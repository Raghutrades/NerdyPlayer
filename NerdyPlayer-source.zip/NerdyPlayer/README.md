# NerdyPlayer

A private, fully offline photo + video gallery and player for Android.

- Library with tabs (All, Photos, Videos, Favourites), albums, search, sort, smart lists
- Photo viewer: swipe, pinch-zoom, pan, double-tap zoom, rotate, flip, free angle, colour adjust, info
- Slideshow with transitions (fade, slide, zoom, Ken Burns)
- Native video player (Media3 ExoPlayer): speed 0.25x to 4x, rotate to any angle, flip, zoom/pan, aspect modes,
  colour filters, A-B repeat, subtitles, audio tracks, volume boost, equalizer, sleep timer, picture-in-picture,
  gestures (brightness, volume, seek, double-tap, hold to fast-play), resume position, frame capture
- Private vault: AES-256 encrypted, PIN + fingerprint, auto-lock, screenshot block, secure erase
- Delete, share, favourite, duplicate finder, storage insights
- No internet permission at all

## Build (GitHub does it for you)
1. Put this project (or the zip) in a GitHub repo.
2. Make sure `.github/workflows/build-apk.yml` is in the repo.
3. Push. Actions builds it. Download `NerdyPlayer.apk` from the Releases page.

Your photo for the About page: add `raghu.jpg` next to the zip (or inside `app/src/main/assets/www/`).
