# NerdyPlayer
Offline Android gallery and player for photos and videos. Private by design: no internet permission, encrypted vault, PIN/fingerprint lock.

## Build the APK on GitHub
1. Create a new **private** GitHub repo (the signing keystore is in this project).
2. Upload this project (or `NerdyPlayer-source.zip` + `.github/workflows/build-apk.yml`).
3. Optional: add `raghu.jpg` at the repo root for the About page photo.
4. Open **Actions → Build NerdyPlayer APK**, wait for green, then download `NerdyPlayer.apk` from **Releases → latest**.
5. Install it on your phone (allow "install unknown apps").

Web app: `app/src/main/assets/www` (edit About text in `js/about.js`). Android shell: `app/src/main/java/...`.
