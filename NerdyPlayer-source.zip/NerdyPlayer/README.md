# NerdyPlayer
Offline Android gallery and player for photos and videos. Private by design: no internet permission, encrypted vault, PIN/fingerprint lock.

## Build the APK on GitHub
1. Create a new **private** GitHub repo (the signing keystore is in this project).
2. Upload this project (or `NerdyPlayer-source.zip` + `.github/workflows/build-apk.yml`).
3. Optional: add `raghu.jpg` at the repo root for the About page photo.
4. Open **Actions → Build NerdyPlayer APK**, wait for green, then download `NerdyPlayer.apk` from **Releases → latest**.
5. Install it on your phone (allow "install unknown apps").

Web app: `app/src/main/assets/www` (edit About text in `js/about.js`). Android shell: `app/src/main/java/...`.

## Version 2 notes
- Full-screen app (Settings → Look), immersive video playback.
- View styles: Photos (Grid, Masonry, Mosaic, Feed, Card stack, Coverflow) and Videos (List, Grid, Live cards, Reels, Card stack, Mosaic).
- Built-in VLC engine (libVLC) for every video format and half-downloaded files: drawer → "Play any file (VLC)". The WebView player hands over automatically when a video fails.
- HEIC / TIFF / DNG / JPEG-2000 pictures are decoded by Android and shown like normal photos.
- Vault: originals are hidden inside the app immediately; use "Remove originals now" if you cancelled Android's prompt.
- The APK is larger now because VLC is inside it (arm64 + armv7 only).

## v2.1 notes
- One player for every format: the same screen and controls drive the browser engine and an embedded libVLC engine (drawn behind the transparent page). No separate player screen; Settings > Playback engine can force one.
- Live previews: formats the WebView cannot play cycle real still frames via the `/tf/<id>?t=ms` route.
- Lag: backdrop blur, endless animations and heavy shadows removed; tiles are cheaper.
- Greeting uses the name set in Settings > Your name (empty by default).
- Calmer splash with a soft two-note chime.

## v2.2
- VLC (libVLC) is now the main engine for every video and is pre-loaded at launch for a fast first frame. Hardware decoding can be switched off in Settings.
- Quick player strip: Rotate, Flip, Audio, Subtitles, Filters, A-B, Capture, Chapters; Aspect button cycles Fit / Fill / 16:9 / 4:3 / 21:9 / Stretch / 100%.
- Six more photo styles: Justified rows, Timeline, Polaroid, Photo wall, Bubbles, Cinema wide.
- The workflow also publishes the APK as a GitHub Release.
