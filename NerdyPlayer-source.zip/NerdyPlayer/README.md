# NerdyPlayer
Offline Android gallery and player for photos and videos. Private by design: no internet permission, encrypted vault, PIN/fingerprint lock.

## Build the APK on GitHub
1. Create a new **private** GitHub repo (the signing keystore is in this project).
2. Upload this project (or `NerdyPlayer-source.zip` + `.github/workflows/build-apk.yml`).
3. Optional: add `raghu.jpg` at the repo root for the About page photo.
4. Open **Actions → Build NerdyPlayer APK**, wait for green, then download `NerdyPlayer.apk` from **Releases → latest**.
5. Install it on your phone (allow "install unknown apps").

Web app: `app/src/main/assets/www` (edit About text in `js/about.js`). Android shell: `app/src/main/java/...`.

## Version 2 notes
- Full-screen app (Settings → Look), immersive video playback.
- View styles: Photos (Grid, Masonry, Mosaic, Feed, Card stack, Coverflow) and Videos (List, Grid, Live cards, Reels, Card stack, Mosaic).
- Built-in VLC engine (libVLC) for every video format and half-downloaded files: drawer → "Play any file (VLC)". The WebView player hands over automatically when a video fails.
- HEIC / TIFF / DNG / JPEG-2000 pictures are decoded by Android and shown like normal photos.
- Vault: originals are hidden inside the app immediately; use "Remove originals now" if you cancelled Android's prompt.
- The APK is larger now because VLC is inside it (arm64 + armv7 only).

## Version 3 - one player, powered by VLC
- Every video (gallery, vault, "Open with", Share, "Play any file") now opens in ONE native VLC player. The slow WebView player is no longer used inside the app.
- LibVLC is created once when the app starts and kept warm, so videos start instantly. "Open with" on a video skips the gallery entirely.
- Player tools: speed 0.25x-4x (fine slider), rotate 90/180 + fine tilt, flip horizontal/vertical, zoom + pan, aspect ratios, orientation modes, picture (brightness, contrast, saturation, hue, warmth, presets), audio track, volume boost to 200%, audio delay, 18-preset + 10-band equalizer, subtitle track/file/delay, A-B loop, bookmarks, sleep timer, capture frame, picture-in-picture, lock controls, queue with loop/shuffle, hardware/software decoder switch (auto software retry).
- Vault videos are decrypted in memory while playing; nothing is written to disk in clear.
