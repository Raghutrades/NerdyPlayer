package com.nerdyintruder.nerdyplayer;

import android.content.Context;
import android.net.Uri;

import androidx.media3.common.C;
import androidx.media3.datasource.BaseDataSource;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.TransferListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Streams an encrypted vault video to the player, decrypting on the fly (seeking works). */
final class VaultDataSource extends BaseDataSource {
    private final Vault vault;
    private Vault.Reader reader;
    private Uri uri;
    private long remaining;
    private boolean opened;

    VaultDataSource(Vault v) {
        super(false);
        vault = v;
    }

    @Override
    public long open(DataSpec spec) throws IOException {
        if (!Guard.vaultOk()) throw new IOException("Vault is locked");
        uri = spec.uri;
        transferInitializing(spec);
        try {
            reader = vault.reader(uri.getHost());
            long pos = spec.position;
            if (pos > reader.size) pos = reader.size;
            reader.seek(pos);
            remaining = spec.length == C.LENGTH_UNSET ? reader.size - pos : Math.min(spec.length, reader.size - pos);
        } catch (Exception e) {
            throw new IOException(e);
        }
        opened = true;
        transferStarted(spec);
        return remaining;
    }

    @Override
    public int read(byte[] buffer, int offset, int length) throws IOException {
        if (length == 0) return 0;
        if (remaining == 0) return C.RESULT_END_OF_INPUT;
        int n = reader.read(buffer, offset, (int) Math.min(length, remaining));
        if (n < 0) return C.RESULT_END_OF_INPUT;
        remaining -= n;
        bytesTransferred(n);
        return n;
    }

    @Override public Uri getUri() { return uri; }

    @Override
    public void close() throws IOException {
        try {
            if (reader != null) reader.close();
        } finally {
            reader = null;
            uri = null;
            if (opened) { opened = false; transferEnded(); }
        }
    }

    /** Picks the vault reader for vault:// addresses and the normal reader for everything else. */
    static final class Router implements DataSource {
        private final Context ctx;
        private final Vault vault;
        private final List<TransferListener> listeners = new ArrayList<>();
        private DataSource active;

        Router(Context c, Vault v) { ctx = c; vault = v; }

        @Override public void addTransferListener(TransferListener l) { listeners.add(l); }

        @Override
        public long open(DataSpec spec) throws IOException {
            active = "vault".equals(spec.uri.getScheme()) ? new VaultDataSource(vault)
                    : new DefaultDataSource.Factory(ctx).createDataSource();
            for (TransferListener l : listeners) active.addTransferListener(l);
            return active.open(spec);
        }

        @Override public int read(byte[] b, int o, int l) throws IOException { return active.read(b, o, l); }

        @Override public Uri getUri() { return active == null ? null : active.getUri(); }

        @Override
        public void close() throws IOException {
            if (active != null) { try { active.close(); } finally { active = null; } }
        }
    }
}
