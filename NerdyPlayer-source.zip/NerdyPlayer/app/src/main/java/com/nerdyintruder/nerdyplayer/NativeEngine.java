package com.nerdyintruder.nerdyplayer;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import org.json.JSONArray;
import org.json.JSONObject;
import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.util.VLCVideoLayout;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;

/**
 * The second video engine (VLC). It draws behind the transparent WebView, so the
 * player interface is the SAME one you use for every video. Everything is called
 * on the UI thread.
 */
final class NativeEngine {
    interface Emit { void send(JSONObject o); }

    private final Activity act;
    private final FrameLayout host;
    private final Emit emit;
    private LibVLC lib;
    private MediaPlayer mp;
    private VLCVideoLayout layout;
    private ParcelFileDescriptor pfd;
    private File tmp;
    private float density = 1f;
    private MediaPlayer.Equalizer eq;

    NativeEngine(Activity a, FrameLayout host, Emit e) {
        this.act = a;
        this.host = host;
        this.emit = e;
        this.density = a.getResources().getDisplayMetrics().density;
    }

    boolean isOpen() { return mp != null; }

    private void send(String type, Object... kv) {
        try {
            JSONObject o = new JSONObject();
            o.put("e", "np");
            o.put("t", type);
            for (int i = 0; i + 1 < kv.length; i += 2) o.put(String.valueOf(kv[i]), kv[i + 1]);
            emit.send(o);
        } catch (Exception ignored) { }
    }

    /** Load VLC in the background right after launch so the first video starts at once. */
    void warm() {
        new Thread(() -> {
            try { synchronized (this) { makeLib(); } } catch (Throwable ignored) { }
            act.runOnUiThread(() -> { try { ensure(); layout.setVisibility(View.INVISIBLE); } catch (Throwable ignored) { } });
        }, "vlc-warm").start();
    }

    private void makeLib() {
        if (lib != null) return;
        ArrayList<String> args = new ArrayList<>();
        args.add("--no-drop-late-frames");
        args.add("--no-skip-frames");
        args.add("--audio-time-stretch");
        args.add("--avcodec-hw=any");
        args.add("--network-caching=300");
        lib = new LibVLC(act, args);
    }

    private void ensure() {
        if (lib == null) {
            synchronized (this) { makeLib(); }
        }
        if (layout == null) {
            layout = new VLCVideoLayout(act);
            host.addView(layout, 0, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        if (mp == null) {
            mp = new MediaPlayer(lib);
            mp.attachViews(layout, null, true, true);
            mp.setEventListener(ev -> {
                switch (ev.type) {
                    case MediaPlayer.Event.LengthChanged:
                        send("len", "ms", ev.getLengthChanged());
                        break;
                    case MediaPlayer.Event.TimeChanged:
                        send("time", "ms", ev.getTimeChanged());
                        break;
                    case MediaPlayer.Event.Playing:
                        send("state", "s", "playing");
                        break;
                    case MediaPlayer.Event.Paused:
                        send("state", "s", "paused");
                        break;
                    case MediaPlayer.Event.Buffering:
                        send("buf", "p", ev.getBuffering());
                        break;
                    case MediaPlayer.Event.EndReached:
                        send("state", "s", "ended");
                        break;
                    case MediaPlayer.Event.EncounteredError:
                        send("state", "s", "error");
                        break;
                    case MediaPlayer.Event.ESAdded:
                        send("tracks");
                        break;
                    default:
                        break;
                }
            });
        }
    }

    /** Open a content/file Uri, or a plain file (a decrypted vault video). */
    void open(Uri uri, File file, long startMs) { open(uri, file, startMs, true); }

    void open(Uri uri, File file, long startMs, boolean hw) {
        try {
            ensure();
            mp.stop();
            closeFd();
            Media m;
            if (file != null) {
                tmp = file;
                m = new Media(lib, Uri.fromFile(file));
            } else if ("file".equals(uri.getScheme())) {
                m = new Media(lib, uri);
            } else {
                pfd = act.getContentResolver().openFileDescriptor(uri, "r");
                m = new Media(lib, pfd.getFileDescriptor());
            }
            m.setHWDecoderEnabled(hw, false);
            m.addOption(":file-caching=300");
            m.addOption(":clock-jitter=0");
            if (deint) { m.addOption(":deinterlace=1"); m.addOption(":deinterlace-mode=blend"); }
            mp.setMedia(m);
            m.release();
            mp.play();
            if (startMs > 0) mp.setTime(startMs);
            layout.setVisibility(View.VISIBLE);
        } catch (Throwable t) {
            send("state", "s", "error", "msg", String.valueOf(t.getMessage()));
        }
    }

    private void closeFd() {
        try { if (pfd != null) pfd.close(); } catch (Exception ignored) { }
        pfd = null;
    }

    void play() { if (mp != null) mp.play(); }
    void pause() { if (mp != null) mp.pause(); }
    void seek(long ms) { if (mp != null) mp.setTime(Math.max(0, ms)); }
    void rate(float r) { if (mp != null) mp.setRate(r); }
    void volume(int pct) { if (mp != null) mp.setVolume(Math.max(0, Math.min(200, pct))); }
    void audioDelay(long ms) { if (mp != null) mp.setAudioDelay(ms * 1000L); }
    void subDelay(long ms) { if (mp != null) mp.setSpuDelay(ms * 1000L); }
    void audioTrack(int id) { if (mp != null) mp.setAudioTrack(id); }
    void subTrack(int id) { if (mp != null) mp.setSpuTrack(id); }

    void fit(String mode) {
        if (mp == null) return;
        try {
            mp.setAspectRatio(null);
            switch (mode) {
                case "fill": mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_FIT_SCREEN); break;
                case "stretch": mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_FILL); break;
                case "100": mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_ORIGINAL); break;
                case "16:9": mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_16_9); break;
                case "4:3": mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_4_3); break;
                case "21:9": case "1:1": case "9:16":
                    mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_BEST_FIT);
                    mp.setAspectRatio(mode);
                    break;
                default: mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_BEST_FIT); break;
            }
        } catch (Throwable ignored) { }
    }

    /** rotation in degrees, flips as +1/-1, scale, translation in CSS pixels */
    void xform(float rot, float fx, float fy, float scale, float tx, float ty) {
        if (layout == null) return;
        layout.setRotation(rot);
        layout.setScaleX(fx * scale);
        layout.setScaleY(fy * scale);
        layout.setTranslationX(tx * density);
        layout.setTranslationY(ty * density);
    }

    private TextureView findTexture(View v) {
        if (v instanceof TextureView) return (TextureView) v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                TextureView t = findTexture(g.getChildAt(i));
                if (t != null) return t;
            }
        }
        return null;
    }

    /** A 4x5 colour matrix (20 numbers) for brightness, contrast, saturation, hue, sepia... */
    void color(float[] m) {
        if (layout == null) return;
        TextureView tv = findTexture(layout);
        if (tv == null) return;
        if (m == null || m.length != 20) { tv.setLayerType(View.LAYER_TYPE_NONE, null); return; }
        Paint p = new Paint();
        p.setColorFilter(new ColorMatrixColorFilter(new ColorMatrix(m)));
        tv.setLayerType(View.LAYER_TYPE_HARDWARE, p);
    }

    void equalizer(float bass, float mid, float treble) {
        if (mp == null) return;
        try {
            if (bass == 0 && mid == 0 && treble == 0) { mp.setEqualizer(null); return; }
            eq = MediaPlayer.Equalizer.create();
            int n = MediaPlayer.Equalizer.getBandCount();
            for (int i = 0; i < n; i++) {
                float g = i <= 2 ? bass : (i >= 7 ? treble : (i >= 4 && i <= 6 ? mid : 0f));
                eq.setAmp(i, g);
            }
            mp.setEqualizer(eq);
        } catch (Throwable ignored) { }
    }

    String chapters() {
        JSONArray a = new JSONArray();
        try {
            if (mp != null) {
                MediaPlayer.Chapter[] cs = mp.getChapters(-1);
                if (cs != null) for (int i = 0; i < cs.length; i++)
                    a.put(new JSONObject().put("id", i).put("t", cs[i].timeOffset).put("name", cs[i].name == null || cs[i].name.isEmpty() ? "Chapter " + (i + 1) : cs[i].name));
                return new JSONObject().put("list", a).put("cur", mp.getChapter()).toString();
            }
        } catch (Throwable ignored) { }
        return "{\"list\":[],\"cur\":0}";
    }

    void chapter(int i) { if (mp != null) try { mp.setChapter(i); } catch (Throwable ignored) { } }

    private boolean deint = false;
    void deinterlace(boolean on) { deint = on; }

    String tracks() {
        JSONObject o = new JSONObject();
        try {
            JSONArray a = new JSONArray(), s = new JSONArray();
            if (mp != null) {
                MediaPlayer.TrackDescription[] at = mp.getAudioTracks();
                if (at != null) for (MediaPlayer.TrackDescription t : at) a.put(new JSONObject().put("id", t.id).put("name", t.name));
                MediaPlayer.TrackDescription[] st = mp.getSpuTracks();
                if (st != null) for (MediaPlayer.TrackDescription t : st) s.put(new JSONObject().put("id", t.id).put("name", t.name));
                o.put("curA", mp.getAudioTrack());
                o.put("curS", mp.getSpuTrack());
            }
            o.put("audio", a);
            o.put("sub", s);
        } catch (Exception ignored) { }
        return o.toString();
    }

    /** Current picture as JPEG bytes (null when unavailable). */
    byte[] shot() {
        try {
            TextureView tv = findTexture(layout);
            if (tv == null) return null;
            Bitmap b = tv.getBitmap();
            if (b == null) return null;
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, 95, bo);
            b.recycle();
            return bo.toByteArray();
        } catch (Throwable t) {
            return null;
        }
    }

    void close() {
        try {
            if (mp != null) {
                mp.setEventListener(null);
                mp.stop();
                mp.detachViews();
                mp.release();
            }
        } catch (Throwable ignored) { }
        mp = null;
        closeFd();
        try { if (layout != null) host.removeView(layout); } catch (Throwable ignored) { }
        layout = null;
        try { if (lib != null) lib.release(); } catch (Throwable ignored) { }
        lib = null;
        if (tmp != null) { try { tmp.delete(); } catch (Exception ignored) { } tmp = null; }
    }
}
