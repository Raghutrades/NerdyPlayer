package com.nerdyintruder.nerdyplayer;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * The private vault.
 * - Every hidden file is encrypted with AES-256 (CTR mode, random IV per file) and stored in the app's
 *   private folder under a random name. Original file names live only inside an encrypted index.
 * - The 256-bit data key is itself wrapped by a key held in the Android Keystore (hardware-backed on
 *   most phones) and never leaves it unwrapped except in memory.
 * - Nothing here ever touches the network (the app has no internet permission).
 */
final class Vault {
    private static final String KS_ALIAS = "np_wrap_key";
    private static final SecureRandom RND = new SecureRandom();

    private final Context ctx;
    private final File dir;
    private SecretKey key;
    private JSONArray index;

    Vault(Context c) {
        ctx = c.getApplicationContext();
        dir = new File(ctx.getFilesDir(), "vault");
        dir.mkdirs();
        try { new File(dir, ".nomedia").createNewFile(); } catch (IOException ignored) { }
    }

    File fileFor(String uid) { return new File(dir, uid); }

    /* ---------------- keys ---------------- */

    private synchronized SecretKey key() throws Exception {
        if (key != null) return key;
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(KS_ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(KS_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build());
            kg.generateKey();
        }
        SecretKey wrap = (SecretKey) ks.getKey(KS_ALIAS, null);
        File kf = new File(dir, "k.bin");
        if (kf.exists()) {
            byte[] all = readAll(kf);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, wrap, new GCMParameterSpec(128, all, 0, 12));
            key = new SecretKeySpec(c.doFinal(all, 12, all.length - 12), "AES");
        } else {
            byte[] raw = new byte[32];
            RND.nextBytes(raw);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, wrap);
            byte[] iv = c.getIV();
            byte[] ct = c.doFinal(raw);
            byte[] all = new byte[iv.length + ct.length];
            System.arraycopy(iv, 0, all, 0, iv.length);
            System.arraycopy(ct, 0, all, iv.length, ct.length);
            writeAll(kf, all);
            key = new SecretKeySpec(raw, "AES");
        }
        return key;
    }

    private byte[] seal(byte[] pt) throws Exception {
        byte[] iv = new byte[12];
        RND.nextBytes(iv);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key(), new GCMParameterSpec(128, iv));
        byte[] ct = c.doFinal(pt);
        byte[] out = new byte[12 + ct.length];
        System.arraycopy(iv, 0, out, 0, 12);
        System.arraycopy(ct, 0, out, 12, ct.length);
        return out;
    }

    private byte[] unseal(byte[] all) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, all, 0, 12));
        return c.doFinal(all, 12, all.length - 12);
    }

    static byte[] addBlocks(byte[] iv, long blocks) {
        byte[] r = new BigInteger(1, iv).add(BigInteger.valueOf(blocks)).toByteArray();
        byte[] out = new byte[16];
        int n = Math.min(r.length, 16);
        System.arraycopy(r, r.length - n, out, 16 - n, n);
        return out;
    }

    private static byte[] readAll(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[(int) f.length()];
            int o = 0;
            while (o < b.length) {
                int n = in.read(b, o, b.length - o);
                if (n < 0) break;
                o += n;
            }
            return b;
        }
    }

    private static void writeAll(File f, byte[] b) throws IOException {
        File tmp = new File(f.getParentFile(), f.getName() + ".tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) { o.write(b); o.getFD().sync(); }
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f); }
    }

    /* ---------------- streams ---------------- */

    OutputStream openEnc(File f) throws Exception {
        byte[] iv = new byte[16];
        RND.nextBytes(iv);
        FileOutputStream fo = new FileOutputStream(f);
        fo.write(iv);
        Cipher c = Cipher.getInstance("AES/CTR/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key(), new IvParameterSpec(iv));
        return new CipherOutputStream(new BufferedOutputStream(fo, 1 << 16), c);
    }

    InputStream openDec(File f) throws Exception {
        FileInputStream fi = new FileInputStream(f);
        byte[] iv = new byte[16];
        int o = 0;
        while (o < 16) { int n = fi.read(iv, o, 16 - o); if (n < 0) { fi.close(); throw new IOException("short"); } o += n; }
        Cipher c = Cipher.getInstance("AES/CTR/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key(), new IvParameterSpec(iv));
        return new CipherInputStream(new BufferedInputStream(fi, 1 << 16), c);
    }

    /** Random-access decrypting reader, used to stream encrypted videos to the player. */
    final class Reader implements Closeable {
        private final RandomAccessFile raf;
        private final byte[] iv = new byte[16];
        private final SecretKey k;
        private Cipher c;
        final long size;

        Reader(File f) throws Exception {
            k = key();
            raf = new RandomAccessFile(f, "r");
            raf.readFully(iv);
            size = raf.length() - 16;
            seek(0);
        }

        void seek(long p) throws Exception {
            long blk = p / 16;
            int skip = (int) (p % 16);
            raf.seek(16 + blk * 16);
            c = Cipher.getInstance("AES/CTR/NoPadding");
            c.init(Cipher.DECRYPT_MODE, k, new IvParameterSpec(addBlocks(iv, blk)));
            if (skip > 0) {
                byte[] tmp = new byte[skip];
                int n = raf.read(tmp, 0, skip);
                if (n > 0) c.update(tmp, 0, n);
            }
        }

        int read(byte[] b, int off, int len) throws IOException {
            int n = raf.read(b, off, len);
            if (n <= 0) return -1;
            try {
                c.update(b, off, n, b, off);
            } catch (Exception e) {
                throw new IOException(e);
            }
            return n;
        }

        @Override public void close() throws IOException { raf.close(); }
    }

    Reader reader(String uid) throws Exception { return new Reader(fileFor(uid)); }

    /* ---------------- index ---------------- */

    private synchronized JSONArray idx() throws Exception {
        if (index != null) return index;
        File f = new File(dir, "i.bin");
        index = f.exists() ? new JSONArray(new String(unseal(readAll(f)), StandardCharsets.UTF_8)) : new JSONArray();
        return index;
    }

    private synchronized void saveIdx() throws Exception {
        writeAll(new File(dir, "i.bin"), seal(index.toString().getBytes(StandardCharsets.UTF_8)));
    }

    synchronized String list() throws Exception { return idx().toString(); }

    synchronized JSONObject entry(String uid) throws Exception {
        JSONArray a = idx();
        for (int i = 0; i < a.length(); i++) if (uid.equals(a.getJSONObject(i).optString("u"))) return a.getJSONObject(i);
        return null;
    }

    /* ---------------- operations ---------------- */

    /** Encrypt a copy of a gallery item into the vault. The caller then deletes the original. */
    synchronized boolean hide(ContentResolver cr, String type, long id) throws Exception {
        JSONObject m = Media.info(cr, type, id);
        if (m == null) return false;
        String uid = UUID.randomUUID().toString().replace("-", "");
        File out = new File(dir, uid);
        try (InputStream in = cr.openInputStream(Media.uri(type, id)); OutputStream o = openEnc(out)) {
            if (in == null) throw new IOException("no stream");
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        } catch (Exception e) {
            out.delete();
            throw e;
        }
        byte[] th = Media.thumb(cr, type, id, 360);
        if (th != null) try (OutputStream o = openEnc(new File(dir, uid + ".t"))) { o.write(th); }
        JSONObject e = new JSONObject();
        e.put("u", uid);
        e.put("t", type);
        e.put("n", m.optString("n"));
        e.put("s", m.optLong("s"));
        e.put("w", m.optLong("w"));
        e.put("h", m.optLong("h"));
        e.put("u2", m.optLong("u"));
        e.put("m", m.optString("m"));
        e.put("b", m.optString("b"));
        e.put("d", m.optLong("d"));
        e.put("a", System.currentTimeMillis());
        idx().put(e);
        saveIdx();
        return true;
    }

    /** Decrypt back into the public gallery, then remove from the vault. */
    synchronized boolean restore(String uid) throws Exception {
        JSONObject e = entry(uid);
        if (e == null) return false;
        File[] legacy = new File[1];
        Uri u = Media.newEntry(ctx, e.optString("t"), e.optString("n", "restored"), e.optString("m"), legacy);
        if (u == null) return false;
        try (InputStream in = openDec(fileFor(uid)); OutputStream out = "file".equals(u.getScheme())
                ? new FileOutputStream(new File(u.getPath())) : ctx.getContentResolver().openOutputStream(u)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        Media.finishEntry(ctx, u, legacy[0], e.optString("m"));
        remove(uid);
        return true;
    }

    /** Overwrite then delete (best effort), and drop from the index. */
    synchronized void remove(String uid) throws Exception {
        wipeFile(fileFor(uid));
        wipeFile(new File(dir, uid + ".t"));
        JSONArray a = idx();
        JSONArray n = new JSONArray();
        for (int i = 0; i < a.length(); i++) if (!uid.equals(a.getJSONObject(i).optString("u"))) n.put(a.getJSONObject(i));
        index = n;
        saveIdx();
    }

    private static void wipeFile(File f) {
        try {
            if (!f.exists()) return;
            try (RandomAccessFile r = new RandomAccessFile(f, "rw")) {
                byte[] z = new byte[1 << 16];
                long left = r.length();
                r.seek(0);
                while (left > 0) { int n = (int) Math.min(z.length, left); r.write(z, 0, n); left -= n; }
                r.getFD().sync();
            }
        } catch (Exception ignored) { }
        f.delete();
    }

    /** Destroy everything including the key. */
    synchronized void wipeAll() {
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) { if (!f.getName().equals(".nomedia")) wipeFile(f); }
        index = null;
        key = null;
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            ks.deleteEntry(KS_ALIAS);
        } catch (Exception ignored) { }
    }
}
