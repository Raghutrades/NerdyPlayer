package com.nerdyintruder.nerdyplayer;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * The private vault. Files are copied into the app's own storage and encrypted with AES-256
 * (CTR, so videos can still be seeked). The master key is random and is itself wrapped by a
 * hardware-backed Android Keystore key that never leaves the device. File names and details
 * live in an AES-GCM encrypted index. Nothing is readable unless the vault is open.
 */
final class Vault {
    private static final String ALIAS = "nerdyplayer_vault_wrap";

    private final Context ctx;
    private final File dir;
    private final File idxFile;
    private final File keyFile;
    private final SecureRandom rnd = new SecureRandom();
    private final Object lock = new Object();

    private byte[] fileKey;
    private byte[] idxKey;
    private final List<JSONObject> entries = new ArrayList<>();

    Vault(Context c) {
        ctx = c;
        dir = new File(c.getFilesDir(), "vault");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        idxFile = new File(dir, "index.bin");
        keyFile = new File(dir, "mk.bin");
    }

    boolean isOpen() {
        synchronized (lock) { return fileKey != null; }
    }

    /* ------------------------- keys ------------------------- */

    private SecretKey keystoreKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build());
            return kg.generateKey();
        }
        return (SecretKey) ks.getKey(ALIAS, null);
    }

    private static byte[] readAll(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) bos.write(b, 0, n);
            return bos.toByteArray();
        }
    }

    private static void writeAtomic(File f, byte[] data) throws IOException {
        File tmp = new File(f.getParentFile(), f.getName() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(data);
            out.getFD().sync();
        }
        if (!tmp.renameTo(f)) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
            if (!tmp.renameTo(f)) throw new IOException("Could not save");
        }
    }

    private byte[] masterKey() throws Exception {
        SecretKey ks = keystoreKey();
        if (keyFile.exists()) {
            byte[] all = readAll(keyFile);
            byte[] iv = java.util.Arrays.copyOfRange(all, 0, 12);
            byte[] ct = java.util.Arrays.copyOfRange(all, 12, all.length);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, ks, new GCMParameterSpec(128, iv));
            return c.doFinal(ct);
        }
        byte[] k = new byte[32];
        rnd.nextBytes(k);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, ks);
        byte[] iv = c.getIV();
        byte[] ct = c.doFinal(k);
        byte[] out = new byte[iv.length + ct.length];
        System.arraycopy(iv, 0, out, 0, iv.length);
        System.arraycopy(ct, 0, out, iv.length, ct.length);
        writeAtomic(keyFile, out);
        return k;
    }

    private static byte[] hmac(byte[] key, String label) throws Exception {
        Mac m = Mac.getInstance("HmacSHA256");
        m.init(new SecretKeySpec(key, "HmacSHA256"));
        return m.doFinal(label.getBytes(StandardCharsets.UTF_8));
    }

    /** Open the vault (the caller has already checked the PIN). */
    void open() throws Exception {
        synchronized (lock) {
            if (fileKey != null) return;
            byte[] mk = masterKey();
            fileKey = hmac(mk, "np-file");
            idxKey = hmac(mk, "np-index");
            java.util.Arrays.fill(mk, (byte) 0);
            entries.clear();
            if (idxFile.exists()) {
                try {
                    byte[] all = readAll(idxFile);
                    byte[] iv = java.util.Arrays.copyOfRange(all, 0, 12);
                    byte[] ct = java.util.Arrays.copyOfRange(all, 12, all.length);
                    Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                    c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(idxKey, "AES"), new GCMParameterSpec(128, iv));
                    JSONArray a = new JSONArray(new String(c.doFinal(ct), StandardCharsets.UTF_8));
                    for (int i = 0; i < a.length(); i++) entries.add(a.getJSONObject(i));
                } catch (Exception e) {
                    fileKey = null;
                    idxKey = null;
                    throw e;
                }
            }
        }
    }

    void close() {
        synchronized (lock) {
            if (fileKey != null) java.util.Arrays.fill(fileKey, (byte) 0);
            if (idxKey != null) java.util.Arrays.fill(idxKey, (byte) 0);
            fileKey = null;
            idxKey = null;
            entries.clear();
        }
    }

    private void saveIndex() throws Exception {
        JSONArray a = new JSONArray();
        for (JSONObject o : entries) a.put(o);
        byte[] iv = new byte[12];
        rnd.nextBytes(iv);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(idxKey, "AES"), new GCMParameterSpec(128, iv));
        byte[] ct = c.doFinal(a.toString().getBytes(StandardCharsets.UTF_8));
        byte[] out = new byte[12 + ct.length];
        System.arraycopy(iv, 0, out, 0, 12);
        System.arraycopy(ct, 0, out, 12, ct.length);
        writeAtomic(idxFile, out);
    }

    /* ------------------------- file crypto ------------------------- */

    private OutputStream encOut(File f) throws Exception {
        byte[] iv = new byte[16];
        rnd.nextBytes(iv);
        FileOutputStream fos = new FileOutputStream(f);
        try {
            fos.write(iv);
            Cipher c = Cipher.getInstance("AES/CTR/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(fileKey, "AES"), new IvParameterSpec(iv));
            return new CipherOutputStream(fos, c);
        } catch (Exception e) {
            fos.close();
            throw e;
        }
    }

    private static byte[] addCounter(byte[] iv, long blocks) {
        byte[] out = iv.clone();
        long carry = blocks;
        for (int i = 15; i >= 0 && carry != 0; i--) {
            long v = (out[i] & 0xFFL) + (carry & 0xFFL);
            out[i] = (byte) v;
            carry = (carry >>> 8) + (v >>> 8);
        }
        return out;
    }

    /** Decrypting stream starting at plaintext offset `skip`. */
    private InputStream decIn(File f, long skip) throws Exception {
        byte[] key;
        synchronized (lock) {
            if (fileKey == null) throw new IOException("Vault is locked");
            key = fileKey.clone();
        }
        FileInputStream fis = new FileInputStream(f);
        try {
            byte[] iv = new byte[16];
            int got = 0;
            while (got < 16) {
                int n = fis.read(iv, got, 16 - got);
                if (n < 0) throw new IOException("Damaged file");
                got += n;
            }
            long block = skip / 16;
            int rem = (int) (skip % 16);
            if (block > 0) fis.getChannel().position(16 + block * 16);
            Cipher c = Cipher.getInstance("AES/CTR/NoPadding");
            c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(addCounter(iv, block)));
            CipherInputStream cis = new CipherInputStream(fis, c);
            long left = rem;
            while (left > 0) {
                long s = cis.skip(left);
                if (s <= 0) {
                    if (cis.read() < 0) break;
                    s = 1;
                }
                left -= s;
            }
            return cis;
        } catch (Exception e) {
            fis.close();
            throw e;
        }
    }

    private static boolean safeId(String id) {
        if (id == null || id.length() != 32) return false;
        for (int i = 0; i < id.length(); i++) {
            char ch = id.charAt(i);
            if (!((ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f'))) return false;
        }
        return true;
    }

    /* ------------------------- serving ------------------------- */

    /** The decrypted size and mime of a file, or null. */
    Object[] describe(String id, boolean thumb) {
        if (!safeId(id)) return null;
        synchronized (lock) {
            if (fileKey == null) return null;
            JSONObject e = find(id);
            if (e == null) return null;
            File f = new File(dir, id + (thumb ? ".t" : ".v"));
            if (!f.exists() || f.length() < 16) return null;
            return new Object[]{thumb ? "image/jpeg" : e.optString("m", "application/octet-stream"), f.length() - 16};
        }
    }

    Media.Opener opener(final String id, final boolean thumb) {
        return new Media.Opener() {
            @Override public InputStream open(long start) throws IOException {
                try {
                    return decIn(new File(dir, id + (thumb ? ".t" : ".v")), start);
                } catch (IOException e) {
                    throw e;
                } catch (Exception e) {
                    throw new IOException(e.getMessage());
                }
            }
        };
    }

    /**
     * A seekable, decrypt-on-read file for the VLC engine. The video is never written to disk
     * in clear: every read the player makes is decrypted in memory (AES-CTR allows random access).
     */
    android.os.ProxyFileDescriptorCallback proxy(final String id) throws IOException {
        if (!safeId(id)) throw new IOException("Bad file");
        final byte[] key;
        synchronized (lock) {
            if (fileKey == null) throw new IOException("Vault is locked");
            key = fileKey.clone();
        }
        final java.io.RandomAccessFile raf = new java.io.RandomAccessFile(new File(dir, id + ".v"), "r");
        final byte[] iv = new byte[16];
        raf.readFully(iv);
        final long size = raf.length() - 16;
        final SecretKeySpec ks = new SecretKeySpec(key, "AES");
        return new android.os.ProxyFileDescriptorCallback() {
            @Override public long onGetSize() { return size; }

            @Override public int onRead(long offset, int sz, byte[] data) throws android.system.ErrnoException {
                try {
                    if (offset >= size) return 0;
                    int want = (int) Math.min(Math.min(sz, data.length), size - offset);
                    long block = offset / 16;
                    int rem = (int) (offset % 16);
                    byte[] enc = new byte[rem + want];
                    raf.seek(16 + block * 16);
                    raf.readFully(enc);
                    Cipher c = Cipher.getInstance("AES/CTR/NoPadding");
                    c.init(Cipher.DECRYPT_MODE, ks, new IvParameterSpec(addCounter(iv, block)));
                    byte[] dec = c.doFinal(enc);
                    System.arraycopy(dec, rem, data, 0, want);
                    return want;
                } catch (Exception e) {
                    throw new android.system.ErrnoException("read", android.system.OsConstants.EIO);
                }
            }

            @Override public void onRelease() {
                try { raf.close(); } catch (IOException ignored) { }
            }
        };
    }

    private JSONObject find(String id) {
        for (JSONObject o : entries) if (id.equals(o.optString("id"))) return o;
        return null;
    }

    /* ------------------------- operations ------------------------- */

    String listJson() {
        synchronized (lock) {
            JSONArray a = new JSONArray();
            for (JSONObject o : entries) a.put(o);
            return a.toString();
        }
    }

    /**
     * Copy a gallery file into the vault. meta has n, m, v, s, d, w, h, t, b.
     * @return the new entry
     */
    JSONObject addOne(android.net.Uri src, JSONObject meta, byte[] thumb) throws Exception {
        synchronized (lock) {
            if (fileKey == null) throw new IOException("Vault is locked");
        }
        String id = UUID.randomUUID().toString().replace("-", "");
        File f = new File(dir, id + ".v");
        File t = new File(dir, id + ".t");
        long copied = 0;
        try (InputStream in = ctx.getContentResolver().openInputStream(src);
             OutputStream out = encOut(f)) {
            if (in == null) throw new IOException("Could not read the file");
            byte[] buf = new byte[1 << 18];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                copied += n;
            }
        } catch (Exception e) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
            throw e;
        }
        boolean hasThumb = false;
        if (thumb != null && thumb.length > 0) {
            try (OutputStream out = encOut(t)) {
                out.write(thumb);
                hasThumb = true;
            } catch (Exception e) {
                //noinspection ResultOfMethodCallIgnored
                t.delete();
            }
        }
        JSONObject e = new JSONObject();
        e.put("id", id);
        e.put("n", meta.optString("n", "file"));
        e.put("m", meta.optString("m", "application/octet-stream"));
        e.put("v", meta.optInt("v", 0));
        e.put("s", copied);
        e.put("d", meta.optLong("d", 0));
        e.put("w", meta.optInt("w", 0));
        e.put("h", meta.optInt("h", 0));
        e.put("t", meta.optLong("t", 0));
        e.put("b", meta.optString("b", ""));
        e.put("a", System.currentTimeMillis());
        e.put("th", hasThumb ? 1 : 0);
        synchronized (lock) {
            entries.add(e);
            try {
                saveIndex();
            } catch (Exception ex) {
                entries.remove(e);
                //noinspection ResultOfMethodCallIgnored
                f.delete();
                //noinspection ResultOfMethodCallIgnored
                t.delete();
                throw ex;
            }
        }
        return e;
    }

    /** Decrypt into the gallery. Returns true when written. */
    boolean restoreOne(String id, Media media, boolean remove) throws Exception {
        JSONObject e;
        synchronized (lock) {
            if (!safeId(id) || fileKey == null) return false;
            e = find(id);
        }
        if (e == null) return false;
        File f = new File(dir, id + ".v");
        try (InputStream in = decIn(f, 0)) {
            media.saveToGallery(e.optString("n", "file"), e.optString("m", "application/octet-stream"),
                    e.optInt("v", 0) == 1, in);
        }
        if (remove) deleteOne(id);
        return true;
    }

    void deleteOne(String id) throws Exception {
        synchronized (lock) {
            if (!safeId(id) || fileKey == null) return;
            JSONObject e = find(id);
            if (e != null) entries.remove(e);
            //noinspection ResultOfMethodCallIgnored
            new File(dir, id + ".v").delete();
            //noinspection ResultOfMethodCallIgnored
            new File(dir, id + ".t").delete();
            saveIndex();
        }
    }

    /** Remove everything, including the keys. */
    void wipe() {
        synchronized (lock) {
            close();
            File[] fs = dir.listFiles();
            if (fs != null) for (File f : fs) {
                //noinspection ResultOfMethodCallIgnored
                f.delete();
            }
            try {
                KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
                ks.load(null);
                if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS);
            } catch (Exception ignored) {
            }
        }
    }

    boolean exists() {
        return keyFile.exists();
    }
}
