package com.nerdyintruder.nerdyplayer;

/** Shared lock flags. The native side enforces them, not just the web page. */
final class Guard {
    /** The PIN was proven recently (used for the optional whole-app lock). */
    static volatile boolean unlocked = false;
    /** The vault is open right now. It can be closed on its own the moment you leave the Vault tab. */
    static volatile boolean vault = false;
    static volatile boolean appLock = false;

    private Guard() { }

    static boolean galleryOk() { return !appLock || unlocked; }

    static boolean vaultOk() { return vault; }

    static void lockAll() { unlocked = false; vault = false; }
}
