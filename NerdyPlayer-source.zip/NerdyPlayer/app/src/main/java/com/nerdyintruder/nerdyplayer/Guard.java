package com.nerdyintruder.nerdyplayer;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * PIN, lock state and lock-out. Everything that decides "may this be shown?" lives here in
 * native code, so the web page can never unlock anything by itself: media, thumbnails and the
 * vault are only served after this class says so.
 */
final class Guard {
    private final SharedPreferences sp;
    private final SecureRandom rnd = new SecureRandom();

    volatile boolean appOk;    // PIN / fingerprint passed (when "lock the whole app" is on)
    volatile boolean vaultOk;  // vault is open
    private volatile long resetOkAt; // phone screen-lock confirmed (for "forgot PIN")

    Guard(Context c) {
        sp = c.getSharedPreferences("np_guard", Context.MODE_PRIVATE);
    }

    boolean pinSet() { return sp.getString("hash", null) != null; }
    boolean appLock() { return sp.getBoolean("applock", false); }
    boolean bio() { return sp.getBoolean("bio", false); }
    boolean vaultAlways() { return sp.getBoolean("vaultAlways", false); }
    boolean shake() { return sp.getBoolean("shake", false); }
    /** seconds in background before locking; 0 = at once, -1 = never */
    int autoLock() { return sp.getInt("autolock", 60); }
    /** 0 = off, 1 = vault only, 2 = everywhere */
    int secureMode() { return sp.getInt("secure", 1); }

    boolean mediaAllowed() { return !appLock() || appOk; }
    boolean vaultAllowed() { return vaultOk; }

    void setOpt(String k, String v) {
        SharedPreferences.Editor e = sp.edit();
        switch (k) {
            case "applock": e.putBoolean("applock", "1".equals(v)); break;
            case "bio": e.putBoolean("bio", "1".equals(v)); break;
            case "vaultAlways": e.putBoolean("vaultAlways", "1".equals(v)); break;
            case "shake": e.putBoolean("shake", "1".equals(v)); break;
            case "autolock":
                try { e.putInt("autolock", Integer.parseInt(v)); } catch (NumberFormatException ignored) { }
                break;
            case "secure":
                try { e.putInt("secure", Integer.parseInt(v)); } catch (NumberFormatException ignored) { }
                break;
            default: break;
        }
        e.apply();
    }

    long lockoutMs() {
        long left = sp.getLong("lockUntil", 0) - System.currentTimeMillis();
        return left > 0 ? left : 0;
    }

    void lock() { appOk = false; vaultOk = false; }

    /** purpose: "app" or "vault" */
    void unlock(String purpose) {
        if ("vault".equals(purpose)) {
            vaultOk = true;
            appOk = true;
        } else {
            appOk = true;
            if (!vaultAlways()) vaultOk = true;
        }
    }

    private byte[] hash(String pin, byte[] salt) throws Exception {
        SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        return f.generateSecret(new PBEKeySpec(pin.toCharArray(), salt, 120000, 256)).getEncoded();
    }

    static boolean validPin(String p) {
        if (p == null || p.length() < 4 || p.length() > 12) return false;
        for (int i = 0; i < p.length(); i++) if (p.charAt(i) < '0' || p.charAt(i) > '9') return false;
        return true;
    }

    /** returns null when fine, else an error text */
    String setPin(String pin, String old) {
        if (!validPin(pin)) return "Use 4 to 12 digits";
        if (pinSet()) {
            boolean viaDevice = System.currentTimeMillis() - resetOkAt < 3 * 60 * 1000L;
            if (!viaDevice) {
                if (lockoutMs() > 0) return "Too many tries. Wait a little.";
                if (!check(old)) return "Current PIN is wrong";
            }
        }
        try {
            byte[] salt = new byte[16];
            rnd.nextBytes(salt);
            byte[] h = hash(pin, salt);
            sp.edit().putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                    .putString("hash", Base64.encodeToString(h, Base64.NO_WRAP))
                    .putInt("fails", 0).putLong("lockUntil", 0).apply();
            resetOkAt = 0;
            return null;
        } catch (Exception e) {
            return "Could not save the PIN";
        }
    }

    private boolean check(String pin) {
        try {
            String s = sp.getString("salt", null), h = sp.getString("hash", null);
            if (s == null || h == null || pin == null) return false;
            byte[] a = hash(pin, Base64.decode(s, Base64.NO_WRAP));
            return MessageDigest.isEqual(a, Base64.decode(h, Base64.NO_WRAP));
        } catch (Exception e) {
            return false;
        }
    }

    /** @return 0 = ok, otherwise milliseconds to wait (or -1 = wrong PIN, may try again) */
    long verify(String pin) {
        long w = lockoutMs();
        if (w > 0) return w;
        if (check(pin)) {
            sp.edit().putInt("fails", 0).putLong("lockUntil", 0).apply();
            return 0;
        }
        int fails = sp.getInt("fails", 0) + 1;
        long wait = 0;
        if (fails >= 5) {
            int step = fails - 5;
            long[] table = {30_000L, 60_000L, 300_000L, 900_000L, 3_600_000L};
            wait = table[Math.min(step, table.length - 1)];
        }
        sp.edit().putInt("fails", fails).putLong("lockUntil", wait > 0 ? System.currentTimeMillis() + wait : 0).apply();
        return wait > 0 ? wait : -1;
    }

    int failsLeftBeforeLockout() {
        int f = sp.getInt("fails", 0);
        return Math.max(0, 5 - f);
    }

    void deviceConfirmed() { resetOkAt = System.currentTimeMillis(); }

    boolean deviceRecent() { return System.currentTimeMillis() - resetOkAt < 3 * 60 * 1000L; }

    void wipe() {
        sp.edit().clear().apply();
        lock();
    }
}
