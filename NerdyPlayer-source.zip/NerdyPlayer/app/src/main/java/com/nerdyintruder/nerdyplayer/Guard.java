package com.nerdyintruder.nerdyplayer;

/** One shared "is the app unlocked right now" flag. The native side enforces it, not just the web page. */
final class Guard {
    static volatile boolean unlocked = false;
    static volatile boolean appLock = false;

    private Guard() { }

    /** Anything in the normal gallery. */
    static boolean galleryOk() { return !appLock || unlocked; }

    /** Anything inside the vault. */
    static boolean vaultOk() { return unlocked; }
}
