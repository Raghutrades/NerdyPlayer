package com.nerdyintruder.nerdyplayer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.media.AudioManager;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Equalizer;
import android.media.audiofx.LoudnessEnhancer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Rational;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.common.VideoSize;
import androidx.media3.common.text.Cue;
import androidx.media3.common.text.CueGroup;
import androidx.media3.datasource.DataSource;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The native video player. Video is decoded by Media3 ExoPlayer into a TextureView (so it can be rotated,
 * flipped, zoomed and colour-filtered freely). All controls are a transparent web page laid on top.
 */
public class PlayerActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";

    private FrameLayout root;
    private TextureView tv;
    private WebView web;
    private ExoPlayer player;
    private Vault vault;
    private SharedPreferences resume;
    private final Handler h = new Handler(Looper.getMainLooper());

    private final List<String> src = new ArrayList<>();
    private final List<String> titles = new ArrayList<>();
    private final Map<String, Uri> subs = new HashMap<>();
    private final Map<String, String> subMime = new HashMap<>();
    private boolean hasVault;

    // picture transform
    private int vw, vh;
    private float par = 1f, rot = 0f, zoom = 1f, panX = 0f, panY = 0f;
    private boolean flipH, flipV;
    private int aspect = 0; // 0 fit,1 fill,2 (spare),3 stretch,4 16:9,5 4:3,6 1:1,7 21:9
    private float fb = 0f, fc = 1f, fs = 1f; // brightness, contrast, saturation

    // loop / timers
    private long abA = -1, abB = -1;
    private boolean sleepEnd;
    private float speed = 1f;
    private boolean keepPitch = true;

    // sound effects
    private volatile int sid = 0;
    private LoudnessEnhancer loud;
    private Equalizer eq;
    private BassBoost bass;
    private int boostMb = 0;
    private boolean eqOn;
    private short[] eqLv;
    private int bassStr = 0;

    private final List<Tracks.Group> audioGroups = new ArrayList<>();
    private final List<Tracks.Group> textGroups = new ArrayList<>();

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        vault = new Vault(this);
        resume = getSharedPreferences("resume", MODE_PRIVATE);
        readIntent(getIntent());
        if (src.isEmpty()) { finish(); return; }
        if (hasVault || getSharedPreferences("np", MODE_PRIVATE).getBoolean("secure", false))
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        tv = new TextureView(this);
        root.addView(tv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        root.addOnLayoutChangeListener((v, l, t, r, bt, ol, ot, or, ob) -> applyTransform());

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !HOST.equals(r.getUrl().getHost());
            }
        });
        web.addJavascriptInterface(new Bridge(), "P");

        DataSource.Factory dsf = () -> new VaultDataSource.Router(PlayerActivity.this, vault);
        player = new ExoPlayer.Builder(this, new DefaultRenderersFactory(this).setEnableDecoderFallback(true))
                .setMediaSourceFactory(new DefaultMediaSourceFactory(dsf))
                .setHandleAudioBecomingNoisy(true)
                .build();
        player.setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true);
        player.setVideoTextureView(tv);
        player.addListener(new Player.Listener() {
            @Override
            public void onVideoSizeChanged(VideoSize v) {
                vw = v.width;
                vh = v.height;
                par = v.pixelWidthHeightRatio <= 0 ? 1f : v.pixelWidthHeightRatio;
                applyTransform();
                pushInfo();
            }

            @Override
            public void onIsPlayingChanged(boolean playing) { tick(); }

            @Override
            public void onPlaybackStateChanged(int st) { tick(); }

            @Override
            public void onMediaItemTransition(MediaItem item, int reason) {
                abA = abB = -1;
                if (sleepEnd && reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) { player.pause(); sleepEnd = false; evalJs("Sleep&&Sleep()"); }
                restoreResume();
                evalJs("Item&&Item(" + player.getCurrentMediaItemIndex() + ")");
            }

            @Override
            public void onTracksChanged(Tracks t) { pushTracks(t); pushInfo(); }

            @Override
            public void onCues(CueGroup g) {
                StringBuilder sb = new StringBuilder();
                for (Cue c : g.cues) {
                    if (c.text != null) { if (sb.length() > 0) sb.append('\n'); sb.append(c.text.toString()); }
                }
                evalJs("Cue&&Cue(" + JSONObject.quote(sb.toString()) + ")");
            }

            @Override
            public void onPlayerError(PlaybackException e) {
                evalJs("Err&&Err(" + JSONObject.quote(e.getErrorCodeName()) + ")");
            }

            @Override
            public void onAudioSessionIdChanged(int id) { sid = id; buildFx(); }
        });

        loadItems(getIntent().getIntExtra("idx", 0), -1);
        player.prepare();
        player.play();
        web.loadUrl("https://" + HOST + "/assets/www/player.html");
        h.post(ticker);
    }

    /* ---------------- intent / items ---------------- */

    private void readIntent(Intent in) {
        ArrayList<String> s = in.getStringArrayListExtra("src");
        ArrayList<String> t = in.getStringArrayListExtra("titles");
        if (s != null) {
            for (int i = 0; i < s.size(); i++) {
                if (s.get(i).startsWith("v:")) { if (!Guard.vaultOk()) continue; hasVault = true; }
                src.add(s.get(i));
                titles.add(t != null && i < t.size() ? t.get(i) : "Video");
            }
        } else if (Intent.ACTION_VIEW.equals(in.getAction()) && in.getData() != null) {
            src.add("u:" + in.getData());
            titles.add(displayName(in.getData()));
        }
    }

    private String displayName(Uri u) {
        String n = null;
        if ("content".equals(u.getScheme())) {
            try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
                if (c != null && c.moveToFirst()) { int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) n = c.getString(i); }
            } catch (Exception ignored) { }
        }
        if (n == null || n.isEmpty()) { String p = u.getLastPathSegment(); n = p == null ? "Video" : p.substring(p.lastIndexOf('/') + 1); }
        return n;
    }

    private Uri uriFor(String s) {
        if (s.startsWith("m:")) return Media.uri("v", Long.parseLong(s.substring(2)));
        if (s.startsWith("v:")) return Uri.parse("vault://" + s.substring(2));
        return Uri.parse(s.substring(2));
    }

    private MediaItem itemFor(String s) {
        MediaItem.Builder mb = new MediaItem.Builder().setUri(uriFor(s)).setMediaId(s);
        if (s.startsWith("v:")) {
            try { JSONObject e = vault.entry(s.substring(2)); if (e != null && !e.optString("m").isEmpty()) mb.setMimeType(e.optString("m")); } catch (Exception ignored) { }
        }
        Uri sub = subs.get(s);
        if (sub != null) {
            mb.setSubtitleConfigurations(java.util.Collections.singletonList(
                    new MediaItem.SubtitleConfiguration.Builder(sub).setMimeType(subMime.get(s)).setLanguage("und")
                            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()));
        }
        return mb.build();
    }

    private void loadItems(int idx, long pos) {
        List<MediaItem> l = new ArrayList<>();
        for (String s : src) l.add(itemFor(s));
        player.setMediaItems(l, idx, pos < 0 ? C.TIME_UNSET : pos);
        if (pos < 0) restoreResume();
    }

    private String cur() {
        int i = player == null ? 0 : player.getCurrentMediaItemIndex();
        return i >= 0 && i < src.size() ? src.get(i) : "";
    }

    private void restoreResume() {
        if (!getSharedPreferences("np_cfg", MODE_PRIVATE).getBoolean("resume", true)) return;
        long p = resume.getLong(cur(), 0);
        if (p > 5000) player.seekTo(p);
    }

    private void saveResume() {
        if (player == null || src.isEmpty()) return;
        long d = player.getDuration(), p = player.getCurrentPosition();
        SharedPreferences.Editor e = resume.edit();
        if (d > 0 && p > 5000 && p < d - 5000) e.putLong(cur(), p); else e.remove(cur());
        e.apply();
    }

    /* ---------------- picture ---------------- */

    private void applyTransform() {
        if (root == null || tv == null) return;
        int W = root.getWidth(), H = root.getHeight();
        if (W == 0 || H == 0 || vw == 0 || vh == 0) return;
        double a = vw * (double) par / vh;
        switch (aspect) {
            case 4: a = 16 / 9.0; break;
            case 5: a = 4 / 3.0; break;
            case 6: a = 1; break;
            case 7: a = 21 / 9.0; break;
            default: break;
        }
        double th = Math.toRadians(rot), c = Math.abs(Math.cos(th)), sn = Math.abs(Math.sin(th));
        double r = ((rot % 180) + 180) % 180;
        boolean zero = r < 0.5 || r > 179.5, ninety = Math.abs(r - 90) < 0.5;
        double dw, dh;
        if (aspect == 3 && (zero || ninety)) {
            dw = zero ? W : H;
            dh = zero ? H : W;
        } else {
            double bw = a * c + sn, bh = a * sn + c;
            double s = aspect == 1 ? Math.max(W / bw, H / bh) : Math.min(W / bw, H / bh);
            dw = a * s;
            dh = s;
        }
        float sx = (float) (dw / W * zoom), sy = (float) (dh / H * zoom);
        tv.setScaleX(flipH ? -sx : sx);
        tv.setScaleY(flipV ? -sy : sy);
        tv.setRotation(rot);
        tv.setTranslationX(panX);
        tv.setTranslationY(panY);
    }

    private void applyFilter() {
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(fs);
        float t = 128f * (1f - fc) + fb * 255f;
        cm.postConcat(new ColorMatrix(new float[]{
                fc, 0, 0, 0, t,
                0, fc, 0, 0, t,
                0, 0, fc, 0, t,
                0, 0, 0, 1, 0}));
        Paint p = new Paint();
        p.setColorFilter(new ColorMatrixColorFilter(cm));
        tv.setLayerPaint(p);
    }

    /* ---------------- sound effects ---------------- */

    private synchronized void buildFx() {
        int id = sid;
        try { if (loud != null) loud.release(); } catch (Exception ignored) { }
        try { if (eq != null) eq.release(); } catch (Exception ignored) { }
        try { if (bass != null) bass.release(); } catch (Exception ignored) { }
        loud = null; eq = null; bass = null;
        if (id == 0) return;
        try { loud = new LoudnessEnhancer(id); loud.setTargetGain(boostMb); loud.setEnabled(boostMb > 0); } catch (Exception ignored) { }
        try {
            eq = new Equalizer(0, id);
            if (eqLv != null) for (short i = 0; i < Math.min(eqLv.length, eq.getNumberOfBands()); i++) eq.setBandLevel(i, eqLv[i]);
            eq.setEnabled(eqOn);
        } catch (Exception ignored) { }
        try { bass = new BassBoost(0, id); bass.setStrength((short) bassStr); bass.setEnabled(bassStr > 0); } catch (Exception ignored) { }
    }

    /* ---------------- pushing state to the page ---------------- */

    private void evalJs(String code) {
        h.post(() -> { if (web != null) web.evaluateJavascript("window." + code, null); });
    }

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            tick();
            h.postDelayed(this, 250);
        }
    };

    private void tick() {
        if (player == null) return;
        long pos = player.getCurrentPosition();
        if (abA >= 0 && abB > abA && pos >= abB) { player.seekTo(abA); pos = abA; }
        try {
            JSONObject o = new JSONObject();
            o.put("p", pos);
            o.put("d", Math.max(0, player.getDuration()));
            o.put("b", player.getBufferedPosition());
            o.put("pl", player.isPlaying());
            o.put("st", player.getPlaybackState());
            o.put("sp", speed);
            o.put("ix", player.getCurrentMediaItemIndex());
            o.put("a", abA);
            o.put("e", abB);
            web.evaluateJavascript("window.S&&S(" + o + ")", null);
        } catch (Exception ignored) { }
    }

    private String label(Format f, String fallback, int n) {
        StringBuilder sb = new StringBuilder();
        if (f.label != null && !f.label.isEmpty()) sb.append(f.label);
        if (f.language != null && !"und".equals(f.language)) sb.append(sb.length() > 0 ? " · " : "").append(f.language);
        if (f.channelCount > 0 && f.sampleMimeType != null && f.sampleMimeType.startsWith("audio")) sb.append(sb.length() > 0 ? " · " : "").append(f.channelCount).append("ch");
        return sb.length() > 0 ? sb.toString() : fallback + " " + n;
    }

    private void pushTracks(Tracks t) {
        audioGroups.clear();
        textGroups.clear();
        JSONArray au = new JSONArray(), tx = new JSONArray();
        try {
            for (Tracks.Group g : t.getGroups()) {
                if (g.length == 0) continue;
                Format f = g.getTrackFormat(0);
                JSONObject o = new JSONObject();
                o.put("s", g.isSelected());
                if (g.getType() == C.TRACK_TYPE_AUDIO) {
                    o.put("l", label(f, "Audio", audioGroups.size() + 1));
                    audioGroups.add(g);
                    au.put(o);
                } else if (g.getType() == C.TRACK_TYPE_TEXT) {
                    o.put("l", label(f, "Subtitle", textGroups.size() + 1));
                    textGroups.add(g);
                    tx.put(o);
                }
            }
            JSONObject all = new JSONObject();
            all.put("audio", au);
            all.put("text", tx);
            evalJs("Tracks&&Tracks(" + all + ")");
        } catch (Exception ignored) { }
    }

    private void pushInfo() {
        try {
            JSONObject o = new JSONObject();
            Format v = player.getVideoFormat();
            Format a = player.getAudioFormat();
            if (v != null) {
                o.put("w", v.width);
                o.put("h", v.height);
                o.put("fps", v.frameRate);
                o.put("vb", v.bitrate);
                o.put("vc", v.sampleMimeType == null ? "" : v.sampleMimeType);
                o.put("vcodec", v.codecs == null ? "" : v.codecs);
            }
            if (a != null) {
                o.put("ac", a.sampleMimeType == null ? "" : a.sampleMimeType);
                o.put("ab", a.bitrate);
                o.put("ach", a.channelCount);
                o.put("ahz", a.sampleRate);
            }
            evalJs("Info&&Info(" + o + ")");
        } catch (Exception ignored) { }
    }

    /* ---------------- lifecycle ---------------- */

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        root.post(this::applyTransform);
    }

    @Override
    public void onPictureInPictureModeChanged(boolean in, Configuration c) {
        super.onPictureInPictureModeChanged(in, c);
        evalJs("Pip&&Pip(" + in + ")");
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (getSharedPreferences("np_cfg", MODE_PRIVATE).getBoolean("autopip", false) && player != null && player.isPlaying() && !hasVault) enterPip();
    }

    private void enterPip() {
        try {
            int w = vw > 0 ? vw : 16, hh = vh > 0 ? vh : 9;
            double r = w / (double) hh;
            if (r > 2.3) { w = 230; hh = 100; } else if (r < 0.45) { w = 45; hh = 100; }
            enterPictureInPictureMode(new PictureInPictureParams.Builder().setAspectRatio(new Rational(w, hh)).build());
        } catch (Exception e) {
            Toast.makeText(this, "Picture-in-picture is not available", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        saveResume();
        if (player != null && !isInPictureInPictureMode()) player.pause();
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.Back&&Back())?'1':'0'", v -> { if (!"\"1\"".equals(v)) finish(); });
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        if (player != null) { saveResume(); player.release(); player = null; }
        try { if (loud != null) loud.release(); } catch (Exception ignored) { }
        try { if (eq != null) eq.release(); } catch (Exception ignored) { }
        try { if (bass != null) bass.release(); } catch (Exception ignored) { }
        if (web != null) { root.removeView(web); web.destroy(); web = null; }
        super.onDestroy();
    }

    /* ---------------- page -> player ---------------- */

    private class Bridge {
        @JavascriptInterface
        public String init() {
            try {
                AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
                JSONObject o = new JSONObject();
                o.put("titles", new JSONArray(titles));
                o.put("idx", getIntent().getIntExtra("idx", 0));
                o.put("vol", am.getStreamVolume(AudioManager.STREAM_MUSIC) / (float) Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)));
                float br = getWindow().getAttributes().screenBrightness;
                o.put("bri", br < 0 ? 0.5f : br);
                o.put("vault", hasVault);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        /** Sound-effects capabilities (bands). */
        @JavascriptInterface
        public String fx() {
            try {
                JSONObject o = new JSONObject();
                synchronized (PlayerActivity.this) {
                    if (eq == null && sid != 0) buildFx();
                    if (eq != null) {
                        JSONArray bands = new JSONArray();
                        for (short i = 0; i < eq.getNumberOfBands(); i++) bands.put(eq.getCenterFreq(i) / 1000);
                        o.put("bands", bands);
                        o.put("min", eq.getBandLevelRange()[0]);
                        o.put("max", eq.getBandLevelRange()[1]);
                    }
                }
                o.put("bass", bass != null);
                o.put("loud", loud != null);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void c(String cmd, String arg) {
            h.post(() -> run(cmd, arg == null ? "" : arg));
        }
    }

    private float f(String s, float d) { try { return Float.parseFloat(s); } catch (Exception e) { return d; } }

    private void run(String cmd, String arg) {
        if (player == null) return;
        switch (cmd) {
            case "play": player.play(); break;
            case "pause": player.pause(); break;
            case "toggle": if (player.isPlaying()) player.pause(); else { if (player.getPlaybackState() == Player.STATE_ENDED) player.seekTo(0); player.play(); } break;
            case "seek": player.seekTo((long) f(arg, 0)); break;
            case "seekby": player.seekTo(Math.max(0, Math.min(player.getDuration() > 0 ? player.getDuration() : Long.MAX_VALUE, player.getCurrentPosition() + (long) f(arg, 0)))); break;
            case "next": saveResume(); if (player.hasNextMediaItem()) player.seekToNextMediaItem(); break;
            case "prev": if (player.getCurrentPosition() > 3000 || !player.hasPreviousMediaItem()) player.seekTo(0); else { saveResume(); player.seekToPreviousMediaItem(); } break;
            case "goto": saveResume(); player.seekTo((int) f(arg, 0), C.TIME_UNSET); break;
            case "speed": case "tmpspeed":
                float sp = Math.max(0.1f, Math.min(8f, f(arg, 1f)));
                if (cmd.equals("speed")) speed = sp;
                player.setPlaybackParameters(new PlaybackParameters(sp, keepPitch ? 1f : sp));
                break;
            case "pitch": keepPitch = !"0".equals(arg); player.setPlaybackParameters(new PlaybackParameters(speed, keepPitch ? 1f : speed)); break;
            case "rot": rot = f(arg, 0); applyTransform(); break;
            case "flip": if (arg.equals("h")) flipH = !flipH; else flipV = !flipV; applyTransform(); break;
            case "asp": aspect = (int) f(arg, 0); applyTransform(); break;
            case "zoom": zoom = Math.max(0.2f, Math.min(8f, f(arg, 1f))); applyTransform(); break;
            case "xf": { // rot,zoom,panX,panY
                String[] p = arg.split(",");
                if (p.length >= 4) { rot = f(p[0], rot); zoom = Math.max(0.2f, Math.min(8f, f(p[1], zoom))); panX = f(p[2], panX); panY = f(p[3], panY); applyTransform(); }
                break;
            }
            case "reset": rot = 0; zoom = 1; panX = panY = 0; flipH = flipV = false; aspect = 0; fb = 0; fc = 1; fs = 1; applyTransform(); applyFilter(); break;
            case "flt": { String[] p = arg.split(","); if (p.length >= 3) { fb = f(p[0], 0); fc = f(p[1], 1); fs = f(p[2], 1); applyFilter(); } break; }
            case "loop": player.setRepeatMode(arg.equals("1") ? Player.REPEAT_MODE_ONE : arg.equals("2") ? Player.REPEAT_MODE_ALL : Player.REPEAT_MODE_OFF); break;
            case "shuffle": player.setShuffleModeEnabled(arg.equals("1")); break;
            case "mute": player.setVolume(arg.equals("1") ? 0f : 1f); break;
            case "boost": boostMb = (int) f(arg, 0); if (loud != null) { try { loud.setTargetGain(boostMb); loud.setEnabled(boostMb > 0); } catch (Exception ignored) { } } break;
            case "eq": { // "on|l0,l1,l2.."
                String[] p = arg.split("\\|");
                eqOn = p.length > 0 && p[0].equals("1");
                if (p.length > 1 && !p[1].isEmpty()) { String[] l = p[1].split(","); eqLv = new short[l.length]; for (int i = 0; i < l.length; i++) eqLv[i] = (short) f(l[i], 0); }
                if (eq != null) { try { if (eqLv != null) for (short i = 0; i < Math.min(eqLv.length, eq.getNumberOfBands()); i++) eq.setBandLevel(i, eqLv[i]); eq.setEnabled(eqOn); } catch (Exception ignored) { } }
                break;
            }
            case "bass": bassStr = (int) f(arg, 0); if (bass != null) { try { bass.setStrength((short) bassStr); bass.setEnabled(bassStr > 0); } catch (Exception ignored) { } } break;
            case "bri": { WindowManager.LayoutParams lp = getWindow().getAttributes(); lp.screenBrightness = Math.max(0.01f, Math.min(1f, f(arg, 0.5f))); getWindow().setAttributes(lp); break; }
            case "vol": { AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE); am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(Math.max(0f, Math.min(1f, f(arg, 0.5f))) * am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)), 0); break; }
            case "abA": abA = player.getCurrentPosition(); if (abB <= abA) abB = -1; break;
            case "abB": if (abA >= 0) abB = player.getCurrentPosition(); break;
            case "abX": abA = abB = -1; break;
            case "sleep": {
                h.removeCallbacks(sleepRun);
                int m = (int) f(arg, 0);
                sleepEnd = m < 0;
                if (m > 0) h.postDelayed(sleepRun, m * 60000L);
                break;
            }
            case "audio": { int k = (int) f(arg, 0); if (k >= 0 && k < audioGroups.size()) player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setOverrideForType(new TrackSelectionOverride(audioGroups.get(k).getMediaTrackGroup(), 0)).build()); break; }
            case "text": {
                int k = (int) f(arg, -1);
                if (k < 0 || k >= textGroups.size()) player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build());
                else player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).setOverrideForType(new TrackSelectionOverride(textGroups.get(k).getMediaTrackGroup(), 0)).build());
                break;
            }
            case "pip": enterPip(); break;
            case "orient": setRequestedOrientation(arg.equals("1") ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    : arg.equals("2") ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED); break;
            case "cap": capture(); break;
            case "pickSub": pickSub(); break;
            case "close": finish(); break;
            default: break;
        }
    }

    private final Runnable sleepRun = () -> { if (player != null) player.pause(); evalJs("Sleep&&Sleep()"); };

    private void capture() {
        if (hasVault) { Toast.makeText(this, "Screenshots are off for vault videos", Toast.LENGTH_SHORT).show(); return; }
        try {
            Bitmap b = vw > 0 && vh > 0 ? tv.getBitmap(vw, vh) : tv.getBitmap();
            if (b == null) return;
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, 95, o);
            Uri u = Media.saveImage(this, o.toByteArray(), "NerdyPlayer_" + System.currentTimeMillis() + ".jpg", "image/jpeg", "Pictures/NerdyPlayer");
            Toast.makeText(this, u != null ? "Frame saved to Pictures/NerdyPlayer" : "Could not save the frame", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not save the frame", Toast.LENGTH_SHORT).show();
        }
    }

    private static final int REQ_SUB = 71;

    private void pickSub() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_SUB);
        } catch (Exception ignored) { }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_SUB || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        String n = displayName(u).toLowerCase();
        String mime = n.endsWith(".vtt") ? "text/vtt" : (n.endsWith(".ass") || n.endsWith(".ssa")) ? "text/x-ssa" : "application/x-subrip";
        String key = cur();
        subs.put(key, u);
        subMime.put(key, mime);
        long pos = player.getCurrentPosition();
        int idx = player.getCurrentMediaItemIndex();
        boolean playing = player.isPlaying();
        loadItems(idx, pos);
        player.prepare();
        if (playing) player.play();
        evalJs("Toast&&Toast('Subtitle loaded. Pick it in Subtitles.')");
    }
}
