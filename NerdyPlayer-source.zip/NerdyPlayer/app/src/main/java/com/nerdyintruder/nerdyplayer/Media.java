package com.nerdyintruder.nerdyplayer;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.Size;

import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Everything that talks to MediaStore: listing, thumbnails, ranged streaming, saving. */
final class Media {

    interface Sink {
        void rows(JSONArray rows, boolean first);
        void done(int total);
    }

    interface Opener {
        InputStream open(long start) throws IOException;
    }

    /** InputStream that stops after a number of bytes and closes an extra resource. */
    static final class Limited extends FilterInputStream {
        private long left;
        private final Closeable extra;

        Limited(InputStream in, long len, Closeable extra) {
            super(in);
            this.left = len;
            this.extra = extra;
        }

        @Override public int read() throws IOException {
            if (left <= 0) return -1;
            int b = super.read();
            if (b >= 0) left--;
            return b;
        }

        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = super.read(b, off, (int) Math.min(len, left));
            if (n > 0) left -= n;
            return n;
        }

        @Override public long skip(long n) throws IOException {
            long s = super.skip(Math.min(n, left));
            if (s > 0) left -= s;
            return s;
        }

        @Override public int available() throws IOException {
            return (int) Math.min(super.available(), Math.min(left, Integer.MAX_VALUE));
        }

        @Override public void close() throws IOException {
            try {
                super.close();
            } finally {
                if (extra != null) {
                    try { extra.close(); } catch (IOException ignored) { }
                }
            }
        }
    }

    static final Uri IMG = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
    static final Uri VID = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

    final Context ctx;
    final ContentResolver cr;

    Media(Context c) {
        ctx = c;
        cr = c.getContentResolver();
    }

    Uri uriFor(String key) {
        if (key == null || key.length() < 2) return null;
        try {
            long id = Long.parseLong(key.substring(1));
            return ContentUris.withAppendedId(key.charAt(0) == 'v' ? VID : IMG, id);
        } catch (NumberFormatException e) {
            return null;
        }
    }


    /** Decode any picture Android understands (HEIC, TIFF, DNG, JPEG-2000...) into a JPEG the WebView can show. */
    byte[] decodeJpeg(Uri u, int max) {
        Bitmap bm = null;
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                final int lim = max;
                android.graphics.ImageDecoder.Source src = android.graphics.ImageDecoder.createSource(cr, u);
                bm = android.graphics.ImageDecoder.decodeBitmap(src, (decoder, info, s) -> {
                    decoder.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE);
                    int w = info.getSize().getWidth(), h = info.getSize().getHeight();
                    int big = Math.max(w, h);
                    if (big > lim) {
                        float f = (float) lim / big;
                        decoder.setTargetSize(Math.max(1, Math.round(w * f)), Math.max(1, Math.round(h * f)));
                    }
                });
            } else {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                try (InputStream in = cr.openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
                int big = Math.max(o.outWidth, o.outHeight), ss = 1;
                while (big / ss > max) ss *= 2;
                o = new BitmapFactory.Options();
                o.inSampleSize = ss;
                try (InputStream in = cr.openInputStream(u)) { bm = BitmapFactory.decodeStream(in, null, o); }
            }
            if (bm == null) return null;
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 92, bo);
            return bo.toByteArray();
        } catch (Throwable t) {
            return null;
        } finally {
            if (bm != null) bm.recycle();
        }
    }

    /* ------------------------- listing ------------------------- */

    private String[] projection(boolean vid, boolean full, boolean trashed) {
        if (!full) return new String[]{"_id", "_display_name", "mime_type", "_size", "date_added"};
        String path = Build.VERSION.SDK_INT >= 29 ? "relative_path" : "_data";
        String exp = (trashed && Build.VERSION.SDK_INT >= 30) ? "date_expires" : "date_modified";
        if (vid) {
            return new String[]{"_id", "_display_name", "mime_type", "_size", "date_added", "datetaken",
                    "duration", "width", "height", "bucket_display_name", path, exp};
        }
        return new String[]{"_id", "_display_name", "mime_type", "_size", "date_added", "datetaken",
                "width", "height", "bucket_display_name", path, exp};
    }

    private static long num(Cursor c, String col) {
        int i = c.getColumnIndex(col);
        if (i < 0 || c.isNull(i)) return 0;
        try { return c.getLong(i); } catch (Exception e) { return 0; }
    }

    private static String str(Cursor c, String col) {
        int i = c.getColumnIndex(col);
        if (i < 0 || c.isNull(i)) return "";
        try { return c.getString(i); } catch (Exception e) { return ""; }
    }

    private Cursor query(Uri base, String[] proj, boolean trashed) {
        if (trashed) {
            if (Build.VERSION.SDK_INT < 30) return null;
            Bundle b = new Bundle();
            b.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, "_size>0");
            b.putInt("android:query-arg-match-trashed", 2); // MediaStore.MATCH_ONLY
            b.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "date_added DESC");
            return cr.query(base, proj, b, null);
        }
        return cr.query(base, proj, "_size>0", null, "date_added DESC");
    }

    /** Row layout: [id, isVideo, name, mime, size, addedSec, takenMs, durMs, w, h, bucket, path, extra] */
    void scan(boolean trashed, Sink sink) {
        JSONArray buf = new JSONArray();
        int total = 0;
        boolean first = true;
        for (int pass = 0; pass < 2; pass++) {
            boolean vid = pass == 1;
            Uri base = vid ? VID : IMG;
            Cursor c = null;
            try {
                try {
                    c = query(base, projection(vid, true, trashed), trashed);
                } catch (Exception e) {
                    c = trashed ? null : cr.query(base, projection(vid, false, false), "_size>0", null, "date_added DESC");
                }
                if (c == null) continue;
                while (c.moveToNext()) {
                    JSONArray r = new JSONArray();
                    r.put(num(c, "_id"));
                    r.put(vid ? 1 : 0);
                    r.put(str(c, "_display_name"));
                    r.put(str(c, "mime_type"));
                    r.put(num(c, "_size"));
                    r.put(num(c, "date_added"));
                    r.put(num(c, "datetaken"));
                    r.put(vid ? num(c, "duration") : 0);
                    r.put(num(c, "width"));
                    r.put(num(c, "height"));
                    r.put(str(c, "bucket_display_name"));
                    r.put(Build.VERSION.SDK_INT >= 29 ? str(c, "relative_path") : str(c, "_data"));
                    r.put(trashed ? num(c, "date_expires") : num(c, "date_modified"));
                    buf.put(r);
                    total++;
                    if (buf.length() >= 600) {
                        sink.rows(buf, first);
                        first = false;
                        buf = new JSONArray();
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) {
                    try { c.close(); } catch (Exception ignored) { }
                }
            }
        }
        if (buf.length() > 0 || first) sink.rows(buf, first);
        sink.done(total);
    }

    /* ------------------------- thumbnails ------------------------- */

    byte[] thumb(String kind, long id, int size) {
        boolean vid = "v".equals(kind);
        Uri u = ContentUris.withAppendedId(vid ? VID : IMG, id);
        Bitmap bm = null;
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                bm = cr.loadThumbnail(u, new Size(size, size), null);
            } else if (vid) {
                bm = MediaStore.Video.Thumbnails.getThumbnail(cr, id, MediaStore.Video.Thumbnails.MINI_KIND, null);
            } else {
                bm = MediaStore.Images.Thumbnails.getThumbnail(cr, id, MediaStore.Images.Thumbnails.MINI_KIND, null);
            }
        } catch (Exception ignored) {
        }
        if (bm == null) bm = fallbackThumb(u, vid, size);
        if (bm == null) return null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream(24 * 1024);
        bm.compress(Bitmap.CompressFormat.JPEG, 82, bos);
        bm.recycle();
        return bos.toByteArray();
    }

    private final Object frameLock = new Object();

    /** One still frame of a video at the given time, as JPEG. Works for any format the phone can decode. */
    byte[] frameAt(Uri u, long ms, int size) {
        synchronized (frameLock) {
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(ctx, u);
                Bitmap f = r.getFrameAtTime(Math.max(0, ms) * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                if (f == null) return null;
                Bitmap sc = scaleDown(f, size);
                ByteArrayOutputStream bos = new ByteArrayOutputStream(24 * 1024);
                sc.compress(Bitmap.CompressFormat.JPEG, 78, bos);
                return bos.toByteArray();
            } catch (Exception e) {
                return null;
            } finally {
                try { r.release(); } catch (Exception ignored) { }
            }
        }
    }

    private Bitmap fallbackThumb(Uri u, boolean vid, int size) {
        try {
            if (vid) {
                MediaMetadataRetriever r = new MediaMetadataRetriever();
                try {
                    r.setDataSource(ctx, u);
                    Bitmap f = r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                    if (f == null) f = r.getFrameAtTime();
                    if (f == null) return null;
                    return scaleDown(f, size);
                } finally {
                    try { r.release(); } catch (Exception ignored) { }
                }
            }
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = cr.openInputStream(u)) {
                if (in == null) return null;
                BitmapFactory.decodeStream(in, null, o);
            }
            int s = 1;
            while (o.outWidth / (s * 2) >= size && o.outHeight / (s * 2) >= size) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            try (InputStream in2 = cr.openInputStream(u)) {
                if (in2 == null) return null;
                return BitmapFactory.decodeStream(in2, null, o2);
            }
        } catch (Exception e) {
            return null;
        }
    }

    private static Bitmap scaleDown(Bitmap b, int size) {
        int w = b.getWidth(), h = b.getHeight();
        float k = Math.min(1f, (float) size / Math.max(w, h));
        if (k >= 1f) return b;
        Bitmap s = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k)), true);
        if (s != b) b.recycle();
        return s;
    }

    /* ------------------------- streaming ------------------------- */

    String mimeOf(Uri u, String fallback) {
        String t = null;
        try { t = cr.getType(u); } catch (Exception ignored) { }
        return (t == null || t.isEmpty()) ? fallback : t;
    }

    /** Open a content Uri as a seekable stream; returns null if it is not seekable. */
    Object[] openSeekable(Uri u) {
        try {
            ParcelFileDescriptor pfd = cr.openFileDescriptor(u, "r");
            if (pfd == null) return null;
            long size = pfd.getStatSize();
            if (size < 0) {
                try { pfd.close(); } catch (IOException ignored) { }
                return null;
            }
            return new Object[]{pfd, size};
        } catch (Exception e) {
            return null;
        }
    }

    Opener seekOpener(final ParcelFileDescriptor pfd) {
        return new Opener() {
            @Override public InputStream open(long start) throws IOException {
                FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
                if (start > 0) fis.getChannel().position(start);
                return new Limited(fis, Long.MAX_VALUE, pfd);
            }
        };
    }

    /* ------------------------- saving ------------------------- */

    /** Save a stream into the gallery (Pictures/NerdyPlayer or Movies/NerdyPlayer). Returns the Uri or null. */
    Uri saveToGallery(String name, String mime, boolean video, InputStream in) throws IOException {
        String folder = video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES;
        byte[] buf = new byte[1 << 16];
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, folder + "/NerdyPlayer");
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri u = cr.insert(video ? VID : IMG, v);
            if (u == null) throw new IOException("Could not create the file");
            try (OutputStream out = cr.openOutputStream(u)) {
                if (out == null) throw new IOException("Could not write the file");
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.flush();
            } catch (IOException e) {
                try { cr.delete(u, null, null); } catch (Exception ignored) { }
                throw e;
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(u, done, null, null);
            return u;
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(folder), "NerdyPlayer");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create the folder");
        File f = new File(dir, name);
        int k = 1;
        while (f.exists()) {
            int dot = name.lastIndexOf('.');
            String stem = dot > 0 ? name.substring(0, dot) : name;
            String ext = dot > 0 ? name.substring(dot) : "";
            f = new File(dir, stem + " (" + (k++) + ")" + ext);
        }
        try (OutputStream out = new FileOutputStream(f)) {
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.flush();
        }
        MediaScannerConnection.scanFile(ctx, new String[]{f.getAbsolutePath()}, new String[]{mime}, null);
        return Uri.fromFile(f);
    }
}
