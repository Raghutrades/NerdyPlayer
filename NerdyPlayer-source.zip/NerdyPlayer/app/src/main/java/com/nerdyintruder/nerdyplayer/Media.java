package com.nerdyintruder.nerdyplayer;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Size;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** Everything that talks to the phone's media library (MediaStore). */
final class Media {
    private Media() { }

    static Uri uri(String type, long id) {
        Uri base = "v".equals(type) ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        return ContentUris.withAppendedId(base, id);
    }

    private static long l(Cursor c, int i) { return i < 0 || c.isNull(i) ? 0 : c.getLong(i); }
    private static String s(Cursor c, int i) { return i < 0 || c.isNull(i) ? "" : c.getString(i); }

    private static void read(ContentResolver cr, String type, JSONArray out, long onlyId, JSONObject[] single) {
        boolean vid = "v".equals(type);
        Uri base = vid ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] proj = vid
                ? new String[]{"_id", "_display_name", "_size", "date_added", "datetaken", "width", "height",
                "bucket_display_name", "mime_type", "_data", "duration"}
                : new String[]{"_id", "_display_name", "_size", "date_added", "datetaken", "width", "height",
                "bucket_display_name", "mime_type", "_data"};
        String sel = onlyId > 0 ? "_id=" + onlyId : null;
        try (Cursor c = cr.query(base, proj, sel, null, onlyId > 0 ? null : "date_added DESC")) {
            if (c == null) return;
            int iId = c.getColumnIndex("_id"), iN = c.getColumnIndex("_display_name"), iS = c.getColumnIndex("_size"),
                    iA = c.getColumnIndex("date_added"), iT = c.getColumnIndex("datetaken"), iW = c.getColumnIndex("width"),
                    iH = c.getColumnIndex("height"), iB = c.getColumnIndex("bucket_display_name"),
                    iM = c.getColumnIndex("mime_type"), iP = c.getColumnIndex("_data"), iD = c.getColumnIndex("duration");
            while (c.moveToNext()) {
                JSONObject o = new JSONObject();
                long taken = l(c, iT);
                long added = l(c, iA) * 1000L;
                o.put("t", vid ? "v" : "i");
                o.put("i", l(c, iId));
                o.put("n", s(c, iN));
                o.put("s", l(c, iS));
                o.put("d", taken > 0 ? taken : added);
                o.put("w", l(c, iW));
                o.put("h", l(c, iH));
                o.put("u", vid ? l(c, iD) : 0);
                o.put("b", s(c, iB));
                o.put("m", s(c, iM));
                o.put("p", s(c, iP));
                if (single != null) { single[0] = o; return; }
                out.put(o);
            }
        } catch (Exception ignored) { }
    }

    /** All photos and videos as a JSON array. */
    static String list(ContentResolver cr) {
        JSONArray a = new JSONArray();
        read(cr, "i", a, 0, null);
        read(cr, "v", a, 0, null);
        return a.toString();
    }

    static JSONObject info(ContentResolver cr, String type, long id) {
        JSONObject[] one = new JSONObject[1];
        read(cr, type, null, id, one);
        return one[0];
    }

    static byte[] thumb(ContentResolver cr, String type, long id, int px) {
        Bitmap b = null;
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                b = cr.loadThumbnail(uri(type, id), new Size(px, px), null);
            } else if ("v".equals(type)) {
                b = MediaStore.Video.Thumbnails.getThumbnail(cr, id, MediaStore.Video.Thumbnails.MINI_KIND, null);
            } else {
                b = MediaStore.Images.Thumbnails.getThumbnail(cr, id, MediaStore.Images.Thumbnails.MINI_KIND, null);
            }
        } catch (Exception ignored) { }
        if (b == null) return null;
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.JPEG, 82, o);
        b.recycle();
        return o.toByteArray();
    }

    /** Re-encode formats a web view cannot show (HEIC and similar) as a JPEG, capped at ~4096 px. */
    static byte[] jpegFrom(ContentResolver cr, Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = cr.openInputStream(uri)) { BitmapFactory.decodeStream(in, null, o); }
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > 4096) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap b;
            try (InputStream in = cr.openInputStream(uri)) { b = BitmapFactory.decodeStream(in, null, o2); }
            if (b == null) return null;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, 92, out);
            b.recycle();
            return out.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    /** Save a picture into Pictures/NerdyPlayer and return its Uri (or null). */
    static Uri saveImage(Context ctx, byte[] data, String name, String mime, String folder) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, folder);
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri u = ctx.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                if (u == null) return null;
                try (OutputStream out = ctx.getContentResolver().openOutputStream(u)) { out.write(data); }
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                ctx.getContentResolver().update(u, done, null, null);
                return u;
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "NerdyPlayer");
                dir.mkdirs();
                File f = new File(dir, name);
                try (FileOutputStream out = new FileOutputStream(f)) { out.write(data); }
                MediaScannerConnection.scanFile(ctx, new String[]{f.getAbsolutePath()}, new String[]{mime}, null);
                return Uri.fromFile(f);
            }
        } catch (Exception e) {
            return null;
        }
    }

    /** Create an empty, pending media entry for a restored file; returns where to write to. */
    static Uri newEntry(Context ctx, String type, String name, String mime, File[] legacyFile) {
        boolean vid = "v".equals(type);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                if (mime != null && !mime.isEmpty()) v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, (vid ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES) + "/NerdyPlayer");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                return ctx.getContentResolver().insert(vid ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        : MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(vid ? Environment.DIRECTORY_MOVIES
                        : Environment.DIRECTORY_PICTURES), "NerdyPlayer");
                dir.mkdirs();
                File f = new File(dir, name);
                legacyFile[0] = f;
                return Uri.fromFile(f);
            }
        } catch (Exception e) {
            return null;
        }
    }

    static void finishEntry(Context ctx, Uri u, File legacy, String mime) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                ctx.getContentResolver().update(u, done, null, null);
            } else if (legacy != null) {
                MediaScannerConnection.scanFile(ctx, new String[]{legacy.getAbsolutePath()}, new String[]{mime}, null);
            }
        } catch (Exception ignored) { }
    }
}
