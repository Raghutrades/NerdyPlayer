package com.nerdyintruder.nerdyplayer;

import android.app.Application;
import android.content.Context;

import org.videolan.libvlc.LibVLC;

import java.util.ArrayList;

/**
 * Keeps ONE LibVLC engine alive for the whole app and warms it up in the background
 * as soon as the app starts. Creating LibVLC is the slow part of starting a video
 * (it loads ~300 plugins), so doing it once, early, makes every video open instantly.
 */
public class NerdyApp extends Application {
    private static LibVLC vlc;

    @Override
    public void onCreate() {
        super.onCreate();
        final Context app = this;
        Thread t = new Thread(() -> {
            try { vlc(app); } catch (Throwable ignored) { }
        }, "np-vlc-warm");
        t.setPriority(Thread.NORM_PRIORITY - 1);
        t.start();
    }

    static synchronized LibVLC vlc(Context c) {
        if (vlc == null) {
            ArrayList<String> a = new ArrayList<>();
            a.add("--no-drop-late-frames");
            a.add("--no-skip-frames");
            a.add("--no-stats");
            a.add("--no-osd");
            a.add("--no-video-title-show");
            vlc = new LibVLC(c.getApplicationContext(), a);
        }
        return vlc;
    }
}
