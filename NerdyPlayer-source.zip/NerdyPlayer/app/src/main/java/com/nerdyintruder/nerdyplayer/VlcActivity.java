package com.nerdyintruder.nerdyplayer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.view.Gravity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.interfaces.IMedia;
import org.videolan.libvlc.util.VLCVideoLayout;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Built-in VLC engine: plays every container and codec VLC knows, including
 * files that are only half downloaded. Used when the WebView player cannot
 * play a file, or when you pick "Play any file".
 */
public class VlcActivity extends Activity {
    private static final int REQ_SUB = 7001;

    private LibVLC lib;
    private MediaPlayer mp;
    private ParcelFileDescriptor pfd;
    private VLCVideoLayout video;
    private FrameLayout root;
    private LinearLayout topBar, botBar;
    private TextView title, tNow, tLen, btnPlay, btnSpeed, btnAspect, hud;
    private SeekBar seek;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean uiOn = true, dragging, locked;
    private long length;
    private float rate = 1f;
    private int aspectIx = 0;
    private int orientIx = 0;
    private final float[] SPEEDS = {0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f, 4f};
    private final MediaPlayer.ScaleType[] ASPECTS = {
            MediaPlayer.ScaleType.SURFACE_BEST_FIT, MediaPlayer.ScaleType.SURFACE_FILL,
            MediaPlayer.ScaleType.SURFACE_FIT_SCREEN, MediaPlayer.ScaleType.SURFACE_16_9,
            MediaPlayer.ScaleType.SURFACE_4_3, MediaPlayer.ScaleType.SURFACE_ORIGINAL};
    private final String[] ASPECT_NAMES = {"Fit", "Fill", "Crop", "16:9", "4:3", "Original"};
    private final Runnable hideUi = () -> showUi(false);
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            update();
            h.postDelayed(this, 500);
        }
    };

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView btn(String t, int sp) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(Color.WHITE);
        v.setTextSize(sp);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(dp(12), dp(8), dp(12), dp(8));
        return v;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        video = new VLCVideoLayout(this);
        root.addView(video, new FrameLayout.LayoutParams(-1, -1));

        hud = new TextView(this);
        hud.setTextColor(Color.WHITE);
        hud.setTextSize(22);
        hud.setGravity(Gravity.CENTER);
        hud.setPadding(dp(22), dp(12), dp(22), dp(12));
        GradientDrawable hb = new GradientDrawable();
        hb.setColor(0xCC000000);
        hb.setCornerRadius(dp(18));
        hud.setBackground(hb);
        hud.setVisibility(View.GONE);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
        root.addView(hud, hp);

        // top bar
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(0x99000000);
        topBar.setPadding(dp(6), dp(8), dp(6), dp(8));
        TextView close = btn("✕", 20);
        close.setOnClickListener(v -> finish());
        title = new TextView(this);
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView lock = btn("🔒", 18);
        lock.setOnClickListener(v -> { locked = true; showUi(false); say("Controls locked. Triple-tap to unlock."); });
        topBar.addView(close);
        topBar.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        topBar.addView(lock);
        root.addView(topBar, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // bottom bar
        botBar = new LinearLayout(this);
        botBar.setOrientation(LinearLayout.VERTICAL);
        botBar.setBackgroundColor(0xAA000000);
        botBar.setPadding(dp(10), dp(8), dp(10), dp(10));
        LinearLayout sr = new LinearLayout(this);
        sr.setGravity(Gravity.CENTER_VERTICAL);
        tNow = new TextView(this); tNow.setTextColor(Color.WHITE); tNow.setTextSize(12); tNow.setText("0:00");
        tLen = new TextView(this); tLen.setTextColor(Color.WHITE); tLen.setTextSize(12); tLen.setText("0:00");
        seek = new SeekBar(this);
        seek.setMax(1000);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser && length > 0) tNow.setText(fmt(length * p / 1000));
            }
            @Override public void onStartTrackingTouch(SeekBar s) { dragging = true; h.removeCallbacks(hideUi); }
            @Override public void onStopTrackingTouch(SeekBar s) {
                dragging = false;
                if (mp != null && length > 0) mp.setTime(length * s.getProgress() / 1000);
                armHide();
            }
        });
        sr.addView(tNow);
        sr.addView(seek, new LinearLayout.LayoutParams(0, -2, 1f));
        sr.addView(tLen);
        botBar.addView(sr);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        TextView back = btn("⏪ 10", 14);
        back.setOnClickListener(v -> skip(-10000));
        btnPlay = btn("⏸", 26);
        btnPlay.setOnClickListener(v -> toggle());
        TextView fwd = btn("10 ⏩", 14);
        fwd.setOnClickListener(v -> skip(10000));
        btnSpeed = btn("1×", 14);
        btnSpeed.setOnClickListener(v -> speedMenu(v));
        btnAspect = btn("Fit", 14);
        btnAspect.setOnClickListener(v -> {
            aspectIx = (aspectIx + 1) % ASPECTS.length;
            if (mp != null) mp.setVideoScale(ASPECTS[aspectIx]);
            btnAspect.setText(ASPECT_NAMES[aspectIx]);
            say(ASPECT_NAMES[aspectIx]);
        });
        TextView aud = btn("🎵", 16);
        aud.setOnClickListener(v -> tracksMenu(v, true));
        TextView sub = btn("CC", 14);
        sub.setOnClickListener(v -> tracksMenu(v, false));
        TextView rot = btn("↻", 18);
        rot.setOnClickListener(v -> rotate());
        row.addView(back); row.addView(btnPlay); row.addView(fwd);
        row.addView(btnSpeed); row.addView(btnAspect); row.addView(aud); row.addView(sub); row.addView(rot);
        botBar.addView(row);
        root.addView(botBar, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        setContentView(root);
        gestures();
        applyBars();

        Uri u = getIntent().getData();
        if (u == null) { finish(); return; }
        title.setText(nameOf(u));
        try {
            ArrayList<String> args = new ArrayList<>();
            args.add("--no-drop-late-frames");
            args.add("--no-skip-frames");
            lib = new LibVLC(this, args);
            mp = new MediaPlayer(lib);
            mp.attachViews(video, null, false, false);
            Media m;
            if ("file".equals(u.getScheme())) {
                m = new Media(lib, u);
            } else {
                pfd = getContentResolver().openFileDescriptor(u, "r");
                m = new Media(lib, pfd.getFileDescriptor());
            }
            m.setHWDecoderEnabled(true, false);
            m.addOption(":file-caching=2000");
            mp.setMedia(m);
            m.release();
            mp.setEventListener(ev -> {
                switch (ev.type) {
                    case MediaPlayer.Event.LengthChanged:
                        length = ev.getLengthChanged();
                        tLen.setText(fmt(length));
                        break;
                    case MediaPlayer.Event.Playing:
                        btnPlay.setText("⏸");
                        break;
                    case MediaPlayer.Event.Paused:
                        btnPlay.setText("▶");
                        break;
                    case MediaPlayer.Event.EndReached:
                        btnPlay.setText("▶");
                        showUi(true);
                        break;
                    case MediaPlayer.Event.EncounteredError:
                        Toast.makeText(VlcActivity.this, "This file cannot be played (too damaged or not video).", Toast.LENGTH_LONG).show();
                        break;
                    default:
                        break;
                }
            });
            mp.play();
            long st = getIntent().getLongExtra("start", 0);
            if (st > 3000) mp.setTime(st);
        } catch (Throwable t) {
            Toast.makeText(this, "Could not start the player: " + t.getMessage(), Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        h.post(tick);
        armHide();
    }

    private String nameOf(Uri u) {
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) { }
        String p = u.getLastPathSegment();
        return p == null ? "Video" : p;
    }

    private static String fmt(long ms) {
        long s = Math.max(0, ms / 1000);
        long hh = s / 3600, mm = (s % 3600) / 60, ss = s % 60;
        return hh > 0 ? String.format(Locale.US, "%d:%02d:%02d", hh, mm, ss) : String.format(Locale.US, "%d:%02d", mm, ss);
    }

    private void update() {
        if (mp == null) return;
        long t = mp.getTime();
        long len = mp.getLength();
        if (len > 0) { length = len; tLen.setText(fmt(len)); }
        if (!dragging) {
            tNow.setText(fmt(t));
            if (length > 0) seek.setProgress((int) (1000L * t / length));
        }
    }

    private void toggle() {
        if (mp == null) return;
        if (mp.isPlaying()) mp.pause(); else mp.play();
        armHide();
    }

    private void skip(long d) {
        if (mp == null) return;
        long t = Math.max(0, mp.getTime() + d);
        if (length > 0) t = Math.min(t, length - 300);
        mp.setTime(t);
        say((d > 0 ? "+" : "−") + Math.abs(d / 1000) + " s");
    }

    private void say(String t) {
        hud.setText(t);
        hud.setVisibility(View.VISIBLE);
        h.removeCallbacks(hudOff);
        h.postDelayed(hudOff, 900);
    }

    private final Runnable hudOff = () -> hud.setVisibility(View.GONE);

    private void speedMenu(View a) {
        PopupMenu pm = new PopupMenu(this, a);
        for (int i = 0; i < SPEEDS.length; i++) pm.getMenu().add(0, i, i, SPEEDS[i] + "×");
        pm.setOnMenuItemClickListener(it -> {
            rate = SPEEDS[it.getItemId()];
            if (mp != null) mp.setRate(rate);
            btnSpeed.setText(rate + "×");
            say(rate + "×");
            return true;
        });
        pm.show();
    }

    private void tracksMenu(View a, boolean audio) {
        if (mp == null) return;
        MediaPlayer.TrackDescription[] tr = audio ? mp.getAudioTracks() : mp.getSpuTracks();
        PopupMenu pm = new PopupMenu(this, a);
        if (tr != null) for (int i = 0; i < tr.length; i++) pm.getMenu().add(0, tr[i].id, i, tr[i].name);
        if (!audio) pm.getMenu().add(0, -999, 999, "Load subtitle file…");
        pm.setOnMenuItemClickListener(it -> {
            int id = it.getItemId();
            if (id == -999) {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    startActivityForResult(i, REQ_SUB);
                } catch (Exception ignored) { }
            } else if (audio) mp.setAudioTrack(id); else mp.setSpuTrack(id);
            return true;
        });
        pm.show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SUB && res == RESULT_OK && data != null && data.getData() != null && mp != null) {
            mp.addSlave(IMedia.Slave.Type.Subtitle, data.getData(), true);
            say("Subtitle loaded");
        }
    }

    private void rotate() {
        orientIx = (orientIx + 1) % 3;
        int[] o = {ActivityInfo.SCREEN_ORIENTATION_SENSOR, ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE, ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT};
        String[] n = {"Auto rotate", "Landscape", "Portrait"};
        setRequestedOrientation(o[orientIx]);
        say(n[orientIx]);
    }

    private void showUi(boolean on) {
        if (locked && on) return;
        uiOn = on;
        int v = on ? View.VISIBLE : View.GONE;
        topBar.setVisibility(v);
        botBar.setVisibility(v);
        if (on) armHide();
        applyBars();
    }

    private void armHide() {
        h.removeCallbacks(hideUi);
        if (uiOn && mp != null && mp.isPlaying()) h.postDelayed(hideUi, 4000);
    }

    private void applyBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) applyBars();
    }

    /* ----- touch: tap, double tap to skip, swipe seek / brightness / volume ----- */
    private float downX, downY, startBright;
    private int startVol;
    private long startTime;
    private int mode; // 0 none, 1 seek, 2 brightness, 3 volume
    private int taps;
    private long lastTap;

    private void gestures() {
        final AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        final GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                if (locked) return true;
                showUi(!uiOn);
                return true;
            }
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (locked) return true;
                float w = root.getWidth();
                if (e.getX() < w * 0.33f) skip(-10000);
                else if (e.getX() > w * 0.67f) skip(10000);
                else toggle();
                return true;
            }
            @Override public void onLongPress(MotionEvent e) {
                if (locked || mp == null) return;
                mp.setRate(2f);
                say("2×");
                longHeld = true;
            }
        });
        root.setOnTouchListener((v, e) -> {
            if (locked) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    long now = System.currentTimeMillis();
                    taps = now - lastTap < 450 ? taps + 1 : 1;
                    lastTap = now;
                    if (taps >= 3) { locked = false; taps = 0; showUi(true); say("Unlocked"); }
                }
                return true;
            }
            gd.onTouchEvent(e);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX(); downY = e.getY(); mode = 0;
                    startTime = mp != null ? mp.getTime() : 0;
                    startBright = getWindow().getAttributes().screenBrightness;
                    if (startBright < 0) startBright = 0.5f;
                    startVol = am.getStreamVolume(AudioManager.STREAM_MUSIC);
                    break;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getX() - downX, dy = e.getY() - downY;
                    if (mode == 0 && !longHeld) {
                        if (Math.abs(dx) > dp(24) && Math.abs(dx) > Math.abs(dy) * 1.5f) mode = 1;
                        else if (Math.abs(dy) > dp(24) && Math.abs(dy) > Math.abs(dx) * 1.5f) mode = downX < root.getWidth() / 2f ? 2 : 3;
                    }
                    if (mode == 1 && mp != null && length > 0) {
                        long t = Math.max(0, Math.min(length, startTime + (long) (dx / root.getWidth() * 120000f)));
                        mp.setTime(t);
                        say(fmt(t));
                    } else if (mode == 2) {
                        float b = Math.max(0.02f, Math.min(1f, startBright - dy / root.getHeight()));
                        WindowManager.LayoutParams lp = getWindow().getAttributes();
                        lp.screenBrightness = b;
                        getWindow().setAttributes(lp);
                        say("☀ " + Math.round(b * 100) + "%");
                    } else if (mode == 3) {
                        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                        int vol = Math.max(0, Math.min(max, startVol + Math.round(-dy / root.getHeight() * max * 1.4f)));
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, vol, 0);
                        say("🔊 " + Math.round(vol * 100f / max) + "%");
                    }
                    break;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (longHeld && mp != null) { mp.setRate(rate); longHeld = false; hud.setVisibility(View.GONE); }
                    break;
                default:
                    break;
            }
            return true;
        });
    }

    private boolean longHeld;

    @Override
    protected void onPause() {
        super.onPause();
        if (mp != null && mp.isPlaying()) mp.pause();
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        try {
            if (mp != null) { mp.stop(); mp.detachViews(); mp.release(); }
            if (lib != null) lib.release();
            if (pfd != null) pfd.close();
        } catch (Throwable ignored) { }
        super.onDestroy();
    }
}
