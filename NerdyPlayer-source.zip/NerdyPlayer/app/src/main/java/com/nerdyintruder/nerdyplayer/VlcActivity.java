package com.nerdyintruder.nerdyplayer;

import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.storage.StorageManager;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Rational;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.interfaces.IMedia;
import org.videolan.libvlc.util.VLCVideoLayout;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/**
 * The ONE NerdyPlayer video player, powered by the VLC engine (libVLC).
 * Plays every format, half-downloaded files, and files inside the encrypted vault.
 * Opens straight from "Open with", from the gallery, or from "Play any file".
 */
public class VlcActivity extends Activity {
    private static final int REQ_SUB = 7001;
    private static final int ACCENT = 0xFF8B7CFF;
    private static final int PANEL_BG = 0xF0111118;

    static VlcActivity live; // so the app lock can close a vault video

    private static final class Item {
        Uri uri;
        String name, key, vaultId;
        long resume;
        ArrayList<Double> marks = new ArrayList<>();
    }

    // engine
    private LibVLC lib;
    private MediaPlayer mp;
    private ParcelFileDescriptor pfd;
    private HandlerThread vaultThread;
    private TextureView tv;

    // views
    private FrameLayout root;
    private VLCVideoLayout video;
    private LinearLayout topBar, botBar, toolRow;
    private TextView title, subtitle, tNow, tLen, btnPlay, btnSpeed, hud, lockHint;
    private SeekBar seek;
    private ProgressBar loader;
    private View scrim;
    private LinearLayout panel, panelBody;
    private TextView panelTitle;
    private final Handler h = new Handler(Looper.getMainLooper());

    // queue + settings
    private final ArrayList<Item> q = new ArrayList<>();
    private int cur = -1;
    boolean vaultMode;
    private int seekStep = 10, hideSecs = 4;
    private boolean cfgDtap = true, cfgGest = true, cfgHold = true, cfgAuto = true, cfgShuffle = false, cfgKeepOn = true, cfgAutoLand = true;
    private String cfgLoop = "off";
    private SharedPreferences prefs;
    private final Random rnd = new Random();

    // state
    private boolean uiOn = true, dragging, locked, inPip, ignoreLeave, panelOpen, longHeld, retriedSw;
    private long length;
    private float rate = 1f;
    private int hw = 1;             // 0 software, 1 hardware, 2 hardware+ (forced)
    private int aspectIx = 0;
    private int orientIx = 0;       // 0 follow video, 1 sensor, 2 landscape, 3 portrait, 4 locked
    private int vw, vh;
    private int volBoost = 100;
    private long abA = -1, abB = -1;
    private long sleepAt = 0;
    private boolean sleepEnd = false;
    private long lastSave = 0;
    private final Map<String, JSONObject> results = new LinkedHashMap<>();

    // view transform
    private int quarter = 0;
    private float fine = 0f, zoom = 1f, panX = 0f, panY = 0f;
    private boolean flipH = false, flipV = false;

    // picture
    private int bri = 0, con = 100, sat = 100, hue = 0, warm = 0;
    private boolean sepia = false, invert = false;

    // audio
    private MediaPlayer.Equalizer eq;
    private int eqPreset = -2; // -2 off, -1 custom, >=0 preset
    private final float[] eqBands = new float[10];
    private float eqPre = 0f;
    private long audioDelay = 0, subDelay = 0;

    private static final float[] SPEEDS = {0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f, 4f};
    private static final MediaPlayer.ScaleType[] ASPECTS = {
            MediaPlayer.ScaleType.SURFACE_BEST_FIT, MediaPlayer.ScaleType.SURFACE_FILL,
            MediaPlayer.ScaleType.SURFACE_FIT_SCREEN, MediaPlayer.ScaleType.SURFACE_16_9,
            MediaPlayer.ScaleType.SURFACE_4_3, MediaPlayer.ScaleType.SURFACE_ORIGINAL};
    private static final String[] ASPECT_NAMES = {"Fit", "Stretch", "Crop", "16:9", "4:3", "Original"};
    private static final String[] EQ_NAMES = {"Flat", "Classical", "Club", "Dance", "Full bass", "Bass + treble", "Full treble",
            "Headphones", "Large hall", "Live", "Party", "Pop", "Reggae", "Rock", "Ska", "Soft", "Soft rock", "Techno"};
    private static final String[] EQ_FREQ = {"60", "170", "310", "600", "1k", "3k", "6k", "12k", "14k", "16k"};
    private static final String[] ORIENT_NAMES = {"Follow video", "Auto rotate", "Landscape", "Portrait", "Lock current"};

    private final Runnable hideUi = () -> showUi(false);
    private final Runnable hudOff = () -> hud.setVisibility(View.GONE);
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            update();
            h.postDelayed(this, 200);
        }
    };

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    /* ============================== lifecycle ============================== */

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        live = this;
        overridePendingTransition(0, 0);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLACK));
        prefs = getSharedPreferences("vlcp", MODE_PRIVATE);
        hw = prefs.getInt("hw", 1);
        aspectIx = prefs.getInt("aspect", 0);
        orientIx = prefs.getInt("orient", 0);
        bri = prefs.getInt("bri", 0); con = prefs.getInt("con", 100); sat = prefs.getInt("sat", 100);
        hue = prefs.getInt("hue", 0); warm = prefs.getInt("warm", 0);

        if (!readIntent(getIntent())) { finish(); return; }
        buildUi();
        applySecure();
        applySystemBars();
        applyOrientation();

        try {
            lib = NerdyApp.vlc(this);
            mp = new MediaPlayer(lib);
            mp.attachViews(video, null, true, true);
            tv = findTv(video);
            mp.setVideoScale(ASPECTS[aspectIx]);
            mp.setEventListener(this::onVlcEvent);
        } catch (Throwable t) {
            Toast.makeText(this, "Could not start the player: " + t.getMessage(), Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        applyPicture();
        h.post(tick);
        startItem(cur, q.get(cur).resume);
    }

    @Override
    protected void onNewIntent(Intent in) {
        super.onNewIntent(in);
        setIntent(in);
        if (readIntent(in)) {
            vaultMode = false;
            startItem(cur, q.get(cur).resume);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveResult();
        if (mp != null && mp.isPlaying() && !(Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode())) mp.pause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mp != null && mp.isPlaying()) mp.pause();
    }

    @Override
    public void finish() {
        saveResult();
        super.finish();
        overridePendingTransition(0, 0);
    }

    @Override
    protected void onDestroy() {
        if (live == this) live = null;
        h.removeCallbacksAndMessages(null);
        try {
            if (mp != null) {
                mp.setEventListener(null);
                mp.stop();
                mp.detachViews();
                mp.release();
            }
            if (pfd != null) pfd.close();
            if (vaultThread != null) vaultThread.quitSafely();
        } catch (Throwable ignored) { }
        super.onDestroy();
    }

    /* ============================== incoming queue ============================== */

    private boolean readIntent(Intent in) {
        q.clear();
        cur = 0;
        try {
            String cfg = in.getStringExtra("cfg");
            if (cfg != null) {
                JSONObject c = new JSONObject(cfg);
                seekStep = Math.max(1, c.optInt("seek", 10));
                cfgDtap = c.optBoolean("dtap", true);
                cfgGest = c.optBoolean("gest", true);
                cfgHold = c.optBoolean("hold2x", true);
                cfgAuto = c.optBoolean("autonext", true);
                cfgShuffle = c.optBoolean("shuffle", false);
                cfgKeepOn = c.optBoolean("keepon", true);
                cfgAutoLand = c.optBoolean("autoland", true);
                hideSecs = Math.max(2, c.optInt("hide", 4));
                cfgLoop = c.optString("loop", "off");
                rate = (float) Math.max(0.25, Math.min(4, c.optDouble("speed", 1)));
            }
            String qj = in.getStringExtra("q");
            if (qj != null) {
                JSONArray a = new JSONArray(qj);
                vaultMode = in.getBooleanExtra("vault", false);
                String[] uris = in.getStringArrayExtra("uris");
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    Item it = new Item();
                    it.key = o.optString("key", null);
                    it.name = o.optString("n", "Video");
                    if (o.optBoolean("vault", false)) it.vaultId = o.optString("id", null);
                    else if (uris != null && i < uris.length && uris[i] != null && !uris[i].isEmpty()) it.uri = Uri.parse(uris[i]);
                    it.resume = (long) (o.optDouble("pos", 0) * 1000);
                    JSONArray m = o.optJSONArray("marks");
                    if (m != null) for (int k = 0; k < m.length(); k++) it.marks.add(m.optDouble(k));
                    if (it.uri != null || it.vaultId != null) q.add(it);
                }
                cur = Math.max(0, Math.min(in.getIntExtra("idx", 0), q.size() - 1));
            } else {
                Uri u = in.getData();
                if (u == null && Intent.ACTION_SEND.equals(in.getAction())) u = in.getParcelableExtra(Intent.EXTRA_STREAM);
                if (u != null) {
                    Item it = new Item();
                    it.uri = u;
                    it.name = nameOf(u);
                    it.resume = in.getLongExtra("start", 0);
                    q.add(it);
                }
            }
        } catch (Throwable t) {
            q.clear();
        }
        if (q.isEmpty()) return false;
        if (vaultMode && (MainActivity.sGuard == null || !MainActivity.sGuard.vaultAllowed())) return false;
        return true;
    }

    private String nameOf(Uri u) {
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null && !n.isEmpty()) return n;
            }
        } catch (Exception ignored) { }
        String p = u.getLastPathSegment();
        if (p == null) return "Video";
        return p.substring(p.lastIndexOf('/') + 1);
    }

    /* ============================== starting a video ============================== */

    private void startItem(int i, long startMs) {
        if (i < 0 || i >= q.size() || mp == null) return;
        saveResult();
        cur = i;
        Item it = q.get(i);
        title.setText(it.name);
        subtitle.setText(q.size() > 1 ? (i + 1) + " / " + q.size() : "");
        subtitle.setVisibility(q.size() > 1 ? View.VISIBLE : View.GONE);
        loader.setVisibility(View.VISIBLE);
        length = 0; vw = 0; vh = 0; abA = abB = -1; retriedSw = false;
        seek.setProgress(0); tNow.setText("0:00"); tLen.setText("0:00");
        resetView();
        audioDelay = 0; subDelay = 0;
        try {
            ParcelFileDescriptor old = pfd;
            pfd = null;
            Media m;
            if (it.vaultId != null) {
                pfd = openVault(it.vaultId);
                m = new Media(lib, pfd.getFileDescriptor());
            } else if ("file".equals(it.uri.getScheme())) {
                m = new Media(lib, it.uri);
            } else {
                pfd = getContentResolver().openFileDescriptor(it.uri, "r");
                m = new Media(lib, pfd.getFileDescriptor());
            }
            m.setHWDecoderEnabled(hw != 0, hw == 2);
            m.addOption(it.vaultId != null ? ":file-caching=1200" : ":file-caching=300");
            if (startMs > 3000) m.addOption(":start-time=" + String.format(Locale.US, "%.2f", startMs / 1000.0));
            mp.setMedia(m);
            m.release();
            mp.play();
            if (old != null) { try { old.close(); } catch (Exception ignored) { } }
        } catch (Throwable t) {
            loader.setVisibility(View.GONE);
            Toast.makeText(this, "Could not open this file: " + t.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        setKeepOn(cfgKeepOn);
        showUi(true);
    }

    private ParcelFileDescriptor openVault(String id) throws Exception {
        Vault v = MainActivity.sVault;
        if (v == null || MainActivity.sGuard == null || !MainActivity.sGuard.vaultAllowed()) throw new java.io.IOException("Vault is locked");
        if (vaultThread == null) { vaultThread = new HandlerThread("np-vault-io"); vaultThread.start(); }
        StorageManager sm = (StorageManager) getSystemService(Context.STORAGE_SERVICE);
        return sm.openProxyFileDescriptor(ParcelFileDescriptor.MODE_READ_ONLY, v.proxy(id), new Handler(vaultThread.getLooper()));
    }

    private void onVlcEvent(MediaPlayer.Event ev) {
        switch (ev.type) {
            case MediaPlayer.Event.LengthChanged:
                length = ev.getLengthChanged();
                tLen.setText(fmt(length));
                break;
            case MediaPlayer.Event.Buffering:
                loader.setVisibility(ev.getBuffering() < 100f ? View.VISIBLE : View.GONE);
                break;
            case MediaPlayer.Event.Playing:
                loader.setVisibility(View.GONE);
                btnPlay.setText("⏸");
                try { mp.setRate(rate); } catch (Throwable ignored) { }
                if (audioDelay != 0) mp.setAudioDelay(audioDelay);
                if (volBoost != 100) mp.setVolume(volBoost);
                videoSized();
                armHide();
                break;
            case MediaPlayer.Event.Vout:
                videoSized();
                break;
            case MediaPlayer.Event.Paused:
                btnPlay.setText("▶");
                h.removeCallbacks(hideUi);
                break;
            case MediaPlayer.Event.EndReached:
                btnPlay.setText("▶");
                onEnded();
                break;
            case MediaPlayer.Event.EncounteredError:
                loader.setVisibility(View.GONE);
                if (hw != 0 && !retriedSw) {
                    // hardware decoder refused this file: silently try software decoding once
                    retriedSw = true;
                    long t = Math.max(0, mp.getTime());
                    int keep = hw;
                    hw = 0;
                    startItem(cur, t);
                    hw = keep;
                    retriedSw = true;
                } else {
                    Toast.makeText(this, "This file cannot be played (damaged or not a video).", Toast.LENGTH_LONG).show();
                    showUi(true);
                }
                break;
            default:
                break;
        }
    }

    private void videoSized() {
        try {
            IMedia.VideoTrack t = mp.getCurrentVideoTrack();
            if (t != null && t.width > 0 && t.height > 0) {
                boolean first = vw == 0;
                vw = t.width; vh = t.height;
                if (first) applyOrientation();
            }
        } catch (Throwable ignored) { }
    }

    private void onEnded() {
        if (sleepEnd) { sleepEnd = false; showUi(true); say("Sleep timer: stopped"); return; }
        Item it = q.get(cur);
        if (it.key != null) putResult(it, 0, length);
        if ("one".equals(cfgLoop)) { startItem(cur, 0); return; }
        if (cfgAuto && q.size() > 1) {
            if (cfgShuffle) {
                int n;
                do { n = rnd.nextInt(q.size()); } while (n == cur);
                startItem(n, q.get(n).resume);
                return;
            }
            if (cur < q.size() - 1) { startItem(cur + 1, q.get(cur + 1).resume); return; }
            if ("all".equals(cfgLoop)) { startItem(0, q.get(0).resume); return; }
        } else if ("all".equals(cfgLoop) && q.size() == 1) { startItem(0, 0); return; }
        showUi(true);
    }

    /* ============================== progress handed back to the gallery ============================== */

    private void putResult(Item it, long t, long d) {
        if (it == null || it.key == null) return;
        try {
            JSONObject o = new JSONObject();
            o.put("key", it.key);
            o.put("t", t / 1000.0);
            o.put("d", d / 1000.0);
            o.put("vault", it.vaultId != null);
            JSONArray m = new JSONArray();
            for (Double x : it.marks) m.put(x);
            o.put("marks", m);
            results.put(it.key, o);
        } catch (Exception ignored) { }
    }

    private void saveResult() {
        try {
            if (mp != null && cur >= 0 && cur < q.size() && length > 0) {
                Item it = q.get(cur);
                if (it.key != null && !results.containsKey(it.key + "#end")) putResult(it, mp.getTime(), length);
            }
            if (results.isEmpty()) return;
            JSONArray a = new JSONArray();
            for (JSONObject o : results.values()) a.put(o);
            Intent r = new Intent();
            r.putExtra("res", a.toString());
            setResult(RESULT_OK, r);
        } catch (Throwable ignored) { }
    }

    /* ============================== UI ============================== */

    private TextView btn(String t, int sp) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(Color.WHITE);
        v.setTextSize(sp);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(dp(12), dp(8), dp(12), dp(8));
        return v;
    }

    private TextView tool(String icon, String label, View.OnClickListener l) {
        TextView v = new TextView(this);
        v.setText(icon + "\n" + label);
        v.setTextColor(0xFFE6E6F0);
        v.setTextSize(11);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(12), dp(6), dp(12), dp(6));
        v.setOnClickListener(l);
        return v;
    }

    private GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        video = new VLCVideoLayout(this);
        root.addView(video, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        root.addOnLayoutChangeListener((v, l, t, r, bt, ol, ot, orr, ob) -> {
            if (r - l != orr - ol || bt - t != ob - ot) root.post(this::applyTransform);
        });

        loader = new ProgressBar(this);
        loader.setIndeterminateTintList(ColorStateList.valueOf(ACCENT));
        root.addView(loader, new FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER));

        hud = new TextView(this);
        hud.setTextColor(Color.WHITE);
        hud.setTextSize(22);
        hud.setGravity(Gravity.CENTER);
        hud.setPadding(dp(22), dp(12), dp(22), dp(12));
        hud.setBackground(round(0xCC000000, 18));
        hud.setVisibility(View.GONE);
        root.addView(hud, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        lockHint = new TextView(this);
        lockHint.setTextColor(0xCCFFFFFF);
        lockHint.setTextSize(12);
        lockHint.setText("🔒  Controls locked · tap 3 times to unlock");
        lockHint.setPadding(dp(14), dp(8), dp(14), dp(8));
        lockHint.setBackground(round(0x88000000, 20));
        lockHint.setVisibility(View.GONE);
        FrameLayout.LayoutParams lhp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lhp.topMargin = dp(30);
        root.addView(lockHint, lhp);

        // ---- top bar
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xCC000000, 0x00000000}));
        topBar.setPadding(dp(6), dp(10), dp(6), dp(16));
        TextView close = btn("✕", 20);
        close.setOnClickListener(v -> finish());
        LinearLayout tt = new LinearLayout(this);
        tt.setOrientation(LinearLayout.VERTICAL);
        title = new TextView(this);
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        subtitle = new TextView(this);
        subtitle.setTextColor(0xAAFFFFFF);
        subtitle.setTextSize(12);
        tt.addView(title);
        tt.addView(subtitle);
        TextView rot = btn("⟳", 22);
        rot.setOnClickListener(v -> { quarter = (quarter + 1) % 4; zoom = 1; panX = panY = 0; applyTransform(); say("Rotate " + (quarter * 90) + "°"); armHide(); });
        TextView pip = btn("⧉", 20);
        pip.setOnClickListener(v -> enterPip());
        TextView lock = btn("🔒", 18);
        lock.setOnClickListener(v -> lockControls());
        topBar.addView(close);
        topBar.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
        topBar.addView(rot);
        topBar.addView(pip);
        topBar.addView(lock);
        root.addView(topBar, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // ---- bottom bar
        botBar = new LinearLayout(this);
        botBar.setOrientation(LinearLayout.VERTICAL);
        botBar.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{0xDD000000, 0x00000000}));
        botBar.setPadding(dp(10), dp(24), dp(10), dp(6));

        LinearLayout sr = new LinearLayout(this);
        sr.setGravity(Gravity.CENTER_VERTICAL);
        tNow = new TextView(this); tNow.setTextColor(Color.WHITE); tNow.setTextSize(12); tNow.setText("0:00");
        tLen = new TextView(this); tLen.setTextColor(Color.WHITE); tLen.setTextSize(12); tLen.setText("0:00");
        seek = new SeekBar(this);
        seek.setMax(1000);
        seek.setProgressTintList(ColorStateList.valueOf(ACCENT));
        seek.setThumbTintList(ColorStateList.valueOf(ACCENT));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser && length > 0) tNow.setText(fmt(length * p / 1000));
            }
            @Override public void onStartTrackingTouch(SeekBar s) { dragging = true; h.removeCallbacks(hideUi); }
            @Override public void onStopTrackingTouch(SeekBar s) {
                dragging = false;
                if (mp != null && length > 0) mp.setTime(length * s.getProgress() / 1000);
                armHide();
            }
        });
        sr.addView(tNow);
        sr.addView(seek, new LinearLayout.LayoutParams(0, -2, 1f));
        sr.addView(tLen);
        botBar.addView(sr);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        TextView prev = btn("⏮", 20);
        prev.setOnClickListener(v -> prevItem());
        TextView back = btn("↺ " + seekStep, 14);
        back.setOnClickListener(v -> skip(-seekStep * 1000L));
        btnPlay = btn("⏸", 30);
        btnPlay.setOnClickListener(v -> toggle());
        TextView fwd = btn(seekStep + " ↻", 14);
        fwd.setOnClickListener(v -> skip(seekStep * 1000L));
        TextView next = btn("⏭", 20);
        next.setOnClickListener(v -> nextItem());
        btnSpeed = btn("1×", 14);
        btnSpeed.setBackground(round(0x33FFFFFF, 14));
        btnSpeed.setOnClickListener(v -> openPanel("speed"));
        row.addView(prev); row.addView(back); row.addView(btnPlay); row.addView(fwd); row.addView(next);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.leftMargin = dp(10);
        row.addView(btnSpeed, sp);
        botBar.addView(row);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        toolRow = new LinearLayout(this);
        toolRow.setOrientation(LinearLayout.HORIZONTAL);
        toolRow.addView(tool("⏩", "Speed", v -> openPanel("speed")));
        toolRow.addView(tool("⤢", "View", v -> openPanel("view")));
        toolRow.addView(tool("◐", "Picture", v -> openPanel("picture")));
        toolRow.addView(tool("♪", "Audio", v -> openPanel("audio")));
        toolRow.addView(tool("CC", "Subtitles", v -> openPanel("subs")));
        toolRow.addView(tool("A↔B", "Loop", v -> openPanel("ab")));
        toolRow.addView(tool("☾", "Sleep", v -> openPanel("sleep")));
        toolRow.addView(tool("▣", "Capture", v -> capture()));
        toolRow.addView(tool("⚑", "Bookmarks", v -> openPanel("marks")));
        toolRow.addView(tool("☰", "Queue", v -> openPanel("queue")));
        toolRow.addView(tool("⚙", "Decoder", v -> openPanel("decoder")));
        toolRow.addView(tool("ⓘ", "Info", v -> openPanel("info")));
        hs.addView(toolRow);
        botBar.addView(hs);
        root.addView(botBar, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        // ---- sliding panel
        scrim = new View(this);
        scrim.setBackgroundColor(0x55000000);
        scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(v -> closePanel());
        root.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable pbg = new GradientDrawable();
        pbg.setColor(PANEL_BG);
        pbg.setCornerRadii(new float[]{dp(22), dp(22), dp(22), dp(22), 0, 0, 0, 0});
        panel.setBackground(pbg);
        panel.setPadding(dp(16), dp(12), dp(16), dp(16));
        panel.setVisibility(View.GONE);
        panel.setClickable(true);
        LinearLayout ph = new LinearLayout(this);
        ph.setGravity(Gravity.CENTER_VERTICAL);
        panelTitle = new TextView(this);
        panelTitle.setTextColor(Color.WHITE);
        panelTitle.setTextSize(17);
        panelTitle.setTypeface(Typeface.DEFAULT_BOLD);
        TextView px = btn("✕", 16);
        px.setOnClickListener(v -> closePanel());
        ph.addView(panelTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        ph.addView(px);
        panel.addView(ph);
        ScrollView sv = new ScrollView(this);
        panelBody = new LinearLayout(this);
        panelBody.setOrientation(LinearLayout.VERTICAL);
        sv.addView(panelBody);
        panel.addView(sv, new LinearLayout.LayoutParams(-1, -2));
        int maxH = (int) (getResources().getDisplayMetrics().heightPixels * 0.62f);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        root.addView(panel, pp);
        panelMaxH = maxH;

        setContentView(root);
        gestures();
    }

    private int panelMaxH;

    /* ============================== panels ============================== */

    private TextView label(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(0xFFB9B9CC);
        v.setTextSize(12);
        v.setPadding(0, dp(12), 0, dp(4));
        return v;
    }

    private HorizontalScrollView chipRow() {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout l = new LinearLayout(this);
        hs.addView(l);
        panelBody.addView(hs);
        return hs;
    }

    private TextView chip(LinearLayout row, String t, boolean on, View.OnClickListener l) {
        TextView c = new TextView(this);
        c.setText(t);
        c.setTextSize(13);
        c.setTextColor(on ? Color.WHITE : 0xFFD8D8E8);
        c.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        c.setPadding(dp(14), dp(8), dp(14), dp(8));
        c.setBackground(round(on ? ACCENT : 0x2AFFFFFF, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        row.addView(c, lp);
        c.setOnClickListener(l);
        return c;
    }

    private LinearLayout rowOf(HorizontalScrollView hs) { return (LinearLayout) hs.getChildAt(0); }

    private void slider(String name, int min, int max, int val, java.util.function.IntFunction<String> fmt, java.util.function.IntConsumer on) {
        LinearLayout head = new LinearLayout(this);
        TextView n = new TextView(this);
        n.setText(name);
        n.setTextColor(Color.WHITE);
        n.setTextSize(14);
        final TextView v = new TextView(this);
        v.setTextColor(ACCENT);
        v.setTextSize(14);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setText(fmt.apply(val));
        head.setPadding(0, dp(10), 0, 0);
        head.addView(n, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(v);
        panelBody.addView(head);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(val - min);
        sb.setProgressTintList(ColorStateList.valueOf(ACCENT));
        sb.setThumbTintList(ColorStateList.valueOf(ACCENT));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (!user) return;
                v.setText(fmt.apply(p + min));
                on.accept(p + min);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        panelBody.addView(sb);
    }

    private TextView textLine(String t, int color, int sp) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(color);
        v.setTextSize(sp);
        v.setPadding(0, dp(6), 0, dp(6));
        panelBody.addView(v);
        return v;
    }

    private void closePanel() {
        panelOpen = false;
        panel.setVisibility(View.GONE);
        scrim.setVisibility(View.GONE);
        armHide();
    }

    private void openPanel(String id) {
        if (locked || mp == null) return;
        h.removeCallbacks(hideUi);
        panelBody.removeAllViews();
        panelOpen = true;
        switch (id) {
            case "speed": panelSpeed(); break;
            case "view": panelView(); break;
            case "picture": panelPicture(); break;
            case "audio": panelAudio(); break;
            case "subs": panelSubs(); break;
            case "ab": panelAb(); break;
            case "sleep": panelSleep(); break;
            case "marks": panelMarks(); break;
            case "queue": panelQueue(); break;
            case "decoder": panelDecoder(); break;
            case "info": panelInfo(); break;
            default: break;
        }
        panel.setVisibility(View.VISIBLE);
        scrim.setVisibility(View.VISIBLE);
        // keep very tall panels scrollable
        ScrollView sv = (ScrollView) panelBody.getParent();
        sv.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        sv.post(() -> {
            if (sv.getHeight() > panelMaxH) sv.setLayoutParams(new LinearLayout.LayoutParams(-1, panelMaxH));
        });
    }

    private void reopen(String id) { openPanel(id); }

    private void panelSpeed() {
        panelTitle.setText("Playback speed");
        HorizontalScrollView hs = chipRow();
        for (float s : SPEEDS) {
            final float sp = s;
            chip(rowOf(hs), fmtRate(s), Math.abs(rate - s) < 0.01f, v -> { setRate(sp); reopen("speed"); });
        }
        slider("Fine speed", 25, 400, Math.round(rate * 100), i -> String.format(Locale.US, "%.2f×", i / 100f), i -> setRate(i / 100f));
        HorizontalScrollView hb = chipRow();
        hb.setPadding(0, dp(10), 0, 0);
        chip(rowOf(hb), "−0.05", false, v -> { setRate(Math.max(0.25f, rate - 0.05f)); reopen("speed"); });
        chip(rowOf(hb), "Reset 1×", false, v -> { setRate(1f); reopen("speed"); });
        chip(rowOf(hb), "+0.05", false, v -> { setRate(Math.min(4f, rate + 0.05f)); reopen("speed"); });
        textLine("Tip: press and hold the video for 2× speed.", 0xFF9A9AB0, 12);
    }

    private void panelView() {
        panelTitle.setText("Rotate, flip & fit");
        panelBody.addView(label("ROTATE"));
        HorizontalScrollView r1 = chipRow();
        chip(rowOf(r1), "⟲ 90°", false, v -> { quarter = (quarter + 3) % 4; zoom = 1; panX = panY = 0; applyTransform(); });
        chip(rowOf(r1), "⟳ 90°", false, v -> { quarter = (quarter + 1) % 4; zoom = 1; panX = panY = 0; applyTransform(); });
        chip(rowOf(r1), "180°", false, v -> { quarter = (quarter + 2) % 4; applyTransform(); });
        slider("Fine tilt", -45, 45, Math.round(fine), i -> i + "°", i -> { fine = i; applyTransform(); });
        panelBody.addView(label("FLIP / MIRROR"));
        HorizontalScrollView r2 = chipRow();
        chip(rowOf(r2), "⇋ Horizontal", flipH, v -> { flipH = !flipH; applyTransform(); reopen("view"); });
        chip(rowOf(r2), "⇅ Vertical", flipV, v -> { flipV = !flipV; applyTransform(); reopen("view"); });
        panelBody.addView(label("ASPECT RATIO"));
        HorizontalScrollView r3 = chipRow();
        for (int i = 0; i < ASPECT_NAMES.length; i++) {
            final int ix = i;
            chip(rowOf(r3), ASPECT_NAMES[i], aspectIx == i, v -> { setAspect(ix); reopen("view"); });
        }
        slider("Zoom", 50, 400, Math.round(zoom * 100), i -> i + "%", i -> { zoom = i / 100f; applyTransform(); });
        panelBody.addView(label("SCREEN ORIENTATION"));
        HorizontalScrollView r4 = chipRow();
        for (int i = 0; i < ORIENT_NAMES.length; i++) {
            final int ix = i;
            chip(rowOf(r4), ORIENT_NAMES[i], orientIx == i, v -> { orientIx = ix; prefs.edit().putInt("orient", ix).apply(); applyOrientation(); reopen("view"); });
        }
        HorizontalScrollView r5 = chipRow();
        r5.setPadding(0, dp(12), 0, 0);
        chip(rowOf(r5), "Reset view", false, v -> { resetView(); applyTransform(); reopen("view"); });
        textLine("Pinch the video to zoom, drag to move it when zoomed.", 0xFF9A9AB0, 12);
    }

    private void panelPicture() {
        panelTitle.setText("Picture");
        panelBody.addView(label("PRESETS"));
        HorizontalScrollView p = chipRow();
        String[] names = {"Normal", "Vivid", "Cinema", "Bright", "Night", "Black & white", "Sepia", "Invert"};
        for (int i = 0; i < names.length; i++) {
            final int ix = i;
            chip(rowOf(p), names[i], false, v -> { pictureStyle(ix); reopen("picture"); });
        }
        slider("Brightness", -100, 100, bri, i -> String.valueOf(i), i -> { bri = i; applyPicture(); });
        slider("Contrast", 0, 200, con, i -> i + "%", i -> { con = i; applyPicture(); });
        slider("Saturation", 0, 200, sat, i -> i + "%", i -> { sat = i; applyPicture(); });
        slider("Hue", -180, 180, hue, i -> i + "°", i -> { hue = i; applyPicture(); });
        slider("Warmth", -100, 100, warm, i -> String.valueOf(i), i -> { warm = i; applyPicture(); });
        if (tv == null) textLine("Picture filters need the TextureView renderer, which is not available on this phone.", 0xFFFFB4A8, 12);
    }

    private void pictureStyle(int i) {
        bri = 0; con = 100; sat = 100; hue = 0; warm = 0; sepia = false; invert = false;
        switch (i) {
            case 1: sat = 140; con = 115; break;
            case 2: con = 115; sat = 90; warm = 20; bri = -5; break;
            case 3: bri = 20; con = 110; break;
            case 4: bri = -20; warm = 30; con = 90; break;
            case 5: sat = 0; con = 110; break;
            case 6: sepia = true; break;
            case 7: invert = true; break;
            default: break;
        }
        applyPicture();
    }

    private void panelAudio() {
        panelTitle.setText("Audio");
        panelBody.addView(label("AUDIO TRACK"));
        HorizontalScrollView hs = chipRow();
        MediaPlayer.TrackDescription[] tr = mp.getAudioTracks();
        if (tr == null || tr.length == 0) chip(rowOf(hs), "No audio tracks", false, v -> { });
        else {
            final int curTrack = mp.getAudioTrack();
            for (MediaPlayer.TrackDescription t : tr) {
                final int id = t.id;
                chip(rowOf(hs), t.name, id == curTrack, v -> { mp.setAudioTrack(id); reopen("audio"); });
            }
        }
        slider("Volume boost", 100, 200, volBoost, i -> i + "%", i -> { volBoost = i; mp.setVolume(i); });
        slider("Audio delay", -2000, 2000, (int) (audioDelay / 1000), i -> i + " ms", i -> { audioDelay = i * 1000L; mp.setAudioDelay(audioDelay); });
        panelBody.addView(label("EQUALIZER"));
        HorizontalScrollView e = chipRow();
        chip(rowOf(e), "Off", eqPreset == -2, v -> { eqPreset = -2; mp.setEqualizer(null); reopen("audio"); });
        chip(rowOf(e), "Custom", eqPreset == -1, v -> {
            eqPreset = -1;
            eq = MediaPlayer.Equalizer.create();
            java.util.Arrays.fill(eqBands, 0f);
            eqPre = 0f;
            mp.setEqualizer(eq);
            reopen("audio");
        });
        for (int i = 0; i < EQ_NAMES.length; i++) {
            final int ix = i;
            chip(rowOf(e), EQ_NAMES[i], eqPreset == i, v -> {
                eqPreset = ix;
                eq = MediaPlayer.Equalizer.createFromPreset(ix);
                mp.setEqualizer(eq);
                reopen("audio");
            });
        }
        if (eqPreset == -1 && eq != null) {
            slider("Pre-amp", -20, 20, Math.round(eqPre), i -> i + " dB", i -> { eqPre = i; eq.setPreAmp(i); mp.setEqualizer(eq); });
            for (int b = 0; b < 10; b++) {
                final int bi = b;
                slider(EQ_FREQ[b] + " Hz", -20, 20, Math.round(eqBands[b]), i -> i + " dB", i -> { eqBands[bi] = i; eq.setAmp(bi, i); mp.setEqualizer(eq); });
            }
        }
    }

    private void panelSubs() {
        panelTitle.setText("Subtitles");
        HorizontalScrollView hs = chipRow();
        MediaPlayer.TrackDescription[] tr = mp.getSpuTracks();
        final int curTrack = mp.getSpuTrack();
        if (tr != null) {
            for (MediaPlayer.TrackDescription t : tr) {
                final int id = t.id;
                chip(rowOf(hs), t.name, id == curTrack, v -> { mp.setSpuTrack(id); reopen("subs"); });
            }
        }
        HorizontalScrollView hf = chipRow();
        hf.setPadding(0, dp(10), 0, 0);
        chip(rowOf(hf), "＋ Load subtitle file…", false, v -> pickSubtitle());
        slider("Subtitle delay", -5000, 5000, (int) (subDelay / 1000), i -> i + " ms", i -> { subDelay = i * 1000L; mp.setSpuDelay(subDelay); });
        textLine("Positive delay shows subtitles later, negative earlier.", 0xFF9A9AB0, 12);
    }

    private void pickSubtitle() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            ignoreLeave = true;
            startActivityForResult(i, REQ_SUB);
        } catch (Exception ignored) { }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        ignoreLeave = false;
        if (req == REQ_SUB && res == RESULT_OK && data != null && data.getData() != null && mp != null) {
            mp.addSlave(IMedia.Slave.Type.Subtitle, data.getData(), true);
            say("Subtitle loaded");
        }
    }

    private void panelAb() {
        panelTitle.setText("A–B loop");
        textLine("Repeat one part of the video forever.", 0xFFB9B9CC, 13);
        textLine("A: " + (abA < 0 ? "not set" : fmt(abA)) + "     B: " + (abB < 0 ? "not set" : fmt(abB)), Color.WHITE, 15);
        HorizontalScrollView hs = chipRow();
        chip(rowOf(hs), "Set A here", false, v -> { abA = mp.getTime(); if (abB <= abA) abB = -1; reopen("ab"); });
        chip(rowOf(hs), "Set B here", false, v -> {
            long t = mp.getTime();
            if (abA < 0) abA = 0;
            if (t <= abA) say("B must be after A"); else abB = t;
            reopen("ab");
        });
        chip(rowOf(hs), "Clear", false, v -> { abA = abB = -1; reopen("ab"); });
        panelBody.addView(label("JUMP"));
        HorizontalScrollView j = chipRow();
        chip(rowOf(j), "−1 min", false, v -> skip(-60000));
        chip(rowOf(j), "−30 s", false, v -> skip(-30000));
        chip(rowOf(j), "+30 s", false, v -> skip(30000));
        chip(rowOf(j), "+1 min", false, v -> skip(60000));
        chip(rowOf(j), "+5 min", false, v -> skip(300000));
    }

    private void panelSleep() {
        panelTitle.setText("Sleep timer");
        HorizontalScrollView hs = chipRow();
        int[] mins = {0, 10, 20, 30, 45, 60, 90};
        for (int m : mins) {
            final int mm = m;
            chip(rowOf(hs), m == 0 ? "Off" : m + " min", false, v -> {
                sleepEnd = false;
                sleepAt = mm == 0 ? 0 : System.currentTimeMillis() + mm * 60000L;
                say(mm == 0 ? "Sleep timer off" : "Pausing in " + mm + " min");
                closePanel();
            });
        }
        HorizontalScrollView e = chipRow();
        e.setPadding(0, dp(10), 0, 0);
        chip(rowOf(e), "After this video", sleepEnd, v -> { sleepEnd = true; sleepAt = 0; say("Will stop after this video"); closePanel(); });
    }

    private void panelMarks() {
        panelTitle.setText("Bookmarks");
        final Item it = q.get(cur);
        HorizontalScrollView hs = chipRow();
        chip(rowOf(hs), "⚑ Add bookmark here", false, v -> {
            double t = Math.round(mp.getTime() / 100.0) / 10.0;
            if (!it.marks.contains(t)) it.marks.add(t);
            Collections.sort(it.marks);
            putResult(it, mp.getTime(), length);
            reopen("marks");
        });
        if (it.marks.isEmpty()) textLine("No bookmarks yet.", 0xFF9A9AB0, 13);
        for (int i = 0; i < it.marks.size(); i++) {
            final int ix = i;
            final double t = it.marks.get(i);
            LinearLayout r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            TextView go = new TextView(this);
            go.setText("⚑  " + fmt((long) (t * 1000)));
            go.setTextColor(Color.WHITE);
            go.setTextSize(15);
            go.setPadding(0, dp(10), 0, dp(10));
            go.setOnClickListener(v -> { mp.setTime((long) (t * 1000)); closePanel(); });
            TextView del = btn("✕", 14);
            del.setOnClickListener(v -> { it.marks.remove(ix); putResult(it, mp.getTime(), length); reopen("marks"); });
            r.addView(go, new LinearLayout.LayoutParams(0, -2, 1f));
            r.addView(del);
            panelBody.addView(r);
        }
        if (it.key == null) textLine("Bookmarks are kept for videos in your gallery.", 0xFF9A9AB0, 12);
    }

    private void panelQueue() {
        panelTitle.setText("Up next");
        HorizontalScrollView hs = chipRow();
        chip(rowOf(hs), "Loop: " + cfgLoop, false, v -> { cfgLoop = "off".equals(cfgLoop) ? "all" : "all".equals(cfgLoop) ? "one" : "off"; reopen("queue"); });
        chip(rowOf(hs), "Shuffle: " + (cfgShuffle ? "on" : "off"), cfgShuffle, v -> { cfgShuffle = !cfgShuffle; reopen("queue"); });
        chip(rowOf(hs), "Auto-next: " + (cfgAuto ? "on" : "off"), cfgAuto, v -> { cfgAuto = !cfgAuto; reopen("queue"); });
        for (int i = 0; i < q.size(); i++) {
            final int ix = i;
            TextView t = new TextView(this);
            t.setText((i == cur ? "▶  " : (i + 1) + ".  ") + q.get(i).name);
            t.setTextColor(i == cur ? ACCENT : Color.WHITE);
            t.setTextSize(14);
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            t.setPadding(0, dp(10), 0, dp(10));
            t.setOnClickListener(v -> { closePanel(); startItem(ix, q.get(ix).resume); });
            panelBody.addView(t);
        }
    }

    private void panelDecoder() {
        panelTitle.setText("Decoder");
        HorizontalScrollView hs = chipRow();
        String[] n = {"Software", "Hardware", "Hardware+"};
        for (int i = 0; i < 3; i++) {
            final int ix = i;
            chip(rowOf(hs), n[i], hw == i, v -> {
                hw = ix;
                prefs.edit().putInt("hw", ix).apply();
                long t = mp.getTime();
                closePanel();
                startItem(cur, t);
            });
        }
        textLine("Hardware is fastest and saves battery. If a video shows green or black frames, switch to Software. If hardware cannot play a file, NerdyPlayer already retries it in software automatically.", 0xFF9A9AB0, 12);
    }

    private void panelInfo() {
        panelTitle.setText("Details");
        Item it = q.get(cur);
        textLine(it.name, Color.WHITE, 15);
        String[] d = {
                "Resolution   " + (vw > 0 ? vw + " × " + vh : "…"),
                "Duration       " + fmt(length),
                "Decoder        " + (hw == 0 ? "Software" : hw == 1 ? "Hardware" : "Hardware+"),
                "Speed           " + fmtRate(rate),
                "Engine          VLC (libVLC)"};
        for (String s : d) textLine(s, 0xFFC8C8DC, 13);
    }

    /* ============================== features ============================== */

    private void setRate(float r) {
        rate = Math.max(0.25f, Math.min(4f, Math.round(r * 100f) / 100f));
        if (mp != null) mp.setRate(rate);
        btnSpeed.setText(fmtRate(rate));
        say(fmtRate(rate));
    }

    private String fmtRate(float r) {
        String s = String.format(Locale.US, "%.2f", r);
        if (s.endsWith("0")) s = s.substring(0, s.length() - 1);
        if (s.endsWith(".0")) s = s.substring(0, s.length() - 2);
        return s + "×";
    }

    private void setAspect(int ix) {
        aspectIx = ix;
        prefs.edit().putInt("aspect", ix).apply();
        if (mp != null) mp.setVideoScale(ASPECTS[ix]);
        say(ASPECT_NAMES[ix]);
    }

    private void resetView() {
        quarter = 0; fine = 0; zoom = 1; panX = panY = 0; flipH = flipV = false;
        if (root != null) applyTransform();
    }

    private void applyTransform() {
        if (root == null || video == null) return;
        int w = root.getWidth(), hh = root.getHeight();
        if (w == 0 || hh == 0) return;
        boolean odd = quarter % 2 != 0;
        int nw = odd ? hh : w, nh = odd ? w : hh;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) video.getLayoutParams();
        if (lp.width != nw || lp.height != nh) {
            lp.width = nw;
            lp.height = nh;
            lp.gravity = Gravity.CENTER;
            video.setLayoutParams(lp);
        }
        video.setRotation(quarter * 90f + fine);
        // when rotated a quarter turn, the view's own X axis is the screen's Y axis
        float sx = zoom * (odd ? (flipV ? -1 : 1) : (flipH ? -1 : 1));
        float sy = zoom * (odd ? (flipH ? -1 : 1) : (flipV ? -1 : 1));
        video.setScaleX(sx);
        video.setScaleY(sy);
        video.setTranslationX(panX);
        video.setTranslationY(panY);
    }

    private TextureView findTv(View v) {
        if (v instanceof TextureView) return (TextureView) v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                TextureView t = findTv(g.getChildAt(i));
                if (t != null) return t;
            }
        }
        return null;
    }

    private void applyPicture() {
        prefs.edit().putInt("bri", bri).putInt("con", con).putInt("sat", sat).putInt("hue", hue).putInt("warm", warm).apply();
        if (tv == null && video != null) tv = findTv(video);
        if (tv == null) return;
        boolean identity = bri == 0 && con == 100 && sat == 100 && hue == 0 && warm == 0 && !sepia && !invert;
        if (identity) { tv.setLayerPaint(null); return; }
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(sat / 100f);
        if (hue != 0) {
            double r = Math.toRadians(hue);
            float c = (float) Math.cos(r), s = (float) Math.sin(r);
            float lr = 0.213f, lg = 0.715f, lb = 0.072f;
            cm.postConcat(new ColorMatrix(new float[]{
                    lr + c * (1 - lr) + s * (-lr), lg + c * (-lg) + s * (-lg), lb + c * (-lb) + s * (1 - lb), 0, 0,
                    lr + c * (-lr) + s * (0.143f), lg + c * (1 - lg) + s * (0.140f), lb + c * (-lb) + s * (-0.283f), 0, 0,
                    lr + c * (-lr) + s * (-(1 - lr)), lg + c * (-lg) + s * (lg), lb + c * (1 - lb) + s * (lb), 0, 0,
                    0, 0, 0, 1, 0}));
        }
        float k = con / 100f;
        float t = 255f * (bri / 100f) + 128f * (1 - k);
        cm.postConcat(new ColorMatrix(new float[]{k, 0, 0, 0, t, 0, k, 0, 0, t, 0, 0, k, 0, t, 0, 0, 0, 1, 0}));
        if (warm != 0) {
            float rs = 1f + warm / 200f, bs = 1f - warm / 200f;
            cm.postConcat(new ColorMatrix(new float[]{rs, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, bs, 0, 0, 0, 0, 0, 1, 0}));
        }
        if (sepia) {
            cm.postConcat(new ColorMatrix(new float[]{0.393f, 0.769f, 0.189f, 0, 0, 0.349f, 0.686f, 0.168f, 0, 0, 0.272f, 0.534f, 0.131f, 0, 0, 0, 0, 0, 1, 0}));
        }
        if (invert) {
            cm.postConcat(new ColorMatrix(new float[]{-1, 0, 0, 0, 255, 0, -1, 0, 0, 255, 0, 0, -1, 0, 255, 0, 0, 0, 1, 0}));
        }
        Paint p = new Paint();
        p.setColorFilter(new ColorMatrixColorFilter(cm));
        tv.setLayerPaint(p);
    }

    private void capture() {
        if (tv == null) { say("Capture is not available here"); return; }
        if (vaultMode) { say("Capture is off inside the vault"); return; }
        try {
            Bitmap b = tv.getBitmap();
            if (b == null) { say("Capture failed"); return; }
            String name = "NerdyPlayer_" + System.currentTimeMillis() + ".jpg";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NerdyPlayer");
                Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                if (u == null) { say("Capture failed"); return; }
                try (OutputStream o = getContentResolver().openOutputStream(u)) { b.compress(Bitmap.CompressFormat.JPEG, 95, o); }
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "NerdyPlayer");
                //noinspection ResultOfMethodCallIgnored
                dir.mkdirs();
                File f = new File(dir, name);
                try (FileOutputStream o = new FileOutputStream(f)) { b.compress(Bitmap.CompressFormat.JPEG, 95, o); }
                android.media.MediaScannerConnection.scanFile(this, new String[]{f.getAbsolutePath()}, null, null);
            }
            say("Saved to Pictures/NerdyPlayer");
        } catch (Throwable t) {
            say("Capture failed");
        }
    }

    private void applyOrientation() {
        int o;
        switch (orientIx) {
            case 1: o = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR; break;
            case 2: o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE; break;
            case 3: o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT; break;
            case 4: o = ActivityInfo.SCREEN_ORIENTATION_LOCKED; break;
            default:
                if (cfgAutoLand && vw > 0 && vh > 0) o = vw >= vh ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT;
                else o = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR;
                break;
        }
        try { setRequestedOrientation(o); } catch (Exception ignored) { }
    }

    private void enterPip() {
        if (Build.VERSION.SDK_INT < 26) { say("Picture-in-picture is not available"); return; }
        try {
            int w = vw > 0 ? vw : 16, hh = vh > 0 ? vh : 9;
            double r = (double) w / hh;
            if (r > 2.39) { w = 239; hh = 100; } else if (r < 0.42) { w = 100; hh = 239; }
            closePanel();
            enterPictureInPictureMode(new PictureInPictureParams.Builder().setAspectRatio(new Rational(w, hh)).build());
        } catch (Throwable ignored) { }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (!ignoreLeave && mp != null && mp.isPlaying() && !locked) enterPip();
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isIn, Configuration cfg) {
        super.onPictureInPictureModeChanged(isIn, cfg);
        inPip = isIn;
        if (isIn) { closePanel(); showUi(false); } else showUi(true);
    }

    private void lockControls() {
        locked = true;
        showUi(false);
        lockHint.setVisibility(View.VISIBLE);
        h.postDelayed(() -> lockHint.setVisibility(View.GONE), 2500);
    }

    private void setKeepOn(boolean on) {
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void applySecure() {
        int m = new Guard(this).secureMode();
        if (m == 2 || (m == 1 && vaultMode)) getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    /* ============================== playback helpers ============================== */

    private static String fmt(long ms) {
        long s = Math.max(0, ms / 1000);
        long hh = s / 3600, mm = (s % 3600) / 60, ss = s % 60;
        return hh > 0 ? String.format(Locale.US, "%d:%02d:%02d", hh, mm, ss) : String.format(Locale.US, "%d:%02d", mm, ss);
    }

    private void update() {
        if (mp == null) return;
        long t = mp.getTime();
        long len = mp.getLength();
        if (len > 0 && len != length) { length = len; tLen.setText(fmt(len)); }
        if (abA >= 0 && abB > abA && t >= abB) mp.setTime(abA);
        if (sleepAt > 0 && System.currentTimeMillis() >= sleepAt) {
            sleepAt = 0;
            mp.pause();
            say("Sleep timer: paused");
        }
        if (!dragging && uiOn) {
            tNow.setText(fmt(t));
            if (length > 0) seek.setProgress((int) (1000L * t / length));
        }
        long now = System.currentTimeMillis();
        if (mp.isPlaying() && now - lastSave > 5000) { lastSave = now; saveResult(); }
    }

    private void toggle() {
        if (mp == null) return;
        if (mp.isPlaying()) mp.pause(); else mp.play();
        armHide();
    }

    private void skip(long d) {
        if (mp == null) return;
        long t = Math.max(0, mp.getTime() + d);
        if (length > 0) t = Math.min(t, Math.max(0, length - 300));
        mp.setTime(t);
        say((d > 0 ? "+" : "−") + fmt(Math.abs(d)));
    }

    private void nextItem() {
        if (q.size() < 2) { say("No next video"); return; }
        int n = cfgShuffle ? rnd.nextInt(q.size()) : (cur + 1) % q.size();
        startItem(n, q.get(n).resume);
    }

    private void prevItem() {
        if (mp != null && mp.getTime() > 4000) { mp.setTime(0); return; }
        if (q.size() < 2) { if (mp != null) mp.setTime(0); return; }
        int n = (cur - 1 + q.size()) % q.size();
        startItem(n, q.get(n).resume);
    }

    private void say(String t) {
        hud.setText(t);
        hud.setVisibility(View.VISIBLE);
        h.removeCallbacks(hudOff);
        h.postDelayed(hudOff, 900);
    }

    private void showUi(boolean on) {
        if (locked && on) return;
        uiOn = on;
        int v = on ? View.VISIBLE : View.GONE;
        topBar.setVisibility(v);
        botBar.setVisibility(v);
        if (on) armHide();
        applySystemBars();
    }

    private void armHide() {
        h.removeCallbacks(hideUi);
        if (uiOn && !panelOpen && mp != null && mp.isPlaying()) h.postDelayed(hideUi, hideSecs * 1000L);
    }

    private void applySystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) applySystemBars();
    }

    @Override
    public void onBackPressed() {
        if (panelOpen) { closePanel(); return; }
        if (locked) { say("Locked · tap 3 times to unlock"); return; }
        finish();
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent e) {
        if (panelOpen || locked) return super.onKeyDown(code, e);
        switch (code) {
            case KeyEvent.KEYCODE_SPACE:
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: toggle(); return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD: skip(seekStep * 1000L); return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_MEDIA_REWIND: skip(-seekStep * 1000L); return true;
            case KeyEvent.KEYCODE_MEDIA_NEXT: nextItem(); return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS: prevItem(); return true;
            default: return super.onKeyDown(code, e);
        }
    }

    /* ============================== touch ============================== */

    private float downX, downY, lastX, lastY, startBright, startVolF;
    private long startTime, seekTarget;
    private int mode; // 0 none, 1 seek, 2 brightness, 3 volume, 4 pan, -1 ignore (pinch)
    private int taps;
    private long lastTap;

    private void gestures() {
        final AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        final GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                if (panelOpen) { closePanel(); return true; }
                showUi(!uiOn);
                return true;
            }
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (!cfgDtap) return true;
                float w = root.getWidth();
                if (e.getX() < w * 0.33f) skip(-seekStep * 1000L);
                else if (e.getX() > w * 0.67f) skip(seekStep * 1000L);
                else toggle();
                return true;
            }
            @Override public void onLongPress(MotionEvent e) {
                if (!cfgHold || mp == null || mode != 0) return;
                mp.setRate(2f);
                say("2×");
                longHeld = true;
            }
        });
        final ScaleGestureDetector sgd = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                zoom = Math.max(0.5f, Math.min(5f, zoom * d.getScaleFactor()));
                applyTransform();
                say(Math.round(zoom * 100) + "%");
                return true;
            }
        });
        root.setOnTouchListener((v, e) -> {
            if (locked) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    long now = System.currentTimeMillis();
                    taps = now - lastTap < 450 ? taps + 1 : 1;
                    lastTap = now;
                    if (taps >= 3) { locked = false; taps = 0; showUi(true); say("Unlocked"); }
                }
                return true;
            }
            if (inPip) return true;
            sgd.onTouchEvent(e);
            if (e.getPointerCount() > 1 || sgd.isInProgress()) { mode = -1; return true; }
            gd.onTouchEvent(e);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = lastX = e.getX(); downY = lastY = e.getY(); mode = 0;
                    startTime = mp != null ? mp.getTime() : 0;
                    startBright = getWindow().getAttributes().screenBrightness;
                    if (startBright < 0) startBright = 0.5f;
                    int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                    startVolF = (am.getStreamVolume(AudioManager.STREAM_MUSIC) / (float) Math.max(1, max)) + (volBoost - 100) / 100f;
                    break;
                case MotionEvent.ACTION_MOVE: {
                    if (mode == -1) break;
                    float dx = e.getX() - downX, dy = e.getY() - downY;
                    if (mode == 0 && !longHeld) {
                        if (zoom > 1.02f && (Math.abs(dx) > dp(10) || Math.abs(dy) > dp(10))) mode = 4;
                        else if (!cfgGest) { /* gestures off */ }
                        else if (Math.abs(dx) > dp(24) && Math.abs(dx) > Math.abs(dy) * 1.5f) { mode = 1; seekTarget = startTime; }
                        else if (Math.abs(dy) > dp(24) && Math.abs(dy) > Math.abs(dx) * 1.5f) mode = downX < root.getWidth() / 2f ? 2 : 3;
                    }
                    if (mode == 4) {
                        panX += e.getX() - lastX;
                        panY += e.getY() - lastY;
                        applyTransform();
                    } else if (mode == 1 && mp != null && length > 0) {
                        seekTarget = Math.max(0, Math.min(length, startTime + (long) (dx / root.getWidth() * 120000f)));
                        say(fmt(seekTarget) + "  (" + (seekTarget >= startTime ? "+" : "−") + fmt(Math.abs(seekTarget - startTime)) + ")");
                    } else if (mode == 2) {
                        float b = Math.max(0.02f, Math.min(1f, startBright - dy / root.getHeight()));
                        WindowManager.LayoutParams lp = getWindow().getAttributes();
                        lp.screenBrightness = b;
                        getWindow().setAttributes(lp);
                        say("☀ " + Math.round(b * 100) + "%");
                    } else if (mode == 3) {
                        float f = Math.max(0f, Math.min(2f, startVolF - dy / root.getHeight() * 1.6f));
                        int mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(Math.min(f, 1f) * mx), 0);
                        volBoost = f > 1f ? 100 + Math.round((f - 1f) * 100f) : 100;
                        if (mp != null) mp.setVolume(volBoost);
                        say("🔊 " + Math.round(f * 100) + "%");
                    }
                    lastX = e.getX(); lastY = e.getY();
                    break;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (mode == 1 && mp != null && e.getActionMasked() == MotionEvent.ACTION_UP) mp.setTime(seekTarget);
                    if (longHeld && mp != null) { mp.setRate(rate); longHeld = false; hud.setVisibility(View.GONE); }
                    mode = 0;
                    break;
                default:
                    break;
            }
            return true;
        });
    }
}
