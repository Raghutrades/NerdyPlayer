package com.nerdyintruder.nerdyplayer;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.RecoverableSecurityException;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * NerdyPlayer shell. The whole gallery UI is a local web app (assets/www) served from a virtual https
 * origin. This class does what a web page cannot: read the media library, make thumbnails, delete files,
 * run the encrypted vault, check the PIN / fingerprint, and start the native video player.
 */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final int REQ_PERM = 51, REQ_DEL = 52, REQ_DEL29 = 53;

    private WebView web;
    private SharedPreferences sp;
    private Vault vault;
    private final ExecutorService io = Executors.newFixedThreadPool(3);
    private final Map<String, Uri> ext = new ConcurrentHashMap<>();
    private String pendingExt;

    private boolean internalNav;
    private long leftAt;

    // delete queue
    private final List<Uri> delQueue = new ArrayList<>();
    private int delTotal;
    private String delKind = "delete";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("np", MODE_PRIVATE);
        vault = new Vault(this);
        Guard.appLock = sp.getBoolean("applock", false) && hasPin();
        if (sp.getBoolean("secure", false)) getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0B0D14"));
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/api/", this::api)
                .addPathHandler("/thumb/", this::thumb)
                .addPathHandler("/img/", this::image)
                .addPathHandler("/vt/", p -> vaultStream(p, true))
                .addPathHandler("/vi/", p -> vaultStream(p, false))
                .addPathHandler("/ext/", this::external)
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !HOST.equals(r.getUrl().getHost()); // never leave the app
            }
        });
        web.addJavascriptInterface(new Bridge(), "Native");
        collect(getIntent());
        web.loadUrl("https://" + HOST + "/assets/www/index.html");
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        collect(i);
        js("Np.onExt&&Np.onExt()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        leftAt = SystemClock.elapsedRealtime();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (internalNav) { internalNav = false; return; }
        if (leftAt > 0 && Guard.unlocked) {
            long limit = sp.getInt("autolock", 30) * 1000L;
            if (SystemClock.elapsedRealtime() - leftAt >= limit) {
                Guard.unlocked = false;
                js("Np.onLock&&Np.onLock()");
            }
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.Np&&Np.back&&Np.back())?'1':'0'", v -> {
            if (!"\"1\"".equals(v)) finish();
        });
    }

    @Override
    protected void onDestroy() {
        io.shutdown();
        super.onDestroy();
    }

    private void js(String code) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.Np&&" + code, null); });
    }

    private void collect(Intent in) {
        if (in == null || !Intent.ACTION_VIEW.equals(in.getAction()) || in.getData() == null) return;
        String id = UUID.randomUUID().toString().replace("-", "");
        ext.put(id, in.getData());
        pendingExt = id;
        in.setAction(Intent.ACTION_MAIN);
    }

    /* ======================= PIN ======================= */

    private boolean hasPin() { return sp.getString("ph", null) != null; }

    private byte[] hash(String pin, byte[] salt) throws Exception {
        SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        return f.generateSecret(new PBEKeySpec(pin.toCharArray(), salt, 150000, 256)).getEncoded();
    }

    private void savePin(String pin) throws Exception {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        sp.edit().putString("ps", Base64.encodeToString(salt, Base64.NO_WRAP))
                .putString("ph", Base64.encodeToString(hash(pin, salt), Base64.NO_WRAP))
                .putInt("fails", 0).putLong("until", 0).apply();
    }

    /** "ok", "bad:N" (N tries before a pause) or "wait:S" (seconds to wait). */
    private String checkPin(String pin) {
        try {
            long now = System.currentTimeMillis();
            long until = sp.getLong("until", 0);
            if (until > now) return "wait:" + ((until - now + 999) / 1000);
            byte[] salt = Base64.decode(sp.getString("ps", ""), Base64.NO_WRAP);
            byte[] want = Base64.decode(sp.getString("ph", ""), Base64.NO_WRAP);
            byte[] got = hash(pin, salt);
            if (MessageDigest.isEqual(want, got)) {
                sp.edit().putInt("fails", 0).putLong("until", 0).apply();
                return "ok";
            }
            int f = sp.getInt("fails", 0) + 1;
            long pause = f >= 10 ? 1800000L : f >= 7 ? 300000L : f >= 5 ? 30000L : 0;
            sp.edit().putInt("fails", f).putLong("until", pause > 0 ? now + pause : 0).apply();
            return pause > 0 ? "wait:" + (pause / 1000) : "bad:" + (5 - f);
        } catch (Exception e) {
            return "bad:0";
        }
    }

    /* ======================= web routes ======================= */

    private WebResourceResponse resp(String mime, byte[] data, boolean cache) {
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", cache ? "private, max-age=3600" : "no-store");
        return new WebResourceResponse(mime, null, 200, "OK", h, new ByteArrayInputStream(data == null ? new byte[0] : data));
    }

    private WebResourceResponse deny() {
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "no-store");
        return new WebResourceResponse("text/plain", "utf-8", 403, "Locked", h, new ByteArrayInputStream(new byte[0]));
    }

    private WebResourceResponse api(String path) {
        try {
            if (path.equals("media")) {
                if (!Guard.galleryOk()) return deny();
                if (!hasMediaPerm()) return resp("application/json", "[]".getBytes("UTF-8"), false);
                return resp("application/json", Media.list(getContentResolver()).getBytes("UTF-8"), false);
            }
            if (path.equals("vault")) {
                if (!Guard.vaultOk()) return deny();
                return resp("application/json", vault.list().getBytes("UTF-8"), false);
            }
        } catch (Exception ignored) { }
        return null;
    }

    private String[] two(String path) {
        int k = path.indexOf('/');
        return k < 0 ? new String[]{path, ""} : new String[]{path.substring(0, k), path.substring(k + 1)};
    }

    private WebResourceResponse thumb(String path) {
        if (!Guard.galleryOk()) return deny();
        try {
            String[] p = two(path);
            byte[] b = Media.thumb(getContentResolver(), p[0], Long.parseLong(p[1]), 360);
            return b == null ? null : resp("image/jpeg", b, true);
        } catch (Exception e) {
            return null;
        }
    }

    private WebResourceResponse image(String path) {
        if (!Guard.galleryOk()) return deny();
        try {
            long id = Long.parseLong(path);
            Uri u = Media.uri("i", id);
            String mime = getContentResolver().getType(u);
            if (mime == null) mime = "image/jpeg";
            if (mime.contains("heic") || mime.contains("heif") || mime.contains("tiff")) {
                byte[] b = Media.jpegFrom(getContentResolver(), u);
                return b == null ? null : resp("image/jpeg", b, false);
            }
            InputStream in = getContentResolver().openInputStream(u);
            if (in == null) return null;
            Map<String, String> h = new HashMap<>();
            h.put("Cache-Control", "private, max-age=600");
            return new WebResourceResponse(mime, null, 200, "OK", h, in);
        } catch (Exception e) {
            return null;
        }
    }

    private WebResourceResponse external(String path) {
        try {
            Uri u = ext.get(path);
            if (u == null) return null;
            InputStream in = getContentResolver().openInputStream(u);
            if (in == null) return null;
            String mime = getContentResolver().getType(u);
            return new WebResourceResponse(mime == null ? "image/jpeg" : mime, null, 200, "OK", new HashMap<>(), in);
        } catch (Exception e) {
            return null;
        }
    }

    private WebResourceResponse vaultStream(String uid, boolean thumb) {
        if (!Guard.vaultOk()) return deny();
        try {
            JSONObject e = vault.entry(uid);
            if (e == null) return null;
            java.io.File f = thumb ? new java.io.File(vault.fileFor(uid).getPath() + ".t") : vault.fileFor(uid);
            if (!f.exists()) return null;
            Map<String, String> h = new HashMap<>();
            h.put("Cache-Control", "no-store");
            return new WebResourceResponse(thumb ? "image/jpeg" : e.optString("m", "image/jpeg"), null, 200, "OK", h, vault.openDec(f));
        } catch (Exception e) {
            return null;
        }
    }

    /* ======================= permissions ======================= */

    private boolean hasMediaPerm() {
        if (Build.VERSION.SDK_INT >= 33)
            return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void askPerm() {
        List<String> l = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(Manifest.permission.READ_MEDIA_IMAGES);
            l.add(Manifest.permission.READ_MEDIA_VIDEO);
        } else {
            l.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            if (Build.VERSION.SDK_INT <= 28) l.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        internalNav = true;
        requestPermissions(l.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_PERM) js("Np.onPerm&&Np.onPerm(" + hasMediaPerm() + ")");
    }

    /* ======================= deleting ======================= */

    private void startDelete(List<Uri> uris, String kind) {
        delQueue.clear();
        delQueue.addAll(uris);
        delTotal = uris.size();
        delKind = kind;
        if (uris.isEmpty()) { done(kind, true, 0, ""); return; }
        internalNav = true;
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                IntentSender sender = MediaStore.createDeleteRequest(getContentResolver(), uris).getIntentSender();
                startIntentSenderForResult(sender, REQ_DEL, null, 0, 0, 0);
            } else {
                stepDelete();
            }
        } catch (Exception e) {
            done(kind, false, 0, "Could not start delete");
        }
    }

    /** Android 10 and older: delete one by one; Android 10 may ask permission per file. */
    private void stepDelete() {
        while (!delQueue.isEmpty()) {
            Uri u = delQueue.get(0);
            try {
                getContentResolver().delete(u, null, null);
                delQueue.remove(0);
            } catch (RecoverableSecurityException e) {
                try {
                    internalNav = true;
                    startIntentSenderForResult(e.getUserAction().getActionIntent().getIntentSender(), REQ_DEL29, null, 0, 0, 0);
                    return;
                } catch (Exception x) {
                    delQueue.clear();
                    done(delKind, false, delTotal, "Not allowed");
                    return;
                }
            } catch (Exception e) {
                delQueue.remove(0);
            }
        }
        done(delKind, true, delTotal, "");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_DEL) {
            done(delKind, res == RESULT_OK, delTotal, res == RESULT_OK ? "" : "cancelled");
        } else if (req == REQ_DEL29) {
            if (res == RESULT_OK) stepDelete();
            else { delQueue.clear(); done(delKind, false, delTotal, "cancelled"); }
        }
    }

    private void done(String kind, boolean ok, int n, String msg) {
        js("Np.onDone&&Np.onDone(" + JSONObject.quote(kind) + "," + ok + "," + n + "," + JSONObject.quote(msg) + ")");
    }

    /* ======================= biometric ======================= */

    private boolean bioReady() {
        if (Build.VERSION.SDK_INT < 30) return false;
        try {
            BiometricManager m = getSystemService(BiometricManager.class);
            return m != null && m.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS;
        } catch (Exception e) {
            return false;
        }
    }

    private void startBio() {
        if (Build.VERSION.SDK_INT < 30 || !bioReady()) { js("Np.onBio&&Np.onBio(false)"); return; }
        try {
            BiometricPrompt bp = new BiometricPrompt.Builder(this)
                    .setTitle("Unlock NerdyPlayer")
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                    .setNegativeButton("Use PIN", getMainExecutor(), (d, w) -> js("Np.onBio&&Np.onBio(false)"))
                    .build();
            bp.authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                    Guard.unlocked = true;
                    js("Np.onBio&&Np.onBio(true)");
                }

                @Override
                public void onAuthenticationError(int code, CharSequence msg) {
                    js("Np.onBio&&Np.onBio(false)");
                }
            });
        } catch (Exception e) {
            js("Np.onBio&&Np.onBio(false)");
        }
    }

    /* ======================= bridge ======================= */

    private class Bridge {
        @JavascriptInterface
        public String state() {
            try {
                JSONObject o = new JSONObject();
                o.put("pin", hasPin());
                o.put("applock", Guard.appLock);
                o.put("unlocked", Guard.unlocked);
                o.put("bio", bioReady());
                o.put("perm", hasMediaPerm());
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("secure", sp.getBoolean("secure", false));
                o.put("autolock", sp.getInt("autolock", 30));
                o.put("ext", pendingExt == null ? "" : pendingExt);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface public void askPerm() { runOnUiThread(MainActivity.this::askPerm); }

        @JavascriptInterface
        public String verify(String pin) {
            String r = checkPin(pin == null ? "" : pin);
            if ("ok".equals(r)) Guard.unlocked = true;
            return r;
        }

        /** Set or change the PIN. Needs the old PIN when one exists. */
        @JavascriptInterface
        public String setPin(String oldPin, String newPin) {
            if (newPin == null || newPin.length() < 4 || newPin.length() > 12) return "short";
            if (hasPin()) {
                String r = checkPin(oldPin == null ? "" : oldPin);
                if (!"ok".equals(r)) return r;
            }
            try {
                savePin(newPin);
                Guard.unlocked = true;
                return "ok";
            } catch (Exception e) {
                return "error";
            }
        }

        @JavascriptInterface
        public String removePin(String pin) {
            String r = checkPin(pin == null ? "" : pin);
            if (!"ok".equals(r)) return r;
            sp.edit().remove("ph").remove("ps").putBoolean("applock", false).apply();
            Guard.appLock = false;
            return "ok";
        }

        @JavascriptInterface public void lock() { Guard.unlocked = false; }

        @JavascriptInterface public void bio() { runOnUiThread(MainActivity.this::startBio); }

        @JavascriptInterface
        public void setFlag(String name, boolean v) {
            if (name.equals("applock")) {
                if (v && !hasPin()) return;
                Guard.appLock = v;
                sp.edit().putBoolean("applock", v).apply();
            } else if (name.equals("secure")) {
                sp.edit().putBoolean("secure", v).apply();
                runOnUiThread(() -> {
                    if (v) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
                    else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
                });
            }
        }

        @JavascriptInterface public void setInt(String name, int v) { if (name.equals("autolock")) sp.edit().putInt("autolock", v).apply(); }

        @JavascriptInterface
        public void bars(String color, boolean lightBar) {
            runOnUiThread(() -> {
                try {
                    int c = Color.parseColor(color);
                    getWindow().setStatusBarColor(c);
                    getWindow().setNavigationBarColor(c);
                    View d = getWindow().getDecorView();
                    int f = d.getSystemUiVisibility();
                    if (lightBar) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    else f &= ~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
                    d.setSystemUiVisibility(f);
                } catch (Exception ignored) { }
            });
        }

        /** Player preferences the native player reads (resume, auto picture-in-picture). */
        @JavascriptInterface
        public void setCfg(String k, boolean v) {
            if (k.equals("resume") || k.equals("autopip")) getSharedPreferences("np_cfg", MODE_PRIVATE).edit().putBoolean(k, v).apply();
        }

        @JavascriptInterface
        public void clearResume() { getSharedPreferences("resume", MODE_PRIVATE).edit().clear().apply(); }

        @JavascriptInterface
        public void awake(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        /** Only the author's Instagram can be opened, and it opens in the Instagram app or browser, not here. */
        @JavascriptInterface
        public void open(String url) {
            if (url == null || !url.startsWith("https://www.instagram.com/nerdyintruder")) return;
            runOnUiThread(() -> {
                try { internalNav = true; startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface public void toast(String m) { runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show()); }

        @JavascriptInterface public void exit() { runOnUiThread(MainActivity.this::finish); }

        /** items: [["i",123],["v",45]] */
        @JavascriptInterface
        public void del(String json) {
            if (!Guard.galleryOk()) return;
            try {
                JSONArray a = new JSONArray(json);
                List<Uri> l = new ArrayList<>();
                for (int i = 0; i < a.length(); i++) l.add(Media.uri(a.getJSONArray(i).getString(0), a.getJSONArray(i).getLong(1)));
                runOnUiThread(() -> startDelete(l, "delete"));
            } catch (Exception e) {
                done("delete", false, 0, "bad request");
            }
        }

        /** Copy into the encrypted vault, then ask Android to delete the originals. */
        @JavascriptInterface
        public void hide(String json) {
            if (!Guard.vaultOk()) { done("hide", false, 0, "locked"); return; }
            io.execute(() -> {
                try {
                    JSONArray a = new JSONArray(json);
                    List<Uri> ok = new ArrayList<>();
                    for (int i = 0; i < a.length(); i++) {
                        String t = a.getJSONArray(i).getString(0);
                        long id = a.getJSONArray(i).getLong(1);
                        try {
                            if (vault.hide(getContentResolver(), t, id)) ok.add(Media.uri(t, id));
                        } catch (Exception ignored) { }
                    }
                    if (ok.isEmpty()) { done("hide", false, 0, "Could not copy into the vault"); return; }
                    runOnUiThread(() -> startDelete(ok, "hide"));
                } catch (Exception e) {
                    done("hide", false, 0, "bad request");
                }
            });
        }

        @JavascriptInterface
        public void restore(String json) {
            if (!Guard.vaultOk()) return;
            io.execute(() -> {
                int n = 0;
                try {
                    JSONArray a = new JSONArray(json);
                    for (int i = 0; i < a.length(); i++) {
                        try { if (vault.restore(a.getString(i))) n++; } catch (Exception ignored) { }
                    }
                } catch (Exception ignored) { }
                done("restore", n > 0, n, "");
            });
        }

        @JavascriptInterface
        public void vdelete(String json) {
            if (!Guard.vaultOk()) return;
            io.execute(() -> {
                int n = 0;
                try {
                    JSONArray a = new JSONArray(json);
                    for (int i = 0; i < a.length(); i++) {
                        try { vault.remove(a.getString(i)); n++; } catch (Exception ignored) { }
                    }
                } catch (Exception ignored) { }
                done("vdelete", true, n, "");
            });
        }

        /** Delete the whole vault and its key. Needs the PIN. */
        @JavascriptInterface
        public String wipe(String pin) {
            String r = checkPin(pin == null ? "" : pin);
            if (!"ok".equals(r)) return r;
            io.execute(() -> { vault.wipeAll(); done("wipe", true, 0, ""); });
            return "ok";
        }

        @JavascriptInterface
        public void share(String type, long id) {
            if (!Guard.galleryOk()) return;
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("v".equals(type) ? "video/*" : "image/*");
                    i.putExtra(Intent.EXTRA_STREAM, Media.uri(type, id));
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    internalNav = true;
                    startActivity(Intent.createChooser(i, "Share"));
                } catch (ActivityNotFoundException ignored) { }
            });
        }

        /** {"i":0,"items":[{"s":"m:12","t":"Title"},{"s":"v:abc","t":"Title"}]} */
        @JavascriptInterface
        public void play(String json) {
            runOnUiThread(() -> {
                try {
                    JSONObject o = new JSONObject(json);
                    JSONArray a = o.getJSONArray("items");
                    ArrayList<String> src = new ArrayList<>(), titles = new ArrayList<>();
                    for (int i = 0; i < a.length(); i++) {
                        String s = a.getJSONObject(i).getString("s");
                        if (s.startsWith("v:") && !Guard.vaultOk()) continue;
                        src.add(s);
                        titles.add(a.getJSONObject(i).optString("t", "Video"));
                    }
                    if (src.isEmpty()) return;
                    Intent i = new Intent(MainActivity.this, PlayerActivity.class);
                    i.putStringArrayListExtra("src", src);
                    i.putStringArrayListExtra("titles", titles);
                    i.putExtra("idx", Math.max(0, Math.min(o.optInt("i", 0), src.size() - 1)));
                    internalNav = true;
                    startActivity(i);
                } catch (Exception ignored) { }
            });
        }
    }
}
