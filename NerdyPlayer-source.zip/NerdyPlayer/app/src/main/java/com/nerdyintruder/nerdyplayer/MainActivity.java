package com.nerdyintruder.nerdyplayer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.KeyguardManager;
import android.app.PictureInPictureParams;
import android.app.RecoverableSecurityException;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Base64;
import android.util.Rational;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * NerdyPlayer shell. The whole app (gallery, video player, image viewer, vault screens, About)
 * is a local web app in assets/www. This class does what a web page cannot:
 *   - list the phone's photos and videos (MediaStore) and stream them to the page, with seeking,
 *   - ask for permission, delete / trash files through the system confirmation dialog,
 *   - the PIN, fingerprint and the encrypted vault (see Guard and Vault),
 *   - brightness, volume, screen rotation, picture-in-picture, screenshots protection.
 * There is no INTERNET permission: nothing can leave the phone.
 */
public class MainActivity extends Activity {

    private static final int REQ_PERM = 5101;
    private static final int REQ_PICK = 5102;
    private static final int REQ_SENDER = 5103;
    private static final int REQ_RS = 5104;
    private static final int REQ_ANY = 5105;
    private static final int REQ_VLC = 5106;
    private static final int REQ_DEV = 5105;
    private static final String HOST = "appassets.androidplatform.net";

    private WebView web;
    private ValueCallback<Uri[]> pickCallback;
    private final Map<String, Uri> shared = new ConcurrentHashMap<>();
    private final List<JSONObject> pending = new ArrayList<>();

    private Guard guard;
    private Media media;
    private Vault vault;

    // state
    private boolean lightBars;
    private boolean fullscreen;
    private boolean appFull = true;
    private int externalOps;
    private long pausedAt;
    private boolean inPip;
    private boolean pipArmed;
    private int pipW = 16, pipH = 9;
    private boolean secureNow;
    private boolean vaultScreen;
    private int origNavColor;

    // a system dialog (delete / trash) in flight
    private static final class Op {
        String kind;
        JSONArray keys;
        List<Uri> remaining;
    }

    private Op op;

    // saving a picture into the gallery
    private File saveFile;
    private FileOutputStream saveOut;
    private String saveName = "image.jpg", saveMime = "image/jpeg";
    private boolean saveVideo;
    private String saveError;

    // shake to lock
    private SensorManager sensors;
    private final SensorEventListener shakeListener = new SensorEventListener() {
        private long last;
        private int count;

        @Override public void onSensorChanged(SensorEvent e) {
            float x = e.values[0], y = e.values[1], z = e.values[2];
            double g = Math.sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH;
            if (g > 2.6) {
                long now = SystemClock.elapsedRealtime();
                if (now - last > 150 && now - last < 1000) count++;
                else if (now - last >= 1000) count = 1;
                last = now;
                if (count >= 3) {
                    count = 0;
                    runOnUiThread(MainActivity.this::lockNow);
                }
            }
        }

        @Override public void onAccuracyChanged(Sensor s, int a) { }
    };

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        guard = new Guard(this);
        media = new Media(this);
        vault = new Vault(this);
        sensors = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0B0B14"));
        setContentView(web);
        appFull = getSharedPreferences("ui", MODE_PRIVATE).getBoolean("appFull", true);
        applySystemUi();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setSaveFormData(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (!HOST.equals(u.getHost())) return reply(403, "Forbidden", new byte[0], "text/plain");
                String path = u.getPath() == null ? "" : u.getPath();
                if (path.startsWith("/assets/")) {
                    WebResourceResponse r = loader.shouldInterceptRequest(u);
                    return r != null ? r : reply(404, "Not Found", new byte[0], "text/plain");
                }
                try {
                    WebResourceResponse r = route(path, u, request.getRequestHeaders());
                    if (r != null) return r;
                } catch (Exception ignored) {
                }
                return reply(404, "Not Found", new byte[0], "text/plain");
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (pickCallback != null) pickCallback.onReceiveValue(null);
                pickCallback = cb;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                String[] acc = params.getAcceptTypes();
                List<String> mimes = new ArrayList<>();
                if (acc != null) for (String a : acc) if (a != null && a.contains("/")) mimes.add(a);
                if (!mimes.isEmpty() && mimes.size() == acc.length) {
                    i.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0]));
                }
                try {
                    externalOps++;
                    startActivityForResult(i, REQ_PICK);
                } catch (Exception e) {
                    externalOps = Math.max(0, externalOps - 1);
                    pickCallback = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "NerdyBridge");

        applySecure();
        collect(getIntent());
        web.loadUrl("https://" + HOST + "/assets/www/index.html");
    }

    /* ===================== request routing (media, thumbnails, vault) ===================== */

    private WebResourceResponse reply(int code, String reason, byte[] body, String mime) {
        return new WebResourceResponse(mime, "utf-8", code, reason, new HashMap<String, String>(),
                new ByteArrayInputStream(body));
    }

    private static String header(Map<String, String> h, String name) {
        if (h == null) return null;
        for (Map.Entry<String, String> e : h.entrySet()) if (name.equalsIgnoreCase(e.getKey())) return e.getValue();
        return null;
    }

    private WebResourceResponse route(String path, Uri u, Map<String, String> headers) throws Exception {
        String[] seg = path.split("/");
        // seg[0] is "" because the path starts with "/"
        if (seg.length < 3) return null;
        String kind = seg[1];
        String range = header(headers, "Range");
        switch (kind) {
            case "m": { // /m/<v|i>/<id>
                if (seg.length < 4 || !guard.mediaAllowed()) return reply(403, "Locked", new byte[0], "text/plain");
                Uri mu = media.uriFor(seg[2] + seg[3]);
                if (mu == null) return null;
                Object[] sk = media.openSeekable(mu);
                if (sk != null) {
                    ParcelFileDescriptor pfd = (ParcelFileDescriptor) sk[0];
                    long total = (Long) sk[1];
                    String mime = media.mimeOf(mu, "v".equals(seg[2]) ? "video/mp4" : "image/jpeg");
                    return ranged(mime, total, range, media.seekOpener(pfd), false);
                }
                return streamPlain(mu, media.mimeOf(mu, "application/octet-stream"));
            }
            case "ci": { // /ci/<id>  any picture, converted to JPEG
                if (!guard.mediaAllowed()) return reply(403, "Locked", new byte[0], "text/plain");
                Uri cu = media.uriFor("i" + seg[2]);
                if (cu == null) return null;
                byte[] jb = media.decodeJpeg(cu, 4096);
                if (jb == null) return reply(404, "Cannot decode", new byte[0], "text/plain");
                Map<String, String> ch = new HashMap<>();
                ch.put("Cache-Control", "no-store");
                return new WebResourceResponse("image/jpeg", null, 200, "OK", ch, new ByteArrayInputStream(jb));
            }
            case "t": { // /t/<v|i>/<id>?s=256
                if (seg.length < 4 || !guard.mediaAllowed()) return reply(403, "Locked", new byte[0], "text/plain");
                int size = 256;
                try { size = Math.max(64, Math.min(1024, Integer.parseInt(u.getQueryParameter("s")))); } catch (Exception ignored) { }
                long id = Long.parseLong(seg[3]);
                byte[] b = media.thumb(seg[2], id, size);
                if (b == null) return reply(404, "No thumbnail", new byte[0], "text/plain");
                Map<String, String> h = new HashMap<>();
                h.put("Cache-Control", "private, max-age=86400");
                return new WebResourceResponse("image/jpeg", null, 200, "OK", h, new ByteArrayInputStream(b));
            }
            case "s": { // /s/<id> a file handed to us by "Open with"
                Uri su = shared.get(seg[2]);
                if (su == null) return null;
                Object[] sk = media.openSeekable(su);
                String mime = media.mimeOf(su, "application/octet-stream");
                if (sk != null) return ranged(mime, (Long) sk[1], range, media.seekOpener((ParcelFileDescriptor) sk[0]), false);
                return streamPlain(su, mime);
            }
            case "vf":
            case "vt": { // /vf/<id>  /vt/<id>   (decrypted on the fly)
                if (!guard.vaultAllowed()) return reply(403, "Locked", new byte[0], "text/plain");
                boolean th = "vt".equals(kind);
                Object[] d = vault.describe(seg[2], th);
                if (d == null) return null;
                return ranged((String) d[0], (Long) d[1], range, vault.opener(seg[2], th), true);
            }
            default:
                return null;
        }
    }

    private WebResourceResponse streamPlain(Uri u, String mime) throws IOException {
        InputStream in = getContentResolver().openInputStream(u);
        if (in == null) return null;
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "no-store");
        return new WebResourceResponse(mime, null, 200, "OK", h, in);
    }

    private WebResourceResponse ranged(String mime, long total, String range, Media.Opener op, boolean noStore)
            throws IOException {
        if (total <= 0) return reply(200, "OK", new byte[0], mime);
        long start = 0, end = total - 1;
        boolean partial = false;
        if (range != null && range.startsWith("bytes=")) {
            String spec = range.substring(6).trim();
            int comma = spec.indexOf(',');
            if (comma >= 0) spec = spec.substring(0, comma);
            int dash = spec.indexOf('-');
            if (dash >= 0) {
                String a = spec.substring(0, dash).trim(), b = spec.substring(dash + 1).trim();
                try {
                    if (a.isEmpty()) {
                        long n = Long.parseLong(b);
                        start = Math.max(0, total - n);
                    } else {
                        start = Long.parseLong(a);
                        if (!b.isEmpty()) end = Math.min(end, Long.parseLong(b));
                    }
                    partial = true;
                } catch (NumberFormatException e) {
                    start = 0;
                    end = total - 1;
                    partial = false;
                }
            }
        }
        Map<String, String> h = new HashMap<>();
        h.put("Accept-Ranges", "bytes");
        h.put("Cache-Control", noStore ? "no-store" : "private, max-age=0");
        if (start >= total || start > end) {
            h.put("Content-Range", "bytes */" + total);
            return new WebResourceResponse(mime, null, 416, "Range Not Satisfiable", h, new ByteArrayInputStream(new byte[0]));
        }
        long len = end - start + 1;
        InputStream in = new Media.Limited(op.open(start), len, null);
        h.put("Content-Length", String.valueOf(len));
        if (partial) {
            h.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
            return new WebResourceResponse(mime, null, 206, "Partial Content", h, in);
        }
        return new WebResourceResponse(mime, null, 200, "OK", h, in);
    }

    /* ===================== lifecycle ===================== */

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        collect(intent);
        web.evaluateJavascript("window.nrIncoming&&window.nrIncoming()", null);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK) {
            externalOps = Math.max(0, externalOps - 1);
            if (pickCallback == null) return;
            Uri[] out = null;
            if (res == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null) {
                    out = new Uri[clip.getItemCount()];
                    for (int i = 0; i < out.length; i++) out[i] = clip.getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    out = new Uri[]{data.getData()};
                }
            }
            pickCallback.onReceiveValue(out);
            pickCallback = null;
        } else if (req == REQ_VLC) {
            externalOps = Math.max(0, externalOps - 1);
        } else if (req == REQ_ANY) {
            externalOps = Math.max(0, externalOps - 1);
            if (res == RESULT_OK && data != null && data.getData() != null) {
                Uri pu = data.getData();
                try { getContentResolver().takePersistableUriPermission(pu, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
                startVlc(pu, 0);
            }
        } else if (req == REQ_SENDER) {
            externalOps = Math.max(0, externalOps - 1);
            Op o = op;
            op = null;
            if (o != null) emitDel(o, res == RESULT_OK);
        } else if (req == REQ_RS) {
            externalOps = Math.max(0, externalOps - 1);
            Op o = op;
            if (o == null) return;
            if (res == RESULT_OK && o.remaining != null) {
                legacyDelete(o);
            } else {
                op = null;
                emitDel(o, false);
            }
        } else if (req == REQ_DEV) {
            externalOps = Math.max(0, externalOps - 1);
            boolean ok = res == RESULT_OK;
            if (ok) guard.deviceConfirmed();
            try {
                JSONObject o = new JSONObject();
                o.put("e", "dev");
                o.put("ok", ok);
                js(o);
            } catch (Exception ignored) { }
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req != REQ_PERM) return;
        try {
            JSONObject o = new JSONObject();
            o.put("e", "perm");
            o.put("ok", hasMedia());
            js(o);
        } catch (Exception ignored) { }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.nrBack&&window.nrBack())?'1':'0'", v -> {
            if (!"\"1\"".equals(v)) finish();
        });
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (pipArmed) enterPip(pipW, pipH);
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isIn, Configuration cfg) {
        super.onPictureInPictureModeChanged(isIn, cfg);
        inPip = isIn;
        try {
            JSONObject o = new JSONObject();
            o.put("e", "pip");
            o.put("on", isIn);
            js(o);
        } catch (Exception ignored) { }
    }

    @Override
    protected void onPause() {
        super.onPause();
        pausedAt = SystemClock.elapsedRealtime();
        if (sensors != null) sensors.unregisterListener(shakeListener);
        web.evaluateJavascript("window.nrPause&&window.nrPause(" + inPip + ")", null);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (guard.autoLock() == 0 && externalOps == 0 && !inPip && (guard.appOk || guard.vaultOk)) lockNow();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (pausedAt > 0 && externalOps == 0 && (guard.appOk || guard.vaultOk)) {
            int t = guard.autoLock();
            if (t >= 0 && SystemClock.elapsedRealtime() - pausedAt >= t * 1000L) lockNow();
        }
        if (guard.shake() && sensors != null) {
            Sensor a = sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (a != null) sensors.registerListener(shakeListener, a, SensorManager.SENSOR_DELAY_GAME);
        }
        web.evaluateJavascript("window.nrResume&&window.nrResume()", null);
    }

    @Override
    protected void onDestroy() {
        vault.close();
        guard.lock();
        super.onDestroy();
    }

    private void lockNow() {
        guard.lock();
        vault.close();
        try {
            JSONObject o = new JSONObject();
            o.put("e", "locked");
            js(o);
        } catch (Exception ignored) { }
    }

    /* ===================== incoming files ("Open with", "Share") ===================== */

    private void collect(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        List<Uri> uris = new ArrayList<>();
        if (Intent.ACTION_VIEW.equals(action) && intent.getData() != null) {
            uris.add(intent.getData());
        } else if (Intent.ACTION_SEND.equals(action)) {
            Uri u = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) uris.add(u);
        }
        for (Uri u : uris) {
            try {
                String id = UUID.randomUUID().toString().replace("-", "");
                shared.put(id, u);
                JSONObject o = new JSONObject();
                o.put("id", id);
                o.put("name", displayName(u));
                String t = getContentResolver().getType(u);
                o.put("mime", t == null ? "" : t);
                synchronized (pending) { pending.add(o); }
            } catch (Exception ignored) { }
        }
        if (!uris.isEmpty()) intent.setAction(Intent.ACTION_MAIN);
    }

    private String displayName(Uri u) {
        String name = null;
        if ("content".equals(u.getScheme())) {
            try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (ix >= 0) name = c.getString(ix);
                }
            } catch (Exception ignored) { }
        }
        if (name == null || name.isEmpty()) {
            String p = u.getLastPathSegment();
            name = p == null ? "file" : p.substring(p.lastIndexOf('/') + 1);
        }
        return name;
    }

    /* ===================== messages to the web page ===================== */

    private void js(JSONObject o) {
        final String code = "window.nrNative&&window.nrNative(" + o.toString() + ")";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    private void emit(String e, String k, Object v) {
        try {
            JSONObject o = new JSONObject();
            o.put("e", e);
            if (k != null) o.put(k, v);
            js(o);
        } catch (Exception ignored) { }
    }

    private void emitDel(Op o, boolean ok) {
        try {
            JSONObject j = new JSONObject();
            j.put("e", "del");
            j.put("op", o.kind);
            j.put("ok", ok);
            j.put("keys", o.keys);
            js(j);
        } catch (Exception ignored) { }
    }

    /* ===================== permissions ===================== */

    private boolean granted(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasMedia() {
        if (Build.VERSION.SDK_INT >= 33) {
            return granted("android.permission.READ_MEDIA_IMAGES") || granted("android.permission.READ_MEDIA_VIDEO")
                    || (Build.VERSION.SDK_INT >= 34 && granted("android.permission.READ_MEDIA_VISUAL_USER_SELECTED"));
        }
        return granted("android.permission.READ_EXTERNAL_STORAGE");
    }

    private void askMedia() {
        List<String> l = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            l.add("android.permission.READ_MEDIA_IMAGES");
            l.add("android.permission.READ_MEDIA_VIDEO");
            if (Build.VERSION.SDK_INT >= 34) l.add("android.permission.READ_MEDIA_VISUAL_USER_SELECTED");
        } else {
            l.add("android.permission.READ_EXTERNAL_STORAGE");
            if (Build.VERSION.SDK_INT < 29) l.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        requestPermissions(l.toArray(new String[0]), REQ_PERM);
    }

    /* ===================== delete / trash through the system dialog ===================== */

    private List<Uri> urisFrom(JSONArray keys) {
        List<Uri> l = new ArrayList<>();
        for (int i = 0; i < keys.length(); i++) {
            Uri u = media.uriFor(keys.optString(i));
            if (u != null) l.add(u);
        }
        return l;
    }

    /** kind: "delete", "trash", "restore", "vaultorig" */
    private void requestChange(final String kind, final JSONArray keys) {
        runOnUiThread(() -> {
            final Op o = new Op();
            o.kind = kind;
            o.keys = keys;
            List<Uri> uris = urisFrom(keys);
            if (uris.isEmpty()) { emitDel(o, false); return; }
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    android.app.PendingIntent pi;
                    if ("trash".equals(kind)) pi = MediaStore.createTrashRequest(getContentResolver(), uris, true);
                    else if ("restore".equals(kind)) pi = MediaStore.createTrashRequest(getContentResolver(), uris, false);
                    else pi = MediaStore.createDeleteRequest(getContentResolver(), uris);
                    op = o;
                    externalOps++;
                    startIntentSenderForResult(pi.getIntentSender(), REQ_SENDER, null, 0, 0, 0);
                } else {
                    if ("trash".equals(kind) || "restore".equals(kind)) { emitDel(o, false); return; }
                    op = o;
                    o.remaining = uris;
                    legacyDelete(o);
                }
            } catch (Exception e) {
                op = null;
                externalOps = Math.max(0, externalOps - 1);
                emitDel(o, false);
            }
        });
    }

    /** Android 8 - 10: delete one by one; Android 10 may ask the user once per file. */
    private void legacyDelete(final Op o) {
        new Thread(() -> {
            List<Uri> rest = o.remaining;
            boolean allOk = true;
            while (rest != null && !rest.isEmpty()) {
                Uri u = rest.get(0);
                try {
                    getContentResolver().delete(u, null, null);
                    rest.remove(0);
                } catch (SecurityException se) {
                    if (Build.VERSION.SDK_INT >= 29 && se instanceof RecoverableSecurityException) {
                        final IntentSender is = ((RecoverableSecurityException) se).getUserAction().getActionIntent().getIntentSender();
                        runOnUiThread(() -> {
                            try {
                                externalOps++;
                                startIntentSenderForResult(is, REQ_RS, null, 0, 0, 0);
                            } catch (Exception e) {
                                externalOps = Math.max(0, externalOps - 1);
                                op = null;
                                emitDel(o, false);
                            }
                        });
                        return;
                    }
                    allOk = false;
                    rest.remove(0);
                } catch (Exception e) {
                    allOk = false;
                    rest.remove(0);
                }
            }
            op = null;
            emitDel(o, allOk);
        }, "np-delete").start();
    }

    /* ===================== system UI ===================== */

    private void applySystemUi() {
        int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        if (fullscreen || appFull) {
            f |= View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        }
        if (lightBars) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        web.setSystemUiVisibility(f);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = (fullscreen || appFull)
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
            getWindow().setAttributes(lp);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && web != null) applySystemUi();
    }

    private void startVlc(Uri u, long startMs) {
        try {
            Intent i = new Intent(this, VlcActivity.class);
            i.setData(u);
            i.putExtra("start", startMs);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            externalOps++;
            startActivityForResult(i, REQ_VLC);
        } catch (Exception e) {
            externalOps = Math.max(0, externalOps - 1);
        }
    }

    private void applySecure() {
        int m = guard.secureMode();
        boolean want = m == 2 || (m == 1 && vaultScreen);
        if (want == secureNow) return;
        secureNow = want;
        if (want) getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }

    private void enterPip(int w, int h) {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            if (w <= 0 || h <= 0) { w = 16; h = 9; }
            double r = (double) w / h;
            if (r > 2.39) { w = 239; h = 100; }
            else if (r < 0.42) { w = 100; h = 239; }
            PictureInPictureParams p = new PictureInPictureParams.Builder().setAspectRatio(new Rational(w, h)).build();
            inPip = true;
            if (!enterPictureInPictureMode(p)) inPip = false;
        } catch (Exception e) {
            inPip = false;
        }
    }

    private void bioPrompt(final String purpose) {
        if (Build.VERSION.SDK_INT < 28) { emit("bio", "ok", false); return; }
        runOnUiThread(() -> {
            try {
                BiometricPrompt.Builder b = new BiometricPrompt.Builder(this)
                        .setTitle("Unlock NerdyPlayer")
                        .setSubtitle("Use your fingerprint or face")
                        .setNegativeButton("Use PIN", getMainExecutor(), (d, w) -> emit("bio", "ok", false));
                BiometricPrompt p = b.build();
                p.authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                    @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                        guard.unlock(purpose);
                        if (guard.vaultOk) {
                            try { vault.open(); } catch (Exception e) { guard.vaultOk = false; }
                        }
                        try {
                            JSONObject o = new JSONObject();
                            o.put("e", "bio");
                            o.put("ok", true);
                            o.put("purpose", purpose);
                            js(o);
                        } catch (Exception ignored) { }
                    }

                    @Override public void onAuthenticationError(int code, CharSequence msg) {
                        emit("bio", "ok", false);
                    }
                });
            } catch (Exception e) {
                emit("bio", "ok", false);
            }
        });
    }

    private boolean bioAvailable() {
        if (Build.VERSION.SDK_INT < 29) return false;
        try {
            BiometricManager bm = getSystemService(BiometricManager.class);
            return bm != null && bm.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS;
        } catch (Exception e) {
            return false;
        }
    }

    /* ===================== the bridge the web page calls ===================== */

    private class Bridge {

        /* ---------- info / permission ---------- */
        @JavascriptInterface
        public String info() {
            try {
                JSONObject o = new JSONObject();
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("perm", hasMedia());
                o.put("canTrash", Build.VERSION.SDK_INT >= 30);
                o.put("pip", Build.VERSION.SDK_INT >= 26);
                o.put("model", Build.MODEL);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void askPerm() { runOnUiThread(MainActivity.this::askMedia); }

        @JavascriptInterface
        public void scan(final boolean trashed) {
            if (!hasMedia()) { emit("scan", "denied", true); return; }
            new Thread(() -> media.scan(trashed, new Media.Sink() {
                @Override public void rows(JSONArray rows, boolean first) {
                    try {
                        JSONObject o = new JSONObject();
                        o.put("e", trashed ? "trash" : "scan");
                        o.put("rows", rows);
                        o.put("first", first);
                        js(o);
                    } catch (Exception ignored) { }
                }

                @Override public void done(int total) {
                    try {
                        JSONObject o = new JSONObject();
                        o.put("e", trashed ? "trash" : "scan");
                        o.put("done", true);
                        o.put("total", total);
                        js(o);
                    } catch (Exception ignored) { }
                }
            }), "np-scan").start();
        }

        @JavascriptInterface
        public String takePending() {
            synchronized (pending) {
                if (pending.isEmpty()) return "";
                JSONArray a = new JSONArray();
                for (JSONObject o : pending) a.put(o);
                pending.clear();
                return a.toString();
            }
        }

        /* ---------- file actions ---------- */
        @JavascriptInterface
        public void deleteKeys(String keysJson, boolean permanent) {
            try { requestChange(permanent ? "delete" : "trash", new JSONArray(keysJson)); } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void restoreTrash(String keysJson) {
            try { requestChange("restore", new JSONArray(keysJson)); } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void share(final String keysJson) {
            runOnUiThread(() -> {
                try {
                    List<Uri> uris = urisFrom(new JSONArray(keysJson));
                    if (uris.isEmpty()) return;
                    Intent i;
                    if (uris.size() == 1) {
                        i = new Intent(Intent.ACTION_SEND);
                        i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                        i.setType(media.mimeOf(uris.get(0), "*/*"));
                    } else {
                        i = new Intent(Intent.ACTION_SEND_MULTIPLE);
                        i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, new ArrayList<>(uris));
                        i.setType("*/*");
                    }
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(i, "Share"));
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void openWith(final String key, final String action) {
            runOnUiThread(() -> {
                try {
                    Uri u = media.uriFor(key);
                    if (u == null) return;
                    String mime = media.mimeOf(u, key.startsWith("v") ? "video/*" : "image/*");
                    Intent i = new Intent("attach".equals(action) ? Intent.ACTION_ATTACH_DATA : Intent.ACTION_VIEW);
                    i.setDataAndType(u, mime);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    if ("attach".equals(action)) i.putExtra("mimeType", mime);
                    startActivity(Intent.createChooser(i, "attach".equals(action) ? "Set as" : "Open with"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No app found for this file", Toast.LENGTH_SHORT).show();
                }
            });
        }

        /* ---------- device ---------- */
        @JavascriptInterface
        public void setBars(final String color, final boolean darkIcons) {
            runOnUiThread(() -> {
                try {
                    int c = Color.parseColor(color);
                    getWindow().setStatusBarColor(c);
                    getWindow().setNavigationBarColor(c);
                    lightBars = darkIcons;
                    applySystemUi();
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void fullscreen(final boolean on) {
            runOnUiThread(() -> { fullscreen = on; applySystemUi(); });
        }

        /** Play a gallery video with the built-in VLC engine (every format, half-downloaded files). */
        @JavascriptInterface
        public void playNative(final String key, final long startMs) {
            if (!guard.mediaAllowed()) return;
            final Uri mu = media.uriFor(key);
            if (mu == null) return;
            runOnUiThread(() -> startVlc(mu, startMs));
        }

        /** Let the person pick ANY file (.part, .crdownload, .mkv, .avi ...) and play it with VLC. */
        @JavascriptInterface
        public void pickAny() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                    externalOps++;
                    startActivityForResult(i, REQ_ANY);
                } catch (Exception e) {
                    externalOps = Math.max(0, externalOps - 1);
                }
            });
        }

        @JavascriptInterface
        public void appFull(final boolean on) {
            getSharedPreferences("ui", MODE_PRIVATE).edit().putBoolean("appFull", on).apply();
            runOnUiThread(() -> { appFull = on; applySystemUi(); });
        }

        @JavascriptInterface
        public void orientation(final String mode) {
            runOnUiThread(() -> {
                int o;
                switch (mode) {
                    case "portrait": o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT; break;
                    case "landscape": o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE; break;
                    case "sensor": o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR; break;
                    case "lock": o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LOCKED; break;
                    default: o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; break;
                }
                try { setRequestedOrientation(o); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void setBrightness(final double v) {
            runOnUiThread(() -> {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = v < 0 ? WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE : (float) Math.max(0.02, Math.min(1, v));
                getWindow().setAttributes(lp);
            });
        }

        @JavascriptInterface
        public double getBrightness() {
            try {
                float b = getWindow().getAttributes().screenBrightness;
                if (b >= 0) return b;
                return Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS) / 255.0;
            } catch (Exception e) {
                return 0.5;
            }
        }

        @JavascriptInterface
        public void setVolume(double v) {
            try {
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                am.setStreamVolume(AudioManager.STREAM_MUSIC, (int) Math.round(Math.max(0, Math.min(1, v)) * max), 0);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public double getVolume() {
            try {
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                return max <= 0 ? 0.5 : am.getStreamVolume(AudioManager.STREAM_MUSIC) / (double) max;
            } catch (Exception e) {
                return 0.5;
            }
        }

        @JavascriptInterface
        public void keepScreenOn(final boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void vaultScreen(final boolean on) {
            runOnUiThread(() -> { vaultScreen = on; applySecure(); });
        }

        @JavascriptInterface
        public void armPip(final boolean on, final int w, final int h) {
            pipArmed = on && Build.VERSION.SDK_INT >= 26;
            pipW = w;
            pipH = h;
        }

        @JavascriptInterface
        public void pipNow(final int w, final int h) {
            runOnUiThread(() -> enterPip(w, h));
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void exit() { runOnUiThread(MainActivity.this::finish); }

        /* ---------- saving a picture or video frame into the gallery ---------- */
        @JavascriptInterface
        public void saveBegin(String name, String mime, boolean video) {
            try {
                if (saveOut != null) { try { saveOut.close(); } catch (Exception ignored) { } }
                if (saveFile != null) //noinspection ResultOfMethodCallIgnored
                    saveFile.delete();
                saveFile = new File(getCacheDir(), "save-" + UUID.randomUUID().toString().replace("-", "") + ".tmp");
                saveOut = new FileOutputStream(saveFile);
                saveName = name;
                saveMime = mime;
                saveVideo = video;
                saveError = null;
            } catch (Exception e) {
                saveError = e.getMessage();
            }
        }

        @JavascriptInterface
        public void saveChunk(String base64) {
            if (saveOut == null) return;
            try { saveOut.write(Base64.decode(base64, Base64.DEFAULT)); } catch (Exception e) { saveError = e.getMessage(); }
        }

        @JavascriptInterface
        public void saveEnd() {
            try { if (saveOut != null) saveOut.close(); } catch (Exception e) { saveError = e.getMessage(); }
            saveOut = null;
            final File f = saveFile;
            final String name = saveName, mime = saveMime;
            final boolean vid = saveVideo;
            final String err = saveError;
            saveFile = null;
            if (f == null || err != null) {
                if (f != null) //noinspection ResultOfMethodCallIgnored
                    f.delete();
                emitSaved(false, name, err == null ? "Nothing to save" : err);
                return;
            }
            new Thread(() -> {
                try (InputStream in = new FileInputStream(f)) {
                    media.saveToGallery(name, mime, vid, in);
                    emitSaved(true, name, null);
                } catch (Exception e) {
                    emitSaved(false, name, e.getMessage());
                } finally {
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                }
            }, "np-save").start();
        }

        /* ---------- security ---------- */
        @JavascriptInterface
        public String sec() {
            try {
                JSONObject o = new JSONObject();
                o.put("pinSet", guard.pinSet());
                o.put("appLock", guard.appLock());
                o.put("appOk", guard.appOk);
                o.put("vaultOk", guard.vaultOk);
                o.put("bio", guard.bio());
                o.put("bioAvail", bioAvailable());
                o.put("vaultAlways", guard.vaultAlways());
                o.put("shake", guard.shake());
                o.put("autolock", guard.autoLock());
                o.put("secure", guard.secureMode());
                o.put("wait", guard.lockoutMs());
                o.put("left", guard.failsLeftBeforeLockout());
                KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                o.put("deviceSecure", km != null && km.isDeviceSecure());
                o.put("vaultExists", vault.exists());
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public String setPin(String pin, String old) {
            String err = guard.setPin(pin, old);
            JSONObject o = new JSONObject();
            try {
                o.put("ok", err == null);
                if (err != null) o.put("err", err);
            } catch (Exception ignored) { }
            return o.toString();
        }

        /** purpose = "app" or "vault" */
        @JavascriptInterface
        public String verify(String pin, String purpose) {
            long r = guard.verify(pin);
            JSONObject o = new JSONObject();
            try {
                if (r == 0) {
                    guard.unlock(purpose);
                    boolean vaultErr = false;
                    if (guard.vaultOk) {
                        try { vault.open(); } catch (Exception e) { vaultErr = true; guard.vaultOk = false; }
                    }
                    o.put("ok", true);
                    if (vaultErr) o.put("vaultErr", true);
                } else {
                    o.put("ok", false);
                    o.put("wait", r > 0 ? r : 0);
                    o.put("left", guard.failsLeftBeforeLockout());
                }
            } catch (Exception ignored) { }
            return o.toString();
        }

        @JavascriptInterface
        public void bio(String purpose) { bioPrompt(purpose); }

        @JavascriptInterface
        public void devConfirm() {
            runOnUiThread(() -> {
                try {
                    KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                    if (km == null || !km.isDeviceSecure()) { emit("dev", "ok", false); return; }
                    Intent i = km.createConfirmDeviceCredentialIntent("Reset NerdyPlayer PIN", "Confirm your phone's screen lock");
                    if (i == null) { emit("dev", "ok", false); return; }
                    externalOps++;
                    startActivityForResult(i, REQ_DEV);
                } catch (Exception e) {
                    externalOps = Math.max(0, externalOps - 1);
                    emit("dev", "ok", false);
                }
            });
        }

        @JavascriptInterface
        public void lock() { runOnUiThread(MainActivity.this::lockNow); }

        @JavascriptInterface
        public void setOpt(final String k, final String v) {
            guard.setOpt(k, v);
            if ("shake".equals(k)) {
                runOnUiThread(() -> {
                    if (sensors == null) return;
                    sensors.unregisterListener(shakeListener);
                    if (guard.shake()) {
                        Sensor a = sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                        if (a != null) sensors.registerListener(shakeListener, a, SensorManager.SENSOR_DELAY_GAME);
                    }
                });
            }
            if ("secure".equals(k)) runOnUiThread(MainActivity.this::applySecure);
        }

        /* ---------- vault ---------- */
        @JavascriptInterface
        public String vaultList() {
            if (!guard.vaultAllowed() || !vault.isOpen()) return "[]";
            return vault.listJson();
        }

        /** items: [{key,n,m,v,s,d,w,h,t,b}] */
        @JavascriptInterface
        public void vaultAdd(final String itemsJson) {
            if (!guard.vaultAllowed() || !vault.isOpen()) { emit("vadd", "err", "Vault is locked"); return; }
            new Thread(() -> {
                int done = 0, failed = 0;
                JSONArray okKeys = new JSONArray();
                try {
                    JSONArray items = new JSONArray(itemsJson);
                    int n = items.length();
                    for (int i = 0; i < n; i++) {
                        JSONObject it = items.getJSONObject(i);
                        String key = it.optString("key");
                        Uri u = media.uriFor(key);
                        try {
                            if (u == null) throw new IOException("bad key");
                            byte[] th = null;
                            try { th = media.thumb(key.substring(0, 1), Long.parseLong(key.substring(1)), 360); } catch (Exception ignored) { }
                            vault.addOne(u, it, th);
                            okKeys.put(key);
                            done++;
                        } catch (Exception e) {
                            failed++;
                        }
                        JSONObject p = new JSONObject();
                        p.put("e", "vprog");
                        p.put("i", i + 1);
                        p.put("n", n);
                        js(p);
                    }
                } catch (Exception ignored) { }
                try {
                    JSONObject o = new JSONObject();
                    o.put("e", "vadd");
                    o.put("done", done);
                    o.put("failed", failed);
                    o.put("keys", okKeys);
                    js(o);
                } catch (Exception ignored) { }
            }, "np-vault-add").start();
        }

        /** After the copies are safe, ask Android to remove the originals. */
        @JavascriptInterface
        public void vaultRemoveOriginals(String keysJson) {
            try { requestChange("vaultorig", new JSONArray(keysJson)); } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void vaultRestore(final String idsJson, final boolean remove) {
            if (!guard.vaultAllowed() || !vault.isOpen()) { emit("vrest", "err", "Vault is locked"); return; }
            new Thread(() -> {
                int ok = 0, bad = 0;
                try {
                    JSONArray ids = new JSONArray(idsJson);
                    for (int i = 0; i < ids.length(); i++) {
                        try {
                            if (vault.restoreOne(ids.getString(i), media, remove)) ok++; else bad++;
                        } catch (Exception e) {
                            bad++;
                        }
                    }
                } catch (Exception ignored) { }
                try {
                    JSONObject o = new JSONObject();
                    o.put("e", "vrest");
                    o.put("ok", ok);
                    o.put("failed", bad);
                    o.put("removed", remove);
                    js(o);
                } catch (Exception ignored) { }
            }, "np-vault-restore").start();
        }

        @JavascriptInterface
        public int vaultDelete(String idsJson) {
            if (!guard.vaultAllowed() || !vault.isOpen()) return 0;
            int n = 0;
            try {
                JSONArray ids = new JSONArray(idsJson);
                for (int i = 0; i < ids.length(); i++) {
                    try { vault.deleteOne(ids.getString(i)); n++; } catch (Exception ignored) { }
                }
            } catch (Exception ignored) { }
            return n;
        }

        /** Erase the vault and the PIN. Needs the PIN, or the phone's screen lock if it was just confirmed. */
        @JavascriptInterface
        public boolean vaultWipe(String pin) {
            if (guard.pinSet() && !guard.deviceRecent() && guard.verify(pin) != 0) return false;
            vault.wipe();
            guard.wipe();
            return true;
        }
    }

    private void emitSaved(boolean ok, String name, String err) {
        try {
            JSONObject o = new JSONObject();
            o.put("e", "saved");
            o.put("ok", ok);
            o.put("name", name == null ? "" : name);
            if (err != null) o.put("error", err);
            js(o);
        } catch (Exception ignored) { }
    }
}
