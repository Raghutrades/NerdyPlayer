'use strict';
/* ===== NerdyPlayer · slideshow ===== */
const Show = (() => {
  let on = false, L = [], i = 0, timer = null, paused = false, cur = 0, layers = [], opt = {}, busy = false;
  const root = () => $('#show');
  const TR = [['fade', 'Fade'], ['slide', 'Slide'], ['zoom', 'Zoom'], ['ken', 'Ken Burns'], ['none', 'None']];
  const srcFor = it => it.src || (it.vault ? '/vi/' + it.uid : '/img/' + it.i);

  function setup(list, start) {
    const photos = list.filter(x => !isVid(x));
    if (!photos.length) return toast('No photos to show');
    const o = { interval: CFG.interval, trans: CFG.trans, shuffle: CFG.shuffle, loop: CFG.loop };
    const seg = (id, arr, v) => `<div class="seg" id="${id}" style="margin:4px 0 12px">${arr.map(a => `<button data-v="${a[0]}" class="${String(a[0]) === String(v) ? 'on' : ''}">${a[1]}</button>`).join('')}</div>`;
    const sh = sheet('Slideshow · ' + photos.length + ' photos', [], `
      <div class="xs mute">Time per photo</div>${seg('ss-int', [[2, '2s'], [3, '3s'], [4, '4s'], [6, '6s'], [10, '10s'], [20, '20s']], o.interval)}
      <div class="xs mute">Transition</div>${seg('ss-tr', TR, o.trans)}
      <div class="xs mute">Order</div>${seg('ss-or', [[0, 'In order'], [1, 'Shuffle']], o.shuffle ? 1 : 0)}
      <div class="xs mute">When it ends</div>${seg('ss-lp', [[1, 'Loop'], [0, 'Stop']], o.loop ? 1 : 0)}
      <button class="btn pri" id="ss-go" style="width:100%;justify-content:center;margin-top:4px">${ic('play', 16)} Start</button>`);
    sh.el.addEventListener('click', e => {
      const b = e.target.closest('.seg button');
      if (b) { $$('button', b.parentNode).forEach(x => x.classList.remove('on')); b.classList.add('on'); const id = b.parentNode.id, v = b.dataset.v; if (id === 'ss-int') o.interval = +v; if (id === 'ss-tr') o.trans = v; if (id === 'ss-or') o.shuffle = v === '1'; if (id === 'ss-lp') o.loop = v === '1'; return; }
      if (e.target.closest('#ss-go')) {
        Object.assign(CFG, { interval: o.interval, trans: o.trans, shuffle: o.shuffle, loop: o.loop }); saveCfg();
        sh.el.parentNode.remove();
        let arr = photos, idx = start || 0;
        if (o.shuffle) { const first = arr[idx]; arr = shuffled(arr); if (first) { arr.splice(arr.indexOf(first), 1); arr.unshift(first); } idx = 0; }
        run(arr, idx, o);
      }
    });
  }

  function run(list, start, o) {
    L = list; i = start; opt = Object.assign({}, o); on = true; paused = false; cur = 0;
    nat('awake', true);
    const r = root(); r.classList.add('on'); r.classList.remove('shhide');
    r.innerHTML = `<div class="sl act"><img alt=""></div><div class="sl"><img alt=""></div>
      <div class="shtop"><button class="ib" data-s="close" style="color:#fff">${ic('close', 24)}</button><span id="shc" style="align-self:center;font-size:13px"></span></div>
      <div class="shctl"><div class="pbar"><i id="shp"></i></div><div class="row gap"><button class="ib" data-s="slow" style="color:#fff">${ic('rew', 22)}</button><button class="ib" data-s="prev" style="color:#fff">${ic('prev', 24)}</button><button class="ib" data-s="pp" id="shpp" style="color:#fff;width:54px;height:54px;background:#ffffff22">${ic('pause', 26)}</button><button class="ib" data-s="next" style="color:#fff">${ic('next', 24)}</button><button class="ib" data-s="fast" style="color:#fff">${ic('fwd', 22)}</button></div><div class="xs" style="opacity:.75" id="shi"></div></div>`;
    layers = $$('.sl', r);
    showAt(i, true);
    setTimeout(() => r.classList.add('shhide'), 2500);
  }

  function showAt(n, first) {
    const nw = layers[1 - cur], old = layers[cur], img = $('img', nw);
    const it = L[n]; if (!it) return;
    $('#shc').textContent = (n + 1) + ' / ' + L.length;
    $('#shi').textContent = opt.interval + 's · ' + (TR.find(t => t[0] === opt.trans) || ['', ''])[1];
    const finish = () => {
      const mode = first ? 'none' : opt.trans;
      nw.style.transition = 'none'; old.style.transition = 'none'; img.style.transition = 'none'; img.style.transform = '';
      if (mode === 'slide') { nw.style.transform = 'translateX(100%)'; nw.style.opacity = 1; }
      else if (mode === 'zoom') { nw.style.transform = 'scale(1.18)'; nw.style.opacity = 0; }
      else { nw.style.transform = ''; nw.style.opacity = 0; }
      void nw.offsetWidth;
      const tm = mode === 'none' ? 'none' : 'opacity .8s ease, transform .8s ease';
      nw.style.transition = tm; old.style.transition = tm;
      nw.style.transform = ''; nw.style.opacity = 1;
      if (mode === 'slide') old.style.transform = 'translateX(-100%)';
      else if (mode === 'zoom') { old.style.transform = 'scale(.9)'; old.style.opacity = 0; }
      else old.style.opacity = 0;
      if (mode === 'ken') {
        const dx = (Math.random() * 6 - 3).toFixed(1), dy = (Math.random() * 6 - 3).toFixed(1);
        img.style.transition = 'none'; img.style.transform = 'scale(1)'; void img.offsetWidth;
        img.style.transition = `transform ${opt.interval + 1}s linear`; img.style.transform = `scale(1.16) translate(${dx}%,${dy}%)`;
      }
      setTimeout(() => { old.style.transform = ''; old.style.opacity = 0; old.classList.remove('act'); }, mode === 'none' ? 0 : 850);
      nw.classList.add('act');
      cur = 1 - cur; busy = false;
      bar(); schedule();
      const nx = L[(n + 1) % L.length]; if (nx) { const p = new Image(); p.src = srcFor(nx); }
    };
    busy = true;
    img.onload = finish; img.onerror = () => { busy = false; step(1); };
    img.src = srcFor(it);
    if (img.complete && img.naturalWidth) { img.onload = null; finish(); }
  }
  function bar() {
    const p = $('#shp'); if (!p) return;
    p.style.transition = 'none'; p.style.width = '0';
    if (paused) return;
    void p.offsetWidth; p.style.transition = `width ${opt.interval}s linear`; p.style.width = '100%';
  }
  function schedule() {
    clearTimeout(timer);
    if (paused || !on) return;
    timer = setTimeout(() => step(1), opt.interval * 1000);
  }
  function step(d) {
    if (!on || busy) return;
    let n = i + d;
    if (n >= L.length) { if (!opt.loop) { toast('Slideshow finished'); return close(); } n = 0; }
    if (n < 0) n = L.length - 1;
    i = n; showAt(n, false);
  }
  function close() {
    if (!on) return;
    on = false; clearTimeout(timer); nat('awake', false);
    const r = root(); r.classList.remove('on'); r.innerHTML = '';
  }
  document.addEventListener('DOMContentLoaded', () => {
    root().addEventListener('click', e => {
      const b = e.target.closest('[data-s]');
      if (!b) { root().classList.toggle('shhide'); return; }
      const a = b.dataset.s;
      if (a === 'close') return close();
      if (a === 'prev') return step(-1);
      if (a === 'next') return step(1);
      if (a === 'pp') { paused = !paused; b.innerHTML = ic(paused ? 'play' : 'pause', 26); if (paused) { clearTimeout(timer); const p = $('#shp'); if (p) { p.style.transition = 'none'; } } else { bar(); schedule(); } return; }
      if (a === 'slow' || a === 'fast') { opt.interval = Math.max(1, Math.min(60, opt.interval + (a === 'slow' ? 1 : -1))); $('#shi').textContent = opt.interval + 's per photo'; bar(); schedule(); }
    });
  });
  return { setup, close, isOn: () => on };
})();
