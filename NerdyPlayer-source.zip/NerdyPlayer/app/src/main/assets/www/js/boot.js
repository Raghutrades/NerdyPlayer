'use strict';
/* ===== NerdyPlayer · start-up ===== */
async function boot2() {
  S.st = JSON.parse(nat('state') || '{}');
  await loadMedia();
  renderMain();
}
async function boot() {
  Splash.mount();
  applyTheme();
  saveCfg();
  wire();
  S.st = JSON.parse(nat('state') || '{}');
  renderBar(); renderMain();
  if (S.st.applock && !S.st.unlocked) {
    Splash.hide();
    Sec.ask(async () => { await boot2(); }, null);
    return;
  }
  if (S.st.perm) await loadMedia(); else nat('askPerm');
  renderMain();
  Splash.hide();
  if (S.st.ext) Viewer.openExt(S.st.ext);
}
document.addEventListener('DOMContentLoaded', boot);
