'use strict';
/* ===== NerdyPlayer · view styles =====
   Photos:  Grid · Masonry · Mosaic · Feed · Card stack · Coverflow
   Videos:  List · Grid · Live cards (preview plays by itself) · Reels · Card stack · Mosaic */

Object.assign(IC, {
  masonry: '<rect x="3" y="3" width="8" height="11" rx="1.5"/><rect x="13" y="3" width="8" height="6" rx="1.5"/><rect x="3" y="16" width="8" height="5" rx="1.5"/><rect x="13" y="11" width="8" height="10" rx="1.5"/>',
  mosaic: '<rect x="3" y="3" width="11" height="11" rx="1.5"/><rect x="16" y="3" width="5" height="5" rx="1"/><rect x="16" y="10" width="5" height="4" rx="1"/><rect x="3" y="16" width="5" height="5" rx="1"/><rect x="10" y="16" width="11" height="5" rx="1.5"/>',
  feed: '<rect x="4" y="3" width="16" height="9" rx="2"/><rect x="4" y="14" width="16" height="7" rx="2"/>',
  stack: '<rect x="6" y="6" width="13" height="15" rx="2"/><path d="M4 17V5a2 2 0 0 1 2-2h10"/>',
  cover: '<rect x="8" y="5" width="8" height="14" rx="1.5"/><path d="M5 7v10M2 9v6M19 7v10M22 9v6"/>',
  cards: '<rect x="3" y="4" width="18" height="10" rx="2"/><path d="M3 18h10M3 21h6"/><path d="M11 7.5v3l2.5-1.5z"/>',
  reels: '<rect x="7" y="2" width="10" height="20" rx="2.5"/><path d="M10.5 9.5v5l4-2.5z"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/>',
  vol: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/>',
  mute: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M17 9l5 6M22 9l-5 6"/>',
});

const STYLES = {
  i: [['grid', 'Grid'], ['masonry', 'Masonry'], ['mosaic', 'Mosaic'], ['feed', 'Feed'], ['stack', 'Card stack'], ['cover', 'Coverflow']],
  v: [['list', 'List'], ['grid', 'Grid'], ['cards', 'Live cards'], ['reels', 'Reels'], ['stack', 'Card stack'], ['mosaic', 'Mosaic']],
};
const styleOf = kind => (kind === 'v' ? ST.viewV : ST.viewP) || (kind === 'v' ? 'list' : 'grid');

/* ---------- tiny helper shared by all styles ---------- */
function pseudoGrid(el, list, destroy) {
  return { items: list, g: el, el, cfg: {}, sel: SEL, refresh() { }, destroy: destroy || (() => { }), find: k => list.find(i => i.key === k) };
}
const openAt = (it, list) => Items.open(it, list);
const thumbFor = (it, s) => Src.thumb(it, s) || '';
const imgTag = (it, s, cls = '') => { const t = thumbFor(it, s); return t ? `<img class="${cls}" loading="lazy" decoding="async" src="${t}" alt="" onerror="this.classList.add('bad')">` : ''; };

/* ---------- live preview: a muted clip that plays by itself inside the card ---------- */
const Prev = {
  io: null, active: null, vis: new Map(),
  start(card) {
    if (this.active === card) return;
    this.stop();
    if (ST.autoPreview === false) return;
    const it = LIB.map.get(card.dataset.key) || (App.gv && App.gv.find && App.gv.find(card.dataset.key));
    if (!it || !it.v) return;
    const box = card.querySelector('.pvw'); if (!box) return;
    const v = document.createElement('video');
    v.muted = !ST.previewSound; v.playsInline = true; v.setAttribute('playsinline', ''); v.preload = 'auto'; v.disablePictureInPicture = true;
    v.src = Src.url(it);
    const dur = it.d ? it.d / 1000 : 0;
    const from = dur > 12 ? Math.min(dur * 0.18, dur - 8) : 0, to = from + 5;
    v.addEventListener('loadedmetadata', () => { try { if (from) v.currentTime = from; } catch (e) { } v.play().catch(() => { }); });
    v.addEventListener('timeupdate', () => {
      if (v.currentTime > to || v.ended) { try { v.currentTime = from; } catch (e) { } v.play().catch(() => { }); }
      const bar = card.querySelector('.pbar i'); if (bar) bar.style.width = Math.min(100, Math.max(0, (v.currentTime - from) / (to - from) * 100)) + '%';
    });
    v.addEventListener('playing', () => card.classList.add('live'));
    v.addEventListener('error', () => card.classList.remove('live'));
    box.appendChild(v);
    this.active = card; this.vid = v;
  },
  stop() {
    if (!this.active) return;
    const c = this.active; this.active = null;
    const v = c.querySelector('.pvw video');
    if (v) { try { v.pause(); v.removeAttribute('src'); v.load(); } catch (e) { } v.remove(); }
    c.classList.remove('live');
  },
  watch(root, scroller) {
    if (!this.io || this.root !== scroller) {
      if (this.io) this.io.disconnect();
      this.root = scroller;
      this.io = new IntersectionObserver(es => {
        for (const e of es) { if (e.isIntersecting && e.intersectionRatio >= 0.55) this.vis.set(e.target, e.intersectionRatio); else { this.vis.delete(e.target); if (e.target === this.active) this.stop(); } }
        let best = null, bd = 1e9; const mid = innerHeight / 2;
        for (const c of this.vis.keys()) { const r = c.getBoundingClientRect(); const d = Math.abs(r.top + r.height / 2 - mid); if (d < bd) { bd = d; best = c; } }
        if (best) this.start(best);
      }, { root: scroller, threshold: [0, 0.55, 0.8, 1] });
    }
    $$('.bigc[data-v="1"]', root).forEach(c => { if (!c.dataset.w) { c.dataset.w = 1; this.io.observe(c); } });
  },
  reset() { this.stop(); this.vis.clear(); if (this.io) { this.io.disconnect(); this.io = null; } },
};
document.addEventListener('visibilitychange', () => { if (document.hidden) Prev.stop(); });

/* big card used by Live cards (videos) and Feed (photos) */
GridView.prototype.bigHTML = function (it) {
  const sel = this.sel.keys.has(it.key), p = it.v ? posOf(it.key) : null;
  const res = it.w && it.h ? `${it.w}×${it.h}` : '';
  return `<div class="bigc ${sel ? 'sel' : ''} ${it.v ? 'vid' : ''}" data-key="${it.key}" data-v="${it.v ? 1 : 0}">
    <div class="bmedia" style="aspect-ratio:${it.w && it.h && !it.v ? Math.max(.75, Math.min(1.6, it.w / it.h)).toFixed(3) : '16/9'}">
      ${imgTag(it, 640)}<span class="ph">${ic(it.v ? 'film' : 'image', 34)}</span><div class="pvw"></div>
      ${it.v ? `<span class="dur">${icFill('play', 9)} ${fmtDur(it.d)}</span><span class="livebadge"><i></i>LIVE</span><div class="pbar"><i></i></div>` : ''}
      ${p && it.d ? `<div class="prog"><i style="width:${Math.min(100, p.t * 1000 / it.d * 100).toFixed(1)}%"></i></div>` : ''}
      <i class="chk">${ic('check', 15)}</i>
      <div class="bgrad"><b>${esc(it.n)}</b><span>${[res, sizeStr(it.s), dateStr(it.t)].filter(Boolean).join(' · ')}</span></div>
    </div>
    <div class="bact"><span class="bf">${esc(it.b)}</span><span class="sp"></span>
      <button class="ib sm ${isFav(it.key) ? 'fav' : ''}" data-bfav="${it.key}" aria-label="Favourite">${isFav(it.key) ? icFill('heart', 20) : ic('heart', 20)}</button>
      <button class="ib sm" data-more aria-label="More">${ic('more', 20)}</button></div></div>`;
};
(function patchGrid() {
  const oldMore = GridView.prototype.more;
  GridView.prototype.more = function () {
    const big = this.cfg.mode === 'cards' || this.cfg.mode === 'feed';
    if (!big) return oldMore.call(this);
    if (this.shown >= this.items.length) { this.sent.hidden = true; return; }
    const end = Math.min(this.items.length, this.shown + 24);
    let h = ''; for (let i = this.shown; i < end; i++) h += this.bigHTML(this.items[i]);
    this.shown = end; this.g.insertAdjacentHTML('beforeend', h); this.sent.hidden = this.shown >= this.items.length;
    if (this.cfg.mode === 'cards') Prev.watch(this.g, $('#main'));
  };
  const oldDestroy = GridView.prototype.destroy;
  GridView.prototype.destroy = function () { oldDestroy.call(this); if (this.cfg.mode === 'cards') Prev.reset(); };
})();
document.addEventListener('click', e => {
  const b = e.target.closest('[data-bfav]'); if (!b) return;
  e.stopPropagation(); toggleFav(b.dataset.bfav);
  const on = isFav(b.dataset.bfav); b.classList.toggle('fav', on); b.innerHTML = on ? icFill('heart', 20) : ic('heart', 20);
}, true);

/* ---------- entry point used by the Photos / Videos tabs ---------- */
function mkStyled(el, kind, list, o = {}) {
  const st = styleOf(kind);
  const by = o.by || 'date';
  const dated = ['date', 'added'].includes(kind === 'v' ? ST.sortV : ST.sortP);
  const grp = o.group || (dated ? ST.group : 'none');
  switch (st) {
    case 'list': return mkGrid(el, list, { ...o, mode: 'list', group: grp, by });
    case 'masonry': return mkGrid(el, list, { ...o, mode: 'grid', tile: 'orig', group: 'none', by });
    case 'mosaic': return mkGrid(el, list, { ...o, mode: 'grid', cls: 'mosaic', group: 'none', by });
    case 'cards': case 'feed': return mkGrid(el, list, { ...o, mode: st === 'feed' && kind === 'v' ? 'cards' : (st === 'feed' ? 'feed' : 'cards'), group: 'none', by });
    case 'reels': return Reels.mount(el, list);
    case 'stack': return Stack.mount(el, list);
    case 'cover': return Cover.mount(el, list);
    default: return mkGrid(el, list, { ...o, mode: 'grid', group: grp, by });
  }
}
ACT['style-sheet'] = el => styleSheet(el.dataset.k);
function styleSheet(kind) {
  const cur = styleOf(kind);
  const s = Sheet.open(`<p class="hint" style="margin:0 0 12px">${kind === 'v' ? 'How your videos are shown. Live cards and Reels play a short silent preview by themselves.' : 'How your photos are shown.'}</p>
    <div class="stylegrid">${STYLES[kind].map(x => `<button class="stl ${cur === x[0] ? 'on' : ''}" data-act="style-set" data-k="${kind}" data-v="${x[0]}">${ic(x[0] === 'grid' ? 'grid' : x[0], 26)}<b>${x[1]}</b></button>`).join('')}</div>
    ${kind === 'v' ? `<div class="rowsw"><div class="grow"><span>Auto-play previews</span><small>Cards and Reels play a few seconds by themselves</small></div>${sw(ST.autoPreview !== false, 'prev-sw', 'autoPreview')}</div>
    <div class="rowsw"><div class="grow"><span>Preview sound</span><small>Off keeps it silent</small></div>${sw(!!ST.previewSound, 'prev-sw', 'previewSound')}</div>` : ''}`, { title: kind === 'v' ? 'Video view style' : 'Photo view style' });
}
ACT['style-set'] = el => { ST[el.dataset.k === 'v' ? 'viewV' : 'viewP'] = el.dataset.v; saveST(); Sheet.close(); Prev.reset(); App.render(true); };
ACT['prev-sw'] = el => { const k = el.dataset.k; ST[k] = !(k === 'autoPreview' ? ST.autoPreview !== false : ST[k]); saveST(); el.classList.toggle('on', k === 'autoPreview' ? ST.autoPreview !== false : ST[k]); };

/* ---------- Reels: full-screen vertical feed, the video playing in front of you ---------- */
const Reels = {
  mount(el, list) {
    const main = $('#main'); main.classList.add('flush');
    const h = main.clientHeight || innerHeight - 120;
    const items = list.filter(i => i.v).slice(0, 150);
    el.innerHTML = `<div class="reels" style="height:${h}px">${items.map((it, i) => `<section class="reel" data-key="${it.key}" data-i="${i}" style="height:${h}px">
      ${imgTag(it, 640, 'rposter')}<div class="rv"></div>
      <div class="rgrad"><b>${esc(it.n)}</b><span>${[it.w && it.h ? `${it.w}×${it.h}` : '', fmtDur(it.d), esc(it.b)].filter(Boolean).join(' · ')}</span></div>
      <div class="rside"><button data-rfav="${it.key}" class="${isFav(it.key) ? 'fav' : ''}" aria-label="Favourite">${isFav(it.key) ? icFill('heart', 26) : ic('heart', 26)}</button>
        <button data-rmute aria-label="Sound">${ic(ST.reelSound ? 'vol' : 'mute', 26)}</button>
        <button data-ropen="${i}" aria-label="Open full screen">${ic('expand', 26)}</button>
        <button data-rmore="${i}" aria-label="More">${ic('more', 26)}</button></div>
      <div class="rbar"><i></i></div></section>`).join('')}</div>`;
    const box = el.firstElementChild; let cur = null, v = null;
    const stop = () => { if (v) { try { v.pause(); v.removeAttribute('src'); v.load(); } catch (e) { } v.remove(); v = null; } if (cur) cur.classList.remove('live'); cur = null; };
    const play = sec => {
      stop(); cur = sec;
      const it = items[+sec.dataset.i];
      const vv = v = document.createElement('video'); v.playsInline = true; v.setAttribute('playsinline', ''); v.loop = true; v.muted = !ST.reelSound; v.src = Src.url(it);
      v.addEventListener('playing', () => sec.classList.add('live'));
      v.addEventListener('timeupdate', () => { if (vv.duration) sec.querySelector('.rbar i').style.width = (vv.currentTime / vv.duration * 100) + '%'; });
      v.addEventListener('error', () => sec.classList.add('rerr'));
      sec.querySelector('.rv').appendChild(v); v.play().catch(() => { });
    };
    const io = new IntersectionObserver(es => { for (const e of es) if (e.isIntersecting && e.intersectionRatio > 0.7) play(e.target); else if (e.target === cur && !e.isIntersecting) stop(); }, { root: box, threshold: [0, 0.7, 1] });
    $$('.reel', box).forEach(s => io.observe(s));
    box.addEventListener('click', e => {
      const sec = e.target.closest('.reel'); if (!sec) return;
      const it = items[+sec.dataset.i];
      const f = e.target.closest('[data-rfav]'), m = e.target.closest('[data-rmute]'), o = e.target.closest('[data-ropen]'), mo = e.target.closest('[data-rmore]');
      if (f) { toggleFav(it.key); const on = isFav(it.key); f.classList.toggle('fav', on); f.innerHTML = on ? icFill('heart', 26) : ic('heart', 26); return; }
      if (m) { ST.reelSound = !ST.reelSound; saveST(); if (v) v.muted = !ST.reelSound; $$('[data-rmute]', box).forEach(b => b.innerHTML = ic(ST.reelSound ? 'vol' : 'mute', 26)); return; }
      if (o) { stop(); Player.open(items, +o.dataset.ropen); return; }
      if (mo) { Items.menu(it, { items }); return; }
      if (v && cur === sec) { v.paused ? v.play() : v.pause(); sec.classList.toggle('paused', v.paused); }
    });
    return pseudoGrid(el, items, () => { io.disconnect(); stop(); main.classList.remove('flush'); });
  },
};

/* ---------- Card stack: swipe the top card away, like a deck ---------- */
const Stack = {
  mount(el, list) {
    let i = 0; const hist = [];
    const main = $('#main');
    el.innerHTML = `<div class="stackwrap"><div class="stk"></div><div class="stkinfo"></div>
      <div class="stkbtn"><button class="ib big2" data-sk="undo" aria-label="Back">${ic('undo', 24)}</button><button class="ib big2" data-sk="fav" aria-label="Favourite">${ic('heart', 26)}</button><button class="ib big2 pri" data-sk="open" aria-label="Open">${ic('expand', 26)}</button><button class="ib big2" data-sk="menu" aria-label="More">${ic('more', 24)}</button><button class="ib big2" data-sk="shuf" aria-label="Shuffle">${ic('shuffle', 24)}</button></div></div>`;
    const stk = $('.stk', el), info = $('.stkinfo', el);
    let items = list.slice(0, 400);
    const cardHTML = (it, depth) => `<div class="sk d${depth}" data-key="${it.key}">${imgTag(it, 640)}<span class="ph">${ic(it.v ? 'film' : 'image', 40)}</span><div class="pvw"></div>
      ${it.v ? `<span class="dur">${icFill('play', 9)} ${fmtDur(it.d)}</span><span class="livebadge"><i></i>LIVE</span>` : ''}<div class="bgrad"><b>${esc(it.n)}</b><span>${esc(it.b)} · ${dateStr(it.t)}</span></div></div>`;
    const render = () => {
      Prev.stop();
      if (!items.length) { stk.innerHTML = ''; info.textContent = ''; return; }
      const n = items.length; const idx = ((i % n) + n) % n;
      stk.innerHTML = [2, 1, 0].map(d => cardHTML(items[(idx + d) % n], d)).join('');
      info.textContent = `${idx + 1} / ${n}`;
      const top = $('.sk.d0', stk); bind(top);
      if (items[idx].v) Prev.start(top);
      $('[data-sk=fav]', el).classList.toggle('fav', isFav(items[idx].key));
    };
    const cur = () => items[((i % items.length) + items.length) % items.length];
    const fling = (top, dir) => {
      top.style.transition = 'transform .28s ease-in, opacity .28s'; top.style.transform = `translate(${dir * 130}%,30px) rotate(${dir * 24}deg)`; top.style.opacity = 0;
      hist.push(i); setTimeout(() => { i++; render(); }, 240);
    };
    const bind = top => {
      let sx = 0, sy = 0, dx = 0, dy = 0, drag = false, t0 = 0;
      top.addEventListener('pointerdown', e => { drag = true; sx = e.clientX; sy = e.clientY; t0 = Date.now(); top.setPointerCapture(e.pointerId); top.style.transition = 'none'; });
      top.addEventListener('pointermove', e => { if (!drag) return; dx = e.clientX - sx; dy = e.clientY - sy; top.style.transform = `translate(${dx}px,${dy * .4}px) rotate(${dx / 18}deg)`; });
      const end = () => {
        if (!drag) return; drag = false;
        const fast = Math.abs(dx) / Math.max(1, Date.now() - t0) > 0.6;
        if (Math.abs(dx) > 110 || (fast && Math.abs(dx) > 40)) fling(top, dx > 0 ? 1 : -1);
        else if (Math.abs(dx) < 8 && Math.abs(dy) < 8) { top.style.transform = ''; openAt(cur(), items); }
        else { top.style.transition = 'transform .25s'; top.style.transform = ''; }
        dx = dy = 0;
      };
      top.addEventListener('pointerup', end); top.addEventListener('pointercancel', end);
    };
    el.addEventListener('click', e => {
      const b = e.target.closest('[data-sk]'); if (!b || !items.length) return;
      const k = b.dataset.sk;
      if (k === 'undo') { if (hist.length) { i = hist.pop(); render(); } }
      else if (k === 'fav') { toggleFav(cur().key); b.classList.toggle('fav', isFav(cur().key)); }
      else if (k === 'open') openAt(cur(), items);
      else if (k === 'menu') Items.menu(cur(), { items });
      else if (k === 'shuf') { items = items.slice().sort(() => Math.random() - .5); i = 0; hist.length = 0; render(); toast('Shuffled'); }
    });
    render();
    return pseudoGrid(el, items, () => Prev.reset());
  },
};

/* ---------- Coverflow: a 3-D carousel of pictures ---------- */
const Cover = {
  mount(el, list) {
    const items = list.slice(0, 300);
    el.innerHTML = `<div class="cvwrap"><div class="cvs">${items.map((it, i) => `<div class="cv" data-i="${i}" data-key="${it.key}">${imgTag(it, 480)}<span class="ph">${ic(it.v ? 'film' : 'image', 34)}</span>${it.v ? `<span class="dur">${fmtDur(it.d)}</span>` : ''}</div>`).join('')}</div>
      <div class="cvcap"><b id="cvn"></b><span id="cvm"></span></div><div class="row gap" style="justify-content:center;margin-top:14px"><button class="btn pri" data-cv="open">${ic('expand', 16)} Open</button><button class="btn" data-cv="fav">${ic('heart', 16)} Favourite</button><button class="btn" data-cv="menu">${ic('more', 16)}</button></div></div>`;
    const sc = $('.cvs', el); let raf = 0, ci = 0;
    const upd = () => {
      raf = 0; const r = sc.getBoundingClientRect(), mid = r.left + r.width / 2; let best = 0, bd = 1e9;
      $$('.cv', sc).forEach((c, k) => {
        const b = c.getBoundingClientRect(), off = (b.left + b.width / 2 - mid) / b.width, a = Math.abs(off);
        c.style.transform = `perspective(700px) rotateY(${Math.max(-60, Math.min(60, -off * 42))}deg) scale(${Math.max(.72, 1 - a * .16)}) translateZ(${-a * 40}px)`;
        c.style.opacity = Math.max(.35, 1 - a * .3); c.style.zIndex = 100 - Math.round(a * 10);
        if (a < bd) { bd = a; best = k; }
      });
      ci = best; const it = items[best]; $('#cvn', el).textContent = it.n; $('#cvm', el).textContent = [`${best + 1} / ${items.length}`, dateStr(it.t), sizeStr(it.s)].join(' · ');
    };
    sc.addEventListener('scroll', () => { if (!raf) raf = requestAnimationFrame(upd); }, { passive: true });
    sc.addEventListener('click', e => { const c = e.target.closest('.cv'); if (!c) return; const k = +c.dataset.i; if (k === ci) openAt(items[k], items); else c.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' }); });
    el.addEventListener('click', e => { const b = e.target.closest('[data-cv]'); if (!b) return; const it = items[ci]; if (b.dataset.cv === 'open') openAt(it, items); else if (b.dataset.cv === 'fav') { toggleFav(it.key); toast(isFav(it.key) ? 'Added to favourites' : 'Removed'); } else Items.menu(it, { items }); });
    setTimeout(upd, 60); setTimeout(upd, 400);
    return pseudoGrid(el, items);
  },
};
