'use strict';
/* ===== NerdyPlayer · video controls (this page sits on top of the native video) ===== */
const CP = Object.assign({ seek: 10, gest: true, xform: true, hold: 2, speed: 1, aspect: 0, accent: '#8b5cf6' }, store.get('np_cfg_js', {}));
document.documentElement.style.setProperty('--ac', CP.accent);
let I = {};
try { I = JSON.parse(window.P ? P.init() : '{}'); } catch (e) { }
const c = (cmd, arg = '') => { try { P.c(cmd, String(arg)); } catch (e) { } };
let st = { p: 0, d: 0, pl: false, st: 1, sp: 1, ix: I.idx || 0, a: -1, e: -1 };
let X = { rot: 0, zoom: 1, px: 0, py: 0, fh: false, fv: false, asp: CP.aspect, b: 0, ct: 100, sat: 100 };
let titles = I.titles || [], tracks = { audio: [], text: [] }, info = {}, locked = false, uiT = 0, skDrag = false, skPos = 0;
let loopMode = 0, shuf = false, speed = 1, keepPitch = true, orient = 0, muted = false, boost = 100, sleepAt = 0, sleepMode = 0;
let eq = { on: false, lv: [] }, bass = 0, subStyle = { size: 22, color: '#ffffff', bg: 0.35, off: 0 };
const ASP = [[0, 'Fit'], [1, 'Fill'], [3, 'Stretch'], [4, '16:9'], [5, '4:3'], [6, '1:1'], [7, '21:9']];
let sheetKind = '';

/* ---------- layout ---------- */
function build() {
  $('#top').innerHTML = `<button class="ib" data-a="back">${ic('back', 26)}</button><div class="tt"><b id="tt"></b><span id="tc"></span></div>
    <button class="ib" data-a="lock">${ic('lockfs', 22)}</button><button class="ib" data-a="cap">${ic('camera', 22)}</button><button class="ib" data-a="pip">${ic('pip', 22)}</button><button class="ib" data-a="more">${ic('more', 22)}</button>`;
  $('#bot').innerHTML = `<div class="sk"><span id="t1">0:00</span><div id="sk"><i class="tr"></i><i class="bf" id="bf"></i><i class="fl" id="fl"></i><span class="ab" id="ma" style="display:none"></span><span class="ab" id="mb" style="display:none"></span><span class="kn" id="kn"></span></div><span id="t2">0:00</span></div>
    <div class="ctl"><button class="ib" data-a="prev">${ic('prev', 26)}</button><button class="ib" data-a="rew">${ic('rew', 26)}</button><button class="ib pp" data-a="pp" id="ppb">${ic('play', 32)}</button><button class="ib" data-a="fwd">${ic('fwd', 26)}</button><button class="ib" data-a="next">${ic('next', 26)}</button></div>
    <div class="chips"><button class="cp" data-a="speed">${ic('speed', 16)}<span id="spl">1×</span></button><button class="cp" data-a="rot">${ic('rotater', 16)}Rotate</button><button class="cp" data-a="asp">${ic('aspect', 16)}<span id="apl">Fit</span></button><button class="cp" data-a="audio">${ic('volume', 16)}Audio</button><button class="cp" data-a="subs">${ic('subs', 16)}Subtitles</button><button class="cp" data-a="pic">${ic('sliders', 16)}Picture</button><button class="cp" data-a="list">${ic('list', 16)}Playlist</button></div>`;
  $('#ulk').innerHTML = ic('lockfs', 26);
  title();
  bindSeek();
}
function title() { $('#tt').textContent = titles[st.ix] || 'Video'; $('#tc').textContent = titles.length > 1 ? (st.ix + 1) + ' / ' + titles.length : (I.vault ? 'Private vault' : ''); }

/* ---------- state coming from the player ---------- */
window.S = s => {
  const prevIx = st.ix;
  st = s;
  if (!skDrag) paintTime(s.p);
  const pb = $('#ppb'); const pl = s.pl ? 'pause' : 'play';
  if (pb.dataset.i !== pl) { pb.dataset.i = pl; pb.innerHTML = ic(pl, 32); }
  $('#spin').style.display = s.st === 2 ? 'block' : 'none';
  const d = s.d || 1;
  $('#bf').style.width = Math.min(100, s.b / d * 100) + '%';
  const sp = $('#spl'); if (sp) sp.textContent = (+s.sp).toFixed(2).replace(/\.?0+$/, '') + '×';
  const A = $('#ma'), B = $('#mb');
  A.style.display = s.a >= 0 ? '' : 'none'; if (s.a >= 0) A.style.left = s.a / d * 100 + '%';
  B.style.display = s.e >= 0 ? '' : 'none'; if (s.e >= 0) B.style.left = s.e / d * 100 + '%';
  if (s.ix !== undefined && s.ix !== prevIx) title();
  if (s.pl && !uiT && !sheetKind) schedHide();
};
function paintTime(p) {
  const d = st.d || 1;
  $('#t1').textContent = durStr(p); $('#t2').textContent = durStr(st.d);
  const pct = Math.max(0, Math.min(100, p / d * 100));
  $('#fl').style.width = pct + '%'; $('#kn').style.left = pct + '%';
}
window.Item = i => { st.ix = i; title(); };
window.Tracks = t => { tracks = t; if (sheetKind === 'audio' || sheetKind === 'subs') panel(sheetKind); };
window.Info = o => { info = o; };
window.Cue = t => { const e = $('#sub'); e.innerHTML = t ? `<span>${esc(t)}</span>` : ''; styleSub(); };
window.Pip = b => { document.body.classList.toggle('pip', b); if (b) closeSheet(); };
window.Sleep = () => { sleepAt = 0; toast('Sleep timer: video paused'); };
window.Toast = m => toast(m);
window.Err = code => {
  const e = $('#err');
  e.innerHTML = `${ic('warn', 34)}<h3 style="margin:8px 0 0">Can’t play this video</h3><p>The phone’s decoder could not handle it (${esc(code)}).</p><button class="cp" data-a="next">Next</button><button class="cp" data-a="back">Close</button>`;
  e.classList.add('on'); setTimeout(() => e.classList.remove('on'), 9000);
};
window.Back = () => {
  if ($('#err').classList.contains('on')) { $('#err').classList.remove('on'); return true; }
  if (sheetKind) { closeSheet(); return true; }
  if (locked) { showUlk(); return true; }
  return false;
};
function styleSub() {
  const e = $('#sub'); e.style.fontSize = subStyle.size + 'px'; e.style.color = subStyle.color; e.style.bottom = (96 + subStyle.off) + 'px';
  const sp = $('span', e); if (sp) sp.style.background = `rgba(0,0,0,${subStyle.bg})`;
}

/* ---------- controls visibility ---------- */
function showUI() { document.body.classList.remove('hide'); clearTimeout(uiT); uiT = 0; }
function schedHide() { clearTimeout(uiT); uiT = setTimeout(() => { uiT = 0; if (!sheetKind && st.pl) document.body.classList.add('hide'); }, 3800); }
function toggleUI() { if (document.body.classList.contains('hide')) { showUI(); schedHide(); } else { document.body.classList.add('hide'); } }
function hud(html, ms = 700) { const h = $('#hud'); h.innerHTML = html; h.style.display = 'block'; clearTimeout(hud.t); hud.t = setTimeout(() => h.style.display = 'none', ms); }
function bar(p) { return `<div class="hb"><i style="width:${Math.round(p * 100)}%"></i></div>`; }

/* ---------- seek bar ---------- */
function bindSeek() {
  const sk = $('#sk');
  const at = e => { const r = sk.getBoundingClientRect(); return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * st.d; };
  sk.addEventListener('pointerdown', e => { skDrag = true; sk.setPointerCapture(e.pointerId); skPos = at(e); paintTime(skPos); clearTimeout(uiT); });
  sk.addEventListener('pointermove', e => { if (skDrag) { skPos = at(e); paintTime(skPos); } });
  const end = e => { if (!skDrag) return; skDrag = false; c('seek', Math.round(skPos)); schedHide(); };
  sk.addEventListener('pointerup', end); sk.addEventListener('pointercancel', end);
}

/* ---------- gestures on the picture ---------- */
const ptr = new Map();
let gs = null, pinch = null, raf = 0;
const g = $('#g');
g.addEventListener('pointerdown', e => {
  g.setPointerCapture(e.pointerId); ptr.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (ptr.size === 1) {
    gs = { x0: e.clientX, y0: e.clientY, t0: Date.now(), mode: null, pos0: st.p, bri0: I.bri == null ? 0.5 : I.bri, vol0: I.vol == null ? 0.5 : I.vol, target: 0 };
    gs.lp = setTimeout(() => { if (gs && !gs.mode && !locked) { gs.mode = 'hold'; c('tmpspeed', CP.hold); hud(ic('fwd', 30) + ' ' + CP.hold + '× speed', 99999); } }, 520);
  } else if (ptr.size === 2 && CP.xform && !locked) {
    if (gs) { clearTimeout(gs.lp); if (gs.mode === 'hold') { c('tmpspeed', st.sp); } gs.mode = 'pinch'; }
    const [a, b] = [...ptr.values()];
    pinch = { d0: Math.hypot(a.x - b.x, a.y - b.y) || 1, z0: X.zoom, a0: Math.atan2(b.y - a.y, b.x - a.x), r0: X.rot, mx0: (a.x + b.x) / 2, my0: (a.y + b.y) / 2, px0: X.px, py0: X.py };
  }
});
g.addEventListener('pointermove', e => {
  if (!ptr.has(e.pointerId)) return; ptr.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (!gs || locked) return;
  if (gs.mode === 'pinch' && ptr.size >= 2 && pinch) {
    const [a, b] = [...ptr.values()];
    X.zoom = Math.max(0.3, Math.min(8, pinch.z0 * Math.hypot(a.x - b.x, a.y - b.y) / pinch.d0));
    X.rot = pinch.r0 + (Math.atan2(b.y - a.y, b.x - a.x) - pinch.a0) * 180 / Math.PI;
    X.px = pinch.px0 + ((a.x + b.x) / 2 - pinch.mx0); X.py = pinch.py0 + ((a.y + b.y) / 2 - pinch.my0);
    if (!raf) raf = requestAnimationFrame(() => { raf = 0; c('xf', [X.rot, X.zoom, X.px, X.py].join(',')); });
    hud(Math.round(X.zoom * 100) + '%<small>' + Math.round(((X.rot % 360) + 360) % 360) + '°</small>', 600);
    return;
  }
  if (ptr.size !== 1) return;
  const dx = e.clientX - gs.x0, dy = e.clientY - gs.y0, W = innerWidth, H = innerHeight;
  if (!gs.mode && Math.hypot(dx, dy) > 14) {
    clearTimeout(gs.lp);
    gs.mode = !CP.gest ? 'none' : (Math.abs(dx) > Math.abs(dy) * 1.2 ? 'seek' : (gs.x0 < W / 2 ? 'bri' : 'vol'));
  }
  if (gs.mode === 'seek') {
    gs.target = Math.max(0, Math.min(st.d, gs.pos0 + dx / W * 120000));
    const diff = Math.round((gs.target - gs.pos0) / 1000);
    hud(durStr(gs.target) + '<small>' + (diff >= 0 ? '+' : '') + diff + 's</small>', 99999);
  } else if (gs.mode === 'bri') {
    const v = Math.max(0.02, Math.min(1, gs.bri0 - dy / (H * 0.7))); I.bri = v; gs.bri0 = v; c('bri', v);
    gs.y0 = e.clientY;
    hud(ic('sun', 26) + '<br>' + Math.round(v * 100) + '%' + bar(v), 700);
  } else if (gs.mode === 'vol') {
    const v = Math.max(0, Math.min(1, gs.vol0 - dy / (H * 0.7))); I.vol = v; gs.vol0 = v; c('vol', v);
    gs.y0 = e.clientY;
    hud(ic(v ? 'volume' : 'mute', 26) + '<br>' + Math.round(v * 100) + '%' + bar(v), 700);
  }
});
function gUp(e) {
  if (!ptr.has(e.pointerId)) return; ptr.delete(e.pointerId);
  if (!gs) return;
  if (gs.mode === 'pinch') {
    if (ptr.size === 0) {
      const r = Math.round(X.rot / 90) * 90; if (Math.abs(X.rot - r) < 9) { X.rot = r; }
      c('xf', [X.rot, X.zoom, X.px, X.py].join(',')); $('#hud').style.display = 'none'; clearTimeout(gs.lp); gs = null; pinch = null;
    }
    return;
  }
  if (ptr.size > 0) return;
  const s = gs; gs = null; clearTimeout(s.lp);
  if (s.mode === 'hold') { c('tmpspeed', st.sp); $('#hud').style.display = 'none'; return; }
  if (s.mode === 'seek') { c('seek', Math.round(s.target)); $('#hud').style.display = 'none'; return; }
  if (s.mode) { return; }
  if (Date.now() - s.t0 < 350) onTap(e.clientX);
}
g.addEventListener('pointerup', gUp); g.addEventListener('pointercancel', gUp);
let tapN = 0, tapT = 0, tapSide = 9, tapTimer = 0;
function onTap(x) {
  if (locked) { showUlk(); return; }
  const side = x < innerWidth * 0.33 ? -1 : x > innerWidth * 0.67 ? 1 : 0, now = Date.now();
  tapN = (now - tapT < 330 && side === tapSide) ? tapN + 1 : 1; tapT = now; tapSide = side;
  clearTimeout(tapTimer);
  if (tapN >= 2) {
    if (side === 0) { c('toggle'); hud(ic(st.pl ? 'pause' : 'play', 34), 500); }
    else { c('seekby', side * CP.seek * 1000); hud(ic(side < 0 ? 'rew' : 'fwd', 28) + '<small>' + (tapN - 1) * CP.seek + ' s</small>', 600); }
    tapTimer = setTimeout(() => { tapN = 0; }, 340); return;
  }
  tapTimer = setTimeout(() => { tapN = 0; toggleUI(); }, 320);
}

/* ---------- screen lock ---------- */
function showUlk() { const u = $('#ulk'); u.classList.add('on'); clearTimeout(showUlk.t); showUlk.t = setTimeout(() => u.classList.remove('on'), 2600); }
function setLock(v) {
  locked = v; document.body.classList.toggle('lk', v); $('#ulk').classList.remove('on');
  if (v) { document.body.classList.add('hide'); closeSheet(); toast('Touch lock on. Tap the screen, then the lock.'); } else { showUI(); schedHide(); }
}
$('#ulk').addEventListener('click', () => setLock(false));

/* ---------- buttons ---------- */
document.addEventListener('click', e => {
  const b = e.target.closest('[data-a]'); if (!b) return;
  const a = b.dataset.a;
  if (a !== 'more') schedHideSoon();
  ({
    back: () => c('close'), lock: () => setLock(true), cap: () => c('cap'), pip: () => c('pip'), more: () => panel('more'),
    prev: () => c('prev'), next: () => { $('#err').classList.remove('on'); c('next'); }, rew: () => c('seekby', -CP.seek * 1000), fwd: () => c('seekby', CP.seek * 1000), pp: () => c('toggle'),
    speed: () => panel('speed'), rot: () => { X.rot = Math.round((X.rot + 90) / 90) * 90; X.px = X.py = 0; send(); hud(ic('rotater', 28) + '<small>' + (((X.rot % 360) + 360) % 360) + '°</small>'); },
    asp: () => { const i = ASP.findIndex(a => a[0] === X.asp); X.asp = ASP[(i + 1) % ASP.length][0]; c('asp', X.asp); aspLabel(); hud(ASP.find(a => a[0] === X.asp)[1]); },
    audio: () => panel('audio'), subs: () => panel('subs'), pic: () => panel('pic'), list: () => panel('list')
  })[a]();
});
function schedHideSoon() { if (!sheetKind) schedHide(); }
function send() { c('xf', [X.rot, X.zoom, X.px, X.py].join(',')); }
function aspLabel() { const l = $('#apl'); if (l) l.textContent = (ASP.find(a => a[0] === X.asp) || ASP[0])[1]; }

/* ---------- sheets ---------- */
function closeSheet() { sheetKind = ''; $('#sheet').classList.remove('on'); $('#sheetbg').classList.remove('on'); schedHide(); }
$('#sheetbg').addEventListener('click', closeSheet);
const seg = (id, arr, v) => `<div class="seg" id="${id}">${arr.map(a => `<button data-v="${a[0]}" class="${String(a[0]) === String(v) ? 'on' : ''}">${a[1]}</button>`).join('')}</div>`;
const slider = (id, label, min, max, v, step = 1, fmt = x => x) => `<label class="sl"><span>${label}</span><span id="${id}-l">${fmt(v)}</span></label><input type="range" data-r="${id}" min="${min}" max="${max}" step="${step}" value="${v}">`;
const opt = (i, t, s, on, data) => `<button class="opt ${on ? 'on' : ''}" ${data}><span>${ic(i, 20)}</span><span class="grow">${esc(t)}${s ? `<div class="mut">${esc(s)}</div>` : ''}</span>${on ? ic('check', 18) : ''}</button>`;
const tgl = (id, v) => `<button class="tg ${v ? 'on' : ''}" data-tg="${id}"></button>`;
const rowT = (t, s, id, v) => `<div class="opt" style="cursor:default"><span class="grow">${t}${s ? `<div class="mut">${s}</div>` : ''}</span>${tgl(id, v)}</div>`;

function panel(kind) {
  sheetKind = kind; showUI(); clearTimeout(uiT);
  const sh = $('#sheet'); $('#sheetbg').classList.add('on'); sh.classList.add('on');
  const head = t => `<h3><span>${t}</span><button class="ib" style="width:36px;height:36px" data-x="close">${ic('close', 20)}</button></h3>`;
  let h = '';
  if (kind === 'more') {
    h = head('More') + [['speed', 'speed', 'Speed', (+st.sp).toFixed(2) + '×'], ['sliders', 'pic', 'Picture & filters', 'Rotate, flip, zoom, colour'], ['volume', 'audio', 'Audio, boost & equalizer', ''], ['subs', 'subs', 'Subtitles', ''], ['loop', 'play2', 'Playback options', 'Loop, A-B repeat, sleep timer'], ['list', 'list', 'Playlist', titles.length + ' video' + (titles.length === 1 ? '' : 's')], ['info', 'info', 'Video details', ''], ['camera', 'cap', 'Save this frame', 'Into Pictures/NerdyPlayer'], ['pip', 'pip', 'Picture-in-picture', ''], ['lockfs', 'lock', 'Lock touch screen', '']].map(o => opt(o[0], o[2], o[3], false, `data-go="${o[1]}"`)).join('');
  } else if (kind === 'speed') {
    h = head('Speed') + `<div class="big" id="spv">${(+st.sp).toFixed(2)}×</div><input type="range" data-r="sp" min="0.25" max="4" step="0.05" value="${st.sp}">
      <div class="seg" id="spp" style="margin-top:12px">${[0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4].map(n => `<button data-v="${n}" class="${Math.abs(st.sp - n) < 0.001 ? 'on' : ''}">${n}×</button>`).join('')}</div>
      ${rowT('Keep the voice natural', 'Pitch stays the same at any speed', 'pitch', keepPitch)}`;
  } else if (kind === 'pic') {
    h = head('Picture') + `<div class="seg"><button data-pa="l90">${ic('rotate', 15)} −90°</button><button data-pa="r90">${ic('rotater', 15)} +90°</button><button data-pa="fh">${ic('flip', 15)} Flip ↔</button><button data-pa="fv">${ic('flipv', 15)} Flip ↕</button></div>
      ${slider('rot', 'Angle', -180, 180, Math.round(((X.rot + 180) % 360 + 360) % 360 - 180), 1, v => v + '°')}${slider('zm', 'Zoom', 30, 400, Math.round(X.zoom * 100), 5, v => v + '%')}
      <div class="mut" style="margin-top:12px">Picture size</div><div class="seg" id="asg">${ASP.map(a => `<button data-v="${a[0]}" class="${X.asp === a[0] ? 'on' : ''}">${a[1]}</button>`).join('')}</div>
      ${slider('fb', 'Brightness', -50, 50, X.b, 1, v => v)}${slider('fc', 'Contrast', 50, 160, X.ct, 1, v => v + '%')}${slider('fs', 'Colour', 0, 200, X.sat, 1, v => v + '%')}
      <div class="seg" style="margin-top:14px"><button data-pa="reset">Reset picture</button></div>`;
  } else if (kind === 'audio') {
    let fx = {}; try { fx = JSON.parse(P.fx()); } catch (e) { }
    const bands = fx.bands || [];
    if (bands.length && eq.lv.length !== bands.length) eq.lv = bands.map(() => 0);
    h = head('Audio') + (tracks.audio.length ? '<div class="mut">Audio tracks</div>' + tracks.audio.map((t, i) => opt('music', t.l, '', t.s, `data-au="${i}"`)).join('') : '<div class="mut" style="margin-bottom:6px">This video has one audio track.</div>')
      + rowT('Mute', '', 'mute', muted) + slider('bo', 'Volume boost', 100, 300, boost, 5, v => v + '%')
      + (bands.length ? `<h3 style="margin-top:16px"><span>Equalizer</span>${tgl('eq', eq.on)}</h3>
        <div class="seg" id="eqp">${['Flat', 'Bass', 'Treble', 'Vocal', 'Rock', 'Pop'].map(n => `<button data-v="${n}">${n}</button>`).join('')}</div>
        <div class="eqb">${bands.map((f, i) => `<div><input type="range" data-eq="${i}" min="${fx.min}" max="${fx.max}" value="${eq.lv[i] || 0}"><span>${f >= 1000 ? (f / 1000) + 'k' : f}</span></div>`).join('')}</div>` : '')
      + (fx.bass ? slider('bb', 'Bass boost', 0, 1000, bass, 10, v => Math.round(v / 10) + '%') : '');
  } else if (kind === 'subs') {
    h = head('Subtitles') + opt('close', 'Off', '', !tracks.text.some(t => t.s), 'data-tx="-1"') + tracks.text.map((t, i) => opt('subs', t.l, '', t.s, `data-tx="${i}"`)).join('')
      + `<button class="opt" data-a2="pickSub"><span>${ic('plus', 20)}</span><span class="grow">Load subtitle file…<div class="mut">.srt  .vtt  .ass</div></span></button>`
      + slider('ss', 'Text size', 14, 44, subStyle.size, 1, v => v + 'px') + slider('so', 'Raise from bottom', 0, 200, subStyle.off, 5, v => v)
      + slider('sb', 'Background', 0, 100, Math.round(subStyle.bg * 100), 5, v => v + '%')
      + `<div class="seg" id="scl" style="margin-top:10px">${[['#ffffff', 'White'], ['#fde047', 'Yellow'], ['#67e8f9', 'Cyan'], ['#86efac', 'Green']].map(a => `<button data-v="${a[0]}" class="${subStyle.color === a[0] ? 'on' : ''}">${a[1]}</button>`).join('')}</div>`;
  } else if (kind === 'play2') {
    const ab = (st.a >= 0 ? 'A ' + durStr(st.a) : 'A —') + '  ·  ' + (st.e >= 0 ? 'B ' + durStr(st.e) : 'B —');
    h = head('Playback') + '<div class="mut">Repeat</div>' + seg('lp', [[0, 'Off'], [1, 'This video'], [2, 'All']], loopMode)
      + rowT('Shuffle', 'Random order in the playlist', 'shuf', shuf)
      + `<div class="mut" style="margin-top:12px">A-B repeat · ${ab}</div><div class="seg"><button data-ab="A">Set A</button><button data-ab="B">Set B</button><button data-ab="X">Clear</button></div>`
      + '<div class="mut">Sleep timer' + (sleepAt ? ' · ' + Math.max(1, Math.round((sleepAt - Date.now()) / 60000)) + ' min left' : '') + '</div>' + seg('sl', [[0, 'Off'], [15, '15 min'], [30, '30 min'], [45, '45 min'], [60, '1 hour'], [-1, 'End of video']], sleepMode)
      + '<div class="mut">Screen direction</div>' + seg('or', [[0, 'Auto'], [1, 'Portrait'], [2, 'Landscape']], orient);
  } else if (kind === 'info') {
    const kv = (a, b) => b ? `<div class="kv"><span>${a}</span><b>${esc(b)}</b></div>` : '';
    h = head('Video details') + kv('Name', titles[st.ix]) + kv('Length', durStr(st.d)) + kv('Resolution', info.w ? info.w + ' × ' + info.h : '') + kv('Frame rate', info.fps > 0 ? Math.round(info.fps * 100) / 100 + ' fps' : '')
      + kv('Video codec', (info.vc || '').replace('video/', '') + (info.vcodec ? ' · ' + info.vcodec : '')) + kv('Video bitrate', info.vb > 0 ? (info.vb / 1e6).toFixed(2) + ' Mbps' : '')
      + kv('Audio codec', (info.ac || '').replace('audio/', '')) + kv('Audio', info.ach ? info.ach + ' ch · ' + info.ahz + ' Hz' : '') + kv('Audio bitrate', info.ab > 0 ? Math.round(info.ab / 1000) + ' kbps' : '');
  } else if (kind === 'list') {
    h = head('Playlist') + titles.map((t, i) => opt(i === st.ix ? 'play' : 'film', t, '', i === st.ix, `data-gt="${i}"`)).join('');
  }
  sh.innerHTML = h;
  const cur = sh.querySelector('.opt.on'); if (cur && kind === 'list') cur.scrollIntoView({ block: 'center' });
}

document.getElementById('sheet').addEventListener('click', e => {
  const t = e.target;
  let b;
  if (t.closest('[data-x]')) return closeSheet();
  if ((b = t.closest('[data-go]'))) {
    const k = b.dataset.go;
    if (k === 'cap') { closeSheet(); return c('cap'); } if (k === 'pip') { closeSheet(); return c('pip'); } if (k === 'lock') { closeSheet(); return setLock(true); }
    return panel(k);
  }
  if ((b = t.closest('#spp button'))) { const v = +b.dataset.v; c('speed', v); st.sp = v; return panel('speed'); }
  if ((b = t.closest('[data-pa]'))) {
    const k = b.dataset.pa;
    if (k === 'l90') X.rot = Math.round((X.rot - 90) / 90) * 90; else if (k === 'r90') X.rot = Math.round((X.rot + 90) / 90) * 90;
    else if (k === 'fh') { X.fh = !X.fh; c('flip', 'h'); } else if (k === 'fv') { X.fv = !X.fv; c('flip', 'v'); }
    else if (k === 'reset') { X = { rot: 0, zoom: 1, px: 0, py: 0, fh: false, fv: false, asp: 0, b: 0, ct: 100, sat: 100 }; c('reset'); aspLabel(); return panel('pic'); }
    if (k === 'l90' || k === 'r90') { X.px = X.py = 0; send(); } return panel('pic');
  }
  if ((b = t.closest('#asg button'))) { X.asp = +b.dataset.v; c('asp', X.asp); aspLabel(); return panel('pic'); }
  if ((b = t.closest('[data-au]'))) { c('audio', b.dataset.au); return; }
  if ((b = t.closest('[data-tx]'))) { c('text', b.dataset.tx); return; }
  if ((b = t.closest('[data-a2]'))) { closeSheet(); return c('pickSub'); }
  if ((b = t.closest('#scl button'))) { subStyle.color = b.dataset.v; styleSub(); return panel('subs'); }
  if ((b = t.closest('#lp button'))) { loopMode = +b.dataset.v; c('loop', loopMode); return panel('play2'); }
  if ((b = t.closest('#sl button'))) {
    sleepMode = +b.dataset.v; c('sleep', sleepMode); sleepAt = sleepMode > 0 ? Date.now() + sleepMode * 60000 : 0;
    toast(sleepMode === 0 ? 'Sleep timer off' : sleepMode < 0 ? 'Will stop after this video' : 'Will pause in ' + sleepMode + ' min'); return panel('play2');
  }
  if ((b = t.closest('#or button'))) { orient = +b.dataset.v; c('orient', orient); return panel('play2'); }
  if ((b = t.closest('[data-ab]'))) { c('ab' + b.dataset.ab); setTimeout(() => panel('play2'), 350); return; }
  if ((b = t.closest('#eqp button'))) {
    const P5 = { Flat: [0, 0, 0, 0, 0], Bass: [.8, .5, 0, 0, 0], Treble: [0, 0, 0, .5, .8], Vocal: [-.3, 0, .6, .4, -.2], Rock: [.6, .3, -.2, .3, .6], Pop: [-.2, .3, .6, .3, -.2] }[b.dataset.v];
    let fx = {}; try { fx = JSON.parse(P.fx()); } catch (er) { }
    const n = (fx.bands || []).length || 5;
    eq.lv = Array.from({ length: n }, (_, i) => { const f = P5[Math.round(i * 4 / Math.max(1, n - 1))]; return Math.round(f * (f >= 0 ? fx.max : -fx.min)); });
    eq.on = true; c('eq', '1|' + eq.lv.join(',')); return panel('audio');
  }
  if ((b = t.closest('[data-gt]'))) { c('goto', b.dataset.gt); st.ix = +b.dataset.gt; title(); return closeSheet(); }
  if ((b = t.closest('[data-tg]'))) {
    const k = b.dataset.tg;
    if (k === 'pitch') { keepPitch = !keepPitch; c('pitch', keepPitch ? 1 : 0); return panel('speed'); }
    if (k === 'mute') { muted = !muted; c('mute', muted ? 1 : 0); return panel('audio'); }
    if (k === 'shuf') { shuf = !shuf; c('shuffle', shuf ? 1 : 0); return panel('play2'); }
    if (k === 'eq') { eq.on = !eq.on; c('eq', (eq.on ? '1' : '0') + '|' + eq.lv.join(',')); return panel('audio'); }
  }
});
document.getElementById('sheet').addEventListener('input', e => {
  const r = e.target; const id = r.dataset.r, v = +r.value;
  const lab = id ? document.getElementById(id + '-l') : null;
  if (r.dataset.eq !== undefined) { eq.lv[+r.dataset.eq] = v; eq.on = true; c('eq', '1|' + eq.lv.join(',')); return; }
  if (id === 'sp') { c('speed', v); st.sp = v; const el = $('#spv'); if (el) el.textContent = v.toFixed(2) + '×'; return; }
  if (id === 'rot') { X.rot = v; send(); }
  else if (id === 'zm') { X.zoom = v / 100; send(); }
  else if (id === 'fb' || id === 'fc' || id === 'fs') { if (id === 'fb') X.b = v; if (id === 'fc') X.ct = v; if (id === 'fs') X.sat = v; c('flt', [X.b / 100, X.ct / 100, X.sat / 100].join(',')); }
  else if (id === 'bo') { boost = v; c('boost', v <= 100 ? 0 : Math.round(2000 * Math.log10(v / 100))); }
  else if (id === 'bb') { bass = v; c('bass', v); }
  else if (id === 'ss') { subStyle.size = v; styleSub(); }
  else if (id === 'so') { subStyle.off = v; styleSub(); }
  else if (id === 'sb') { subStyle.bg = v / 100; styleSub(); }
  if (lab) {
    const f = { rot: v + '°', zm: v + '%', fb: v, fc: v + '%', fs: v + '%', bo: v + '%', bb: Math.round(v / 10) + '%', ss: v + 'px', so: v, sb: v + '%' }[id];
    if (f !== undefined) lab.textContent = f;
  }
});

/* ---------- start ---------- */
build();
aspLabel();
if (CP.speed && CP.speed !== 1) { c('speed', CP.speed); }
if (CP.aspect) c('asp', CP.aspect);
c('play');
showUI(); setTimeout(schedHide, 100);
