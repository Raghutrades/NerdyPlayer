'use strict';
/* ===== NerdyPlayer · the video player =====
   Gestures like MX Player, plus the things the others don't give you: free-angle rotation, flip,
   live video filters, volume boost + equalizer, audio delay, subtitle styling + timing,
   A-B loop, frame step, bookmarks, screenshots, sleep timer and per-video memory. */

const ASPECTS = { '16:9': 16 / 9, '4:3': 4 / 3, '21:9': 21 / 9, '1:1': 1, '9:16': 9 / 16 };
const EQ_PRESETS = { Flat: [0, 0, 0], 'Bass boost': [9, 0, 0], Voice: [-3, 5, 2], Treble: [-2, 0, 8], Movie: [6, 1, 4], Night: [-4, 3, -3] };
const SPEEDS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4];

const Player = {
  active: false, built: false, items: [], i: 0, vault: false,
  rot: 0, fx: 1, fy: 1, z: 1, px: 0, py: 0, fit: 'fit', adj: {}, orient: 'auto',
  ab: { a: null, b: null }, locked: false, ui: true, subs: [], subName: '', subDelay: 0, subOn: true,
  sleepAt: 0, sleepEnd: false, inPip: false, wasPlaying: false, vol: 1,
  eq: { bass: 0, mid: 0, treble: 0 }, boost: 1, adelay: 0, mono: false,

  build() {
    if (this.built) return;
    const p = $('#player');
    p.innerHTML = `<div class="pview" id="pview"><video id="pv" playsinline preload="auto" disablepictureinpicture></video></div>
      <div class="psub" id="psub"></div>
      <div class="pgest" id="pgest"></div>
      <div class="pind" id="pind"></div>
      <button class="presume" id="presume" hidden></button>
      <div class="pbuf" id="pbuf" hidden><div class="spin"></div></div>
      <div class="pctl" id="pctl">
        <div class="ptop"><button class="pb" data-act="p-back" aria-label="Back">${ic('left', 24)}</button><div class="ptt"><b id="ptitle"></b><small id="psubt"></small></div>
          <button class="pb" data-act="p-pip" id="ppipb" aria-label="Picture in picture">${ic('pip', 22)}</button><button class="pb" data-act="p-more" aria-label="More">${ic('more', 22)}</button></div>
        <div class="pbot">
          <div class="seekrow"><span id="ptc">0:00</span><div class="seekwrap"><div class="marks" id="pmarks"></div><input type="range" id="pseek" min="0" max="1000" value="0" step="1" aria-label="Seek"><div class="sbub" id="psbub" hidden></div></div><span id="ptd">0:00</span></div>
          <div class="mainrow">
            <button class="pb sm" data-act="p-lock" aria-label="Lock controls">${ic('lock', 22)}</button>
            <button class="pb" data-act="p-prev" aria-label="Previous">${ic('prev', 24)}</button>
            <button class="pb seekb" data-act="p-rew" aria-label="Back">${ic('rew', 28)}<i id="prewl">10</i></button>
            <button class="pb big" data-act="p-play" id="pplay" aria-label="Play">${icFill('play', 30)}</button>
            <button class="pb seekb" data-act="p-ff" aria-label="Forward">${ic('ff', 28)}<i id="pffl">10</i></button>
            <button class="pb" data-act="p-next" aria-label="Next">${ic('next', 24)}</button>
            <button class="pb sm txt" data-act="p-panel" data-v="speed" id="pspd">1×</button>
          </div>
          <div class="toolrow" id="ptools"></div>
        </div>
      </div>
      <div class="plock" id="plock" hidden><button data-act="p-unlock" aria-label="Unlock">${ic('lock', 26)}<span>Hold to unlock</span></button></div>
      <div class="perr" id="perr" hidden></div>`;
    this.v = $('#pv'); this.view = $('#pview'); this.gest = $('#pgest');
    const T = [['gauge', 'Speed', 'speed'], ['rotcw', 'Rotate & flip', 'tf'], ['wand', 'Filters', 'fx'], ['vol', 'Audio', 'audio'], ['cc', 'Subtitles', 'sub'], ['ab', 'A–B loop', 'ab'], ['film', 'Frame step', 'frame'],
      ['camera', 'Capture', 'shot'], ['bookmark', 'Bookmarks', 'mark'], ['timer', 'Sleep', 'sleep'], ['repeat', 'Play mode', 'mode'], ['list', 'Queue', 'queue'], ['info', 'Info', 'info']];
    $('#ptools').innerHTML = T.map(t => `<button class="tc" data-act="p-panel" data-v="${t[2]}">${ic(t[0], 20)}<span>${t[1]}</span></button>`).join('');
    this.bindVideo(); this.bindGestures(); this.bindSeek();
    window.addEventListener('resize', () => { if (this.active) this.layout(); });
    document.addEventListener('keydown', e => {
      if (!this.active) return; const k = e.key;
      if (k === ' ') { e.preventDefault(); this.toggle(); } else if (k === 'ArrowRight') this.skip(ST.seek); else if (k === 'ArrowLeft') this.skip(-ST.seek);
      else if (k === 'ArrowUp') this.setVol(this.vol + .05); else if (k === 'ArrowDown') this.setVol(this.vol - .05);
      else if (k === 'Escape') this.back(); else if (k === 'n') this.next(); else if (k === 'p') this.prev(); else if (k === '.') this.frame(1); else if (k === ',') this.frame(-1);
    });
    this.built = true;
  },

  /* ----- open / close ----- */
  open(items, idx, o = {}) {
    this.build();
    if (!items.length) return;
    this.items = items; this.vault = !!o.vault; this.active = true; this.locked = false;
    $('#player').hidden = false; requestAnimationFrame(() => $('#player').classList.add('on'));
    Dev.bars('#000000', false); Dev.fullscreen(true);
    $('#plock').hidden = true; $('#perr').hidden = true;
    this.ui = true; this.showUI(true);
    this.load(clamp(idx, 0, items.length - 1));
  },
  get cur() { return this.items[this.i]; },
  load(idx) {
    const it = this.items[idx]; if (!it) return;
    this.saveNow();
    this.i = idx; const v = this.v;
    this.rot = 0; this.fx = 1; this.fy = 1; this.z = 1; this.px = 0; this.py = 0; this.fit = ST.fit; this.ab = { a: null, b: null };
    this.subs = []; this.subName = ''; this.subDelay = 0; $('#psub').innerHTML = '';
    this.adj = Object.assign({}, UD.filt[it.key] || {});
    $('#perr').hidden = true; $('#presume').hidden = true;
    v.pause(); v.removeAttribute('src'); v.src = Src.url(it); v.load();
    v.playbackRate = ST.remSpeed && UD.speed[it.key] ? UD.speed[it.key] : ST.speed;
    v.defaultPlaybackRate = v.playbackRate;
    this.ended = false; this.meta = false;
    $('#ptitle').textContent = it.n;
    $('#psubt').textContent = `${idx + 1} / ${this.items.length}` + (it.w ? ` · ${it.w}×${it.h}` : '');
    $('#prewl').textContent = $('#pffl').textContent = ST.seek;
    $('#pbuf').hidden = false;
    this.updateSpeedChip(); this.applyFilter(); this.layout();
    if (!it.ext && !it.vault) pushHist(it.key);
    const pr = !it.ext && ST.resume ? posOf(it.key) : null;
    this.startAt = pr ? Math.max(0, pr.t - 2) : 0;
    v.play().catch(() => { this.syncPlay(); });
    if (this.ac) try { this.ac.resume(); } catch (e) { }
    Native.call('armPip', ST.pip !== false, it.w || 16, it.h || 9);
  },
  saveNow() {
    const it = this.cur; if (!it || !this.v || !this.meta || it.ext || it.vault) return;
    const d = this.v.duration; if (isFinite(d)) savePos(it.key, this.ended ? 0 : this.v.currentTime, d);
  },
  close() {
    if (!this.active) return;
    this.saveNow(); this.closeSheet();
    this.active = false; this.v.pause(); this.v.removeAttribute('src'); this.v.load();
    clearTimeout(this.hideT); clearTimeout(this.sleepT);
    this.sleepAt = 0; this.sleepEnd = false;
    const p = $('#player'); p.classList.remove('on'); setTimeout(() => { if (!this.active) p.hidden = true; }, 200);
    Dev.brightness.set(-1); Dev.orientation('auto'); Dev.fullscreen(false); Dev.keepOn(false); applyTheme();
    Native.call('armPip', false, 16, 9);
    if (App.view === 'videos' || App.view === 'home') App.render();
  },
  back() {
    if (this.locked) return;
    if (Sheet.isOpen) return Sheet.close();
    this.close();
  },
  forceClose() { if (this.active) { this.v.pause(); this.close(); } },
  closeSheet() { if (Sheet.isOpen) Sheet.close(); },
  onPause(inPip) {
    if (!this.active) return;
    this.saveNow();
    if (inPip || this.inPip) return;
    if (ST.bg === 'pause' && !this.v.paused) { this.wasPlaying = true; this.v.pause(); } else this.wasPlaying = false;
  },
  onResume() { if (this.active) this.layout(); },
  onPip(on) {
    this.inPip = on; $('#player').classList.toggle('pip', on);
    if (on) { this.showUI(false); } else { this.showUI(true); this.layout(); }
  },

  /* ----- the <video> element ----- */
  bindVideo() {
    const v = this.v;
    v.addEventListener('loadedmetadata', () => {
      this.meta = true; const it = this.cur;
      if (it && !it.d) it.d = v.duration * 1000; if (it && (!it.w) && v.videoWidth) { it.w = v.videoWidth; it.h = v.videoHeight; $('#psubt').textContent = `${this.i + 1} / ${this.items.length} · ${it.w}×${it.h}`; }
      if (this.startAt > 0 && this.startAt < v.duration - 3) {
        v.currentTime = this.startAt;
        const b = $('#presume'); b.hidden = false; b.innerHTML = `${ic('undo', 14)} Resumed at ${fmtTime(this.startAt + 2)} · Start over`;
        b.onclick = () => { v.currentTime = 0; b.hidden = true; }; setTimeout(() => b.hidden = true, 6000);
      }
      this.startAt = 0;
      if (ST.autoland && this.orient === 'auto') Dev.orientation(v.videoWidth >= v.videoHeight ? 'landscape' : 'portrait');
      this.layout(); this.tick(true);
    });
    v.addEventListener('play', () => { this.syncPlay(); this.raf(); Dev.keepOn(ST.keepon); if (this.ac) try { this.ac.resume(); } catch (e) { } });
    v.addEventListener('pause', () => { this.syncPlay(); Dev.keepOn(false); this.saveNow(); this.showUI(true); });
    v.addEventListener('waiting', () => { $('#pbuf').hidden = false; });
    v.addEventListener('playing', () => { $('#pbuf').hidden = true; });
    v.addEventListener('canplay', () => { $('#pbuf').hidden = true; });
    v.addEventListener('seeked', () => { $('#pbuf').hidden = true; });
    v.addEventListener('ratechange', () => this.updateSpeedChip());
    v.addEventListener('ended', () => this.onEnded());
    v.addEventListener('error', () => this.onError());
    v.addEventListener('timeupdate', () => this.tick());
    setInterval(() => { if (this.active && !v.paused) this.saveNow(); }, 5000);
    setInterval(() => { if (this.active && this.sleepAt && Date.now() >= this.sleepAt) { this.sleepAt = 0; v.pause(); toast('Sleep timer: paused'); } }, 1000);
  },
  onError() {
    const it = this.cur; if (!it || !this.active) return;
    $('#pbuf').hidden = true; const e = $('#perr');
    e.hidden = false;
    e.innerHTML = `${ic('film', 40)}<h3>This phone can't decode this video here</h3><p>${esc(it.n)}<br>The built-in player handles MP4, WebM, 3GP and most MKV. Some AVI, WMV, FLV or newer codecs need another app.</p>
      <div class="ebtns">${AB && !it.ext && !this.vault ? `<button class="btn pri" data-act="p-vlc">${ic('play', 16)} Play with the VLC engine</button>` : ''}<button class="btn pri" data-act="p-ext">${ic('ext', 16)} Open with another app</button>${this.i < this.items.length - 1 ? `<button class="btn" data-act="p-next">Skip</button>` : ''}<button class="btn" data-act="p-back">Close</button></div>`;
    this.showUI(false);
    if (AB && !it.ext && !this.vault && ST.autoVlc !== false && !this.vlcTried) { this.vlcTried = it.key; ACT['p-vlc'](); }
  },
  onEnded() {
    this.ended = true; this.saveNow(); const v = this.v;
    if (this.sleepEnd) { this.sleepEnd = false; toast('Sleep timer: stopped'); this.showUI(true); return; }
    if (ST.loop === 'one') { v.currentTime = 0; v.play(); return; }
    if (ST.autonext && this.items.length > 1) {
      if (ST.shuffle) { let n; do { n = Math.floor(Math.random() * this.items.length); } while (n === this.i); return this.load(n); }
      if (this.i < this.items.length - 1) return this.load(this.i + 1);
      if (ST.loop === 'all') return this.load(0);
    } else if (ST.loop === 'all' && this.items.length === 1) { v.currentTime = 0; v.play(); return; }
    this.showUI(true);
  },
  syncPlay() {
    const p = !this.v.paused && !this.v.ended;
    $('#pplay').innerHTML = p ? icFill('pause', 30) : icFill('play', 30);
    $('#pplay').setAttribute('aria-label', p ? 'Pause' : 'Play');
    if (p) this.armHide(); else clearTimeout(this.hideT);
  },
  raf() {
    if (this.rafOn) return; this.rafOn = true;
    const f = () => { if (!this.active || this.v.paused) { this.rafOn = false; return; } this.tick(); requestAnimationFrame(f); };
    requestAnimationFrame(f);
  },
  tick(force) {
    const v = this.v, d = v.duration, t = v.currentTime;
    // A-B loop
    if (this.ab.a != null && this.ab.b != null && t >= this.ab.b) v.currentTime = this.ab.a;
    this.subTick(t);
    if (this.seeking && !force) return;
    if (isFinite(d) && d > 0) { $('#pseek').value = Math.round(t / d * 1000); this.seekFill(); }
    $('#ptc').textContent = fmtTime(t); $('#ptd').textContent = isFinite(d) ? fmtTime(d) : '--:--';
  },
  seekFill() { const s = $('#pseek'); s.style.setProperty('--p', (s.value / 10) + '%'); },
  toggle() { const v = this.v; if (v.ended) { v.currentTime = 0; } if (v.paused) v.play().catch(() => { }); else v.pause(); },
  skip(s) { const v = this.v; if (!isFinite(v.duration)) return; v.currentTime = clamp(v.currentTime + s, 0, v.duration); this.tick(true); },
  next() { if (this.i < this.items.length - 1) this.load(this.i + 1); else if (ST.loop === 'all') this.load(0); else toast('Last video'); },
  prev() { if (this.v.currentTime > 4) { this.v.currentTime = 0; } else if (this.i > 0) this.load(this.i - 1); else this.v.currentTime = 0; },
  frame(d) { const v = this.v; v.pause(); v.currentTime = clamp(v.currentTime + d / ST.fps, 0, v.duration || 1e9); this.tick(true); },

  /* ----- controls visibility ----- */
  showUI(on) {
    this.ui = on; $('#player').classList.toggle('hideui', !on || this.locked);
    if (on) this.armHide(); else clearTimeout(this.hideT);
  },
  armHide() {
    clearTimeout(this.hideT);
    if (!this.ui || this.v.paused || Sheet.isOpen || this.seeking || !ST.ctlHide) return;
    this.hideT = setTimeout(() => this.showUI(false), ST.ctlHide * 1000);
  },

  /* ----- video layout: fit, aspect, rotation, flip, zoom ----- */
  layout() {
    if (!this.active) return;
    const v = this.v, vw = this.W = this.view.clientWidth || innerWidth, vh = this.H = this.view.clientHeight || innerHeight;
    const nw = v.videoWidth || this.cur && this.cur.w || 16, nh = v.videoHeight || this.cur && this.cur.h || 9;
    const rad = this.rot * Math.PI / 180, c = Math.abs(Math.cos(rad)), s = Math.abs(Math.sin(rad));
    const ar = ASPECTS[this.fit] || nw / nh;
    let bw, bh, mode = 'contain';
    if (this.fit === 'fill') { bw = Math.max(vw, vh * ar); bh = bw / ar; mode = 'cover'; }
    else if (this.fit === 'stretch') { bw = vw; bh = vh; mode = 'none'; }
    else if (this.fit === '100') { bw = nw; bh = nh; mode = 'none'; }
    else { bw = Math.min(vw, vh * ar); bh = bw / ar; }
    if (this.fit === 'fill') { // cover the screen, then rotate to cover again
      bw = ar >= vw / vh ? vh * ar : vw; bh = bw / ar;
    }
    const rbw = bw * c + bh * s, rbh = bw * s + bh * c;
    let r = 1;
    if (mode === 'contain') r = Math.min(vw / rbw, vh / rbh);
    else if (mode === 'cover') r = Math.max(vw / rbw, vh / rbh);
    else if (this.fit === 'stretch') { r = Math.min(vw / rbw, vh / rbh); }
    this.rbw = rbw * r; this.rbh = rbh * r;
    const mx = Math.max(0, (this.rbw * this.z - vw) / 2), my = Math.max(0, (this.rbh * this.z - vh) / 2);
    this.px = clamp(this.px, -mx, mx); this.py = clamp(this.py, -my, my);
    const st = v.style;
    st.width = bw + 'px'; st.height = bh + 'px'; st.marginLeft = -bw / 2 + 'px'; st.marginTop = -bh / 2 + 'px';
    st.transform = `translate(${this.px}px,${this.py}px) scale(${this.z * r}) rotate(${this.rot}deg) scale(${this.fx},${this.fy})`;
    this.subLayout();
  },
  applyFilter() { this.v.style.filter = filterCSS(this.adj); },
  setFit(f) { this.fit = f; this.z = 1; this.px = this.py = 0; this.layout(); toast({ fit: 'Fit', fill: 'Fill screen', stretch: 'Stretch', '100': '100% (original size)' }[f] || ('Aspect ' + f), 900); },

  /* ----- gestures ----- */
  bindGestures() {
    const el = this.gest, P = new Map(); let g = null, tap = { n: 0, t: 0, timer: null, acc: 0 }, holdT = null;
    const zone = x => x < this.W * 0.34 ? 'L' : x > this.W * 0.66 ? 'R' : 'C';
    const mid = () => { const a = [...P.values()]; return { x: (a[0].x + a[1].x) / 2, y: (a[0].y + a[1].y) / 2, d: Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y) }; };
    const endHold = () => { clearTimeout(holdT); if (g && g.hold) { this.v.playbackRate = g.rate0; g.hold = false; this.ind(''); } };
    el.addEventListener('pointerdown', e => {
      if (this.locked) { this.showLockHint(); return; }
      try { el.setPointerCapture(e.pointerId); } catch (x) { }
      P.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (P.size === 1) {
        g = { sx: e.clientX, sy: e.clientY, mode: null, moved: false, t: Date.now(), z: zone(e.clientX), t0: this.v.currentTime, hold: false, rate0: this.v.playbackRate };
        if (ST.hold2x) holdT = setTimeout(() => { if (g && !g.moved && !this.v.paused) { g.hold = true; g.mode = 'hold'; this.v.playbackRate = 2; this.ind(`${ic('ff', 26)}<b>2×</b>`, 0); navigator.vibrate && navigator.vibrate(15); } }, 480);
      } else if (P.size === 2) {
        clearTimeout(holdT); endHold(); const m = mid();
        g = { mode: 'pinch', d0: m.d || 1, z0: this.z, cx: m.x, cy: m.y, px0: this.px, py0: this.py, moved: true };
      }
    });
    el.addEventListener('pointermove', e => {
      if (!P.has(e.pointerId) || !g) return;
      P.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (g.mode === 'pinch' && P.size >= 2) {
        const m = mid(), nz = clamp(g.z0 * m.d / g.d0, 0.5, 6), k = nz / g.z0, cx = this.W / 2, cy = this.H / 2;
        this.z = nz; this.px = m.x - cx - (g.cx - cx - g.px0) * k; this.py = m.y - cy - (g.cy - cy - g.py0) * k;
        this.layout(); this.ind(`${ic('zoomin', 22)}<b>${Math.round(nz * 100)}%</b>`, 700); return;
      }
      if (g.mode === 'hold') return;
      const dx = e.clientX - g.sx, dy = e.clientY - g.sy;
      if (!g.moved) {
        if (Math.hypot(dx, dy) < 12) return;
        g.moved = true; clearTimeout(holdT);
        if (this.z > 1.03) g.mode = 'pan', g.px0 = this.px, g.py0 = this.py;
        else if (!ST.gest) g.mode = 'none';
        else if (Math.abs(dx) > Math.abs(dy) * 1.2) { g.mode = 'seek'; this.seeking = true; }
        else { g.mode = g.sx < this.W / 2 ? 'bri' : 'vol'; g.b0 = Dev.brightness.get(); g.v0 = this.vol; }
        if (g.mode === 'pan') { g.sx = e.clientX; g.sy = e.clientY; return; }
      }
      if (g.mode === 'pan') { this.px = g.px0 + (e.clientX - g.sx); this.py = g.py0 + (e.clientY - g.sy); this.layout(); }
      else if (g.mode === 'seek') {
        const d = this.v.duration; if (!isFinite(d)) return;
        const delta = dx / this.W * Math.min(d, 240); g.target = clamp(g.t0 + delta, 0, d);
        this.ind(`<b>${fmtTime(g.target)}</b><small>${delta >= 0 ? '+' : '−'}${fmtTime(Math.abs(g.target - g.t0))}</small>`, 0);
        $('#pseek').value = Math.round(g.target / d * 1000); this.seekFill(); $('#ptc').textContent = fmtTime(g.target);
      } else if (g.mode === 'bri') {
        const b = clamp(g.b0 - dy / (this.H * 0.75), 0.02, 1); Dev.brightness.set(b); this.ind(`${ic('sun', 24)}<b>${Math.round(b * 100)}%</b>`, 0);
      } else if (g.mode === 'vol') {
        this.setVol(g.v0 - dy / (this.H * 0.6) * 1.0, true);
      }
    });
    const end = e => {
      if (!P.has(e.pointerId)) return; P.delete(e.pointerId);
      if (!g) return;
      if (g.mode === 'pinch') { if (P.size === 0) { if (this.z < 1) { this.z = 1; this.px = this.py = 0; this.layout(); } g = null; } return; }
      if (P.size > 0) return;
      clearTimeout(holdT); const gg = g; g = null;
      if (gg.mode === 'hold') { this.v.playbackRate = gg.rate0; this.ind(''); return; }
      if (gg.mode === 'seek') { this.seeking = false; if (gg.target != null) { this.v.currentTime = gg.target; } this.ind('', 0); this.tick(true); return; }
      if (gg.mode === 'bri' || gg.mode === 'vol') { this.ind('', 350); return; }
      if (gg.mode === 'pan') { return; }
      if (gg.moved) return;
      // a tap
      const now = Date.now(), zn = zone(e.clientX);
      if (now - tap.t < 330) tap.n++; else { tap.n = 1; tap.acc = 0; }
      tap.t = now; clearTimeout(tap.timer);
      if (tap.n === 1) {
        tap.timer = setTimeout(() => { this.showUI(!this.ui); }, ST.dtap ? 250 : 0);
      } else if (ST.dtap) {
        if (zn === 'C') { if (tap.n === 2) this.toggle(); }
        else {
          const dir = zn === 'R' ? 1 : -1; tap.acc += ST.seek; this.skip(dir * ST.seek);
          this.ind(`${ic(dir > 0 ? 'ff' : 'rew', 28)}<b>${dir > 0 ? '+' : '−'}${tap.acc}s</b>`, 700, zn);
        }
      }
    };
    el.addEventListener('pointerup', end); el.addEventListener('pointercancel', e => { clearTimeout(holdT); endHold(); end(e); });
    el.addEventListener('wheel', e => { e.preventDefault(); this.z = clamp(this.z * (e.deltaY < 0 ? 1.1 : .9), .5, 6); this.layout(); }, { passive: false });
  },
  ind(html, ms = 800, side) {
    const i = $('#pind'); clearTimeout(this.indT);
    if (!html) { i.classList.remove('on'); return; }
    i.className = 'pind on' + (side === 'L' ? ' left' : side === 'R' ? ' right' : '');
    i.innerHTML = html;
    if (ms) this.indT = setTimeout(() => i.classList.remove('on'), ms);
  },
  /* volume 0..1 = phone volume, 1..3 = boost */
  setVol(x, show) {
    x = clamp(x, 0, 3); this.vol = x;
    const sys = Math.min(1, x), boost = Math.max(1, x);
    if (AB) { Dev.volume.set(sys); } else this.v.volume = sys;
    if (boost > 1) { this.audioInit(); }
    this.boost = boost; if (this.ac) this.nodes.gain.gain.value = boost;
    this.ind(`${ic(x === 0 ? 'mute' : 'vol', 24)}<b>${Math.round(x * 100)}%</b>${boost > 1 ? '<small>boosted</small>' : ''}`, 700);
  },
  showLockHint() { const l = $('#plock'); l.classList.add('hint'); clearTimeout(this.lockT); this.lockT = setTimeout(() => l.classList.remove('hint'), 1800); },

  /* ----- seek bar ----- */
  bindSeek() {
    const s = $('#pseek'), b = $('#psbub'); let last = 0;
    const show = () => { const d = this.v.duration; if (!isFinite(d)) return; const t = s.value / 1000 * d; b.hidden = false; b.textContent = fmtTime(t); b.style.left = (s.value / 10) + '%'; $('#ptc').textContent = fmtTime(t); this.seekFill(); return t; };
    s.addEventListener('input', () => { this.seeking = true; clearTimeout(this.hideT); const t = show(); const n = Date.now(); if (n - last > 90 && t != null) { last = n; this.v.currentTime = t; } });
    s.addEventListener('change', () => { const d = this.v.duration; if (isFinite(d)) this.v.currentTime = s.value / 1000 * d; this.seeking = false; b.hidden = true; this.armHide(); });
    s.addEventListener('pointerup', () => { this.seeking = false; b.hidden = true; this.armHide(); });
    $('#pctl').addEventListener('pointerdown', () => { clearTimeout(this.hideT); });
    $('#pctl').addEventListener('pointerup', () => this.armHide());
  },
  drawMarks() {
    const it = this.cur, d = this.v.duration; if (!it || !isFinite(d) || !d) { $('#pmarks').innerHTML = ''; return; }
    let h = marksOf(it.key).map(t => `<i class="mk" style="left:${t / d * 100}%"></i>`).join('');
    if (this.ab.a != null) h += `<i class="mk a" style="left:${this.ab.a / d * 100}%"></i>`;
    if (this.ab.b != null) h += `<i class="mk b" style="left:${this.ab.b / d * 100}%"></i>`;
    if (this.ab.a != null && this.ab.b != null) h += `<i class="abr" style="left:${this.ab.a / d * 100}%;width:${(this.ab.b - this.ab.a) / d * 100}%"></i>`;
    $('#pmarks').innerHTML = h;
  },
  updateSpeedChip() { const r = this.v.playbackRate; $('#pspd').textContent = (Math.round(r * 100) / 100) + '×'; $('#pspd').classList.toggle('on', Math.abs(r - 1) > .01); },
  setSpeed(r) {
    r = clamp(Math.round(r * 20) / 20, 0.25, 4); this.v.playbackRate = r;
    const it = this.cur; if (it && ST.remSpeed && !it.ext) { if (Math.abs(r - ST.speed) < .01) delete UD.speed[it.key]; else UD.speed[it.key] = r; saveUD(); }
  },

  /* ----- audio graph (boost, equalizer, delay, mono) ----- */
  audioInit() {
    if (this.ac) return true;
    try {
      const AC = window.AudioContext || window.webkitAudioContext, ac = new AC();
      const src = ac.createMediaElementSource(this.v);
      const n = this.nodes = { delay: ac.createDelay(3), bass: ac.createBiquadFilter(), mid: ac.createBiquadFilter(), treble: ac.createBiquadFilter(), gain: ac.createGain(), mono: ac.createGain() };
      n.bass.type = 'lowshelf'; n.bass.frequency.value = 120; n.mid.type = 'peaking'; n.mid.frequency.value = 1200; n.mid.Q.value = 0.9; n.treble.type = 'highshelf'; n.treble.frequency.value = 6000;
      src.connect(n.delay); n.delay.connect(n.bass); n.bass.connect(n.mid); n.mid.connect(n.treble); n.treble.connect(n.gain); n.gain.connect(n.mono); n.mono.connect(ac.destination);
      this.ac = ac; ac.resume();
      n.bass.gain.value = this.eq.bass; n.mid.gain.value = this.eq.mid; n.treble.gain.value = this.eq.treble; n.gain.gain.value = this.boost; n.delay.delayTime.value = this.adelay / 1000;
      return true;
    } catch (e) { toast('Audio effects are not available on this phone'); return false; }
  },
  setMono(on) {
    this.mono = on; if (!this.audioInit()) return; const m = this.nodes.mono;
    if (on) { m.channelCount = 1; m.channelCountMode = 'explicit'; m.channelInterpretation = 'speakers'; } else { m.channelCount = 2; m.channelCountMode = 'max'; }
  },

  /* ----- subtitles (own renderer, so size, colour, position and timing are all adjustable) ----- */
  async loadSubs(file) {
    try {
      let txt = await file.text();
      if (txt.includes('�')) { try { txt = new TextDecoder('windows-1252').decode(await file.arrayBuffer()); } catch (e) { } }
      const cues = parseSubs(txt, file.name);
      if (!cues.length) return toast('No subtitles found in that file');
      this.subs = cues; this.subName = file.name; this.subOn = true; this.subIdx = 0; toast(`Subtitles: ${cues.length} lines`);
      this.panel('sub');
    } catch (e) { toast('Could not read that file'); }
  },
  subLayout() {
    const s = $('#psub'); if (!s) return;
    s.style.fontSize = (Math.max(14, Math.min(this.W || 360, this.H || 640) * 0.052) * ST.subSize / 100) + 'px';
    s.style.bottom = ST.subPos + '%'; s.style.color = ST.subColor; s.style.setProperty('--sbg', `rgba(0,0,0,${ST.subBg})`);
  },
  subTick(t) {
    if (!this.subs.length || !this.subOn) { if (this.subShown) { $('#psub').innerHTML = ''; this.subShown = null; } return; }
    const tt = t - this.subDelay; let hit = null;
    const a = this.subs; let i = this.subIdx || 0;
    if (i >= a.length || a[i].s > tt) i = 0;      // went backwards: search again
    for (; i < a.length; i++) { if (a[i].s > tt) break; if (a[i].e >= tt) { hit = a[i]; break; } }
    this.subIdx = Math.max(0, i - 1);
    const h = hit ? hit.t : null;
    if (h !== this.subShown) { this.subShown = h; $('#psub').innerHTML = h ? `<span>${h}</span>` : ''; }
  },

  /* ----- panels ----- */
  panel(name) {
    const v = this.v, it = this.cur;
    const R = (id, label, min, max, step, val, fmt) => `<label class="sl1"><span>${label} <b id="${id}-v">${fmt ? fmt(val) : val}</b></span><input type="range" class="rng" id="${id}" min="${min}" max="${max}" step="${step}" value="${val}"></label>`;
    let title = '', html = '', after = null;
    if (name === 'speed') {
      title = 'Playback speed';
      html = `<div class="bigread" id="spv">${(Math.round(v.playbackRate * 100) / 100)}×</div><input type="range" class="rng" id="spr" min="0.25" max="4" step="0.05" value="${v.playbackRate}">
        <div class="chips wrapc">${SPEEDS.map(s => `<button class="chip ${Math.abs(v.playbackRate - s) < .01 ? 'on' : ''}" data-act="p-spd" data-v="${s}">${s}×</button>`).join('')}</div>
        <div class="rowsw"><span>Keep voices natural (pitch correction)</span>${sw(v.preservesPitch !== false, 'p-sw', 'pitch')}</div>
        <div class="rowsw"><span>Remember speed for this video</span>${sw(ST.remSpeed, 'p-sw', 'remSpeed')}</div>
        <div class="rowsw"><span>Hold the screen for 2× speed</span>${sw(ST.hold2x, 'p-sw', 'hold2x')}</div>
        <p class="hint">Starts at <b>${ST.speed}×</b> for new videos. Change that in Settings.</p>`;
      after = s => { $('#spr', s).oninput = e => { this.setSpeed(+e.target.value); $('#spv', s).textContent = (Math.round(v.playbackRate * 100) / 100) + '×'; $$('.chip', s).forEach(c => c.classList.toggle('on', Math.abs(v.playbackRate - +c.dataset.v) < .01)); }; };
    } else if (name === 'tf') {
      title = 'Rotate, flip & fit';
      html = `<div class="trow"><button class="tb" data-act="p-rot" data-d="-90">${ic('rotccw', 24)}<span>Left 90°</span></button><button class="tb" data-act="p-rot" data-d="90">${ic('rotcw', 24)}<span>Right 90°</span></button><button class="tb ${this.fx < 0 ? 'on' : ''}" data-act="p-flip" data-a="h">${ic('fliph', 24)}<span>Flip ↔</span></button><button class="tb ${this.fy < 0 ? 'on' : ''}" data-act="p-flip" data-a="v">${ic('flipv', 24)}<span>Flip ↕</span></button></div>
        ${R('rotr', 'Free angle', -180, 180, 0.5, this.rot, x => Math.round(x * 10) / 10 + '°')}
        ${R('zmr', 'Zoom', 50, 400, 5, Math.round(this.z * 100), x => x + '%')}
        <div class="lbl">PICTURE SIZE</div><div class="chips wrapc">${[['fit', 'Fit'], ['fill', 'Fill'], ['stretch', 'Stretch'], ['100', '100%'], ['16:9', '16:9'], ['4:3', '4:3'], ['21:9', '21:9'], ['1:1', '1:1']].map(c => `<button class="chip ${this.fit === c[0] ? 'on' : ''}" data-act="p-fit" data-v="${c[0]}">${c[1]}</button>`).join('')}</div>
        <div class="lbl">SCREEN ORIENTATION</div><div class="chips wrapc">${[['auto', 'Auto'], ['landscape', 'Landscape'], ['portrait', 'Portrait'], ['sensor', 'Free (sensor)'], ['lock', 'Lock current']].map(c => `<button class="chip ${this.orient === c[0] ? 'on' : ''}" data-act="p-orient" data-v="${c[0]}">${c[1]}</button>`).join('')}</div>
        <button class="btn wide" data-act="p-tfreset" style="margin-top:12px">${ic('undo', 16)} Reset picture</button>`;
      after = s => {
        $('#rotr', s).oninput = e => { this.rot = +e.target.value; this.layout(); $('#rotr-v', s).textContent = Math.round(this.rot * 10) / 10 + '°'; };
        $('#zmr', s).oninput = e => { this.z = +e.target.value / 100; this.layout(); $('#zmr-v', s).textContent = e.target.value + '%'; };
      };
    } else if (name === 'fx') {
      const a = Object.assign({}, ADJ0, this.adj);
      title = 'Picture filters';
      html = `<div class="chips wrapc">${Object.keys(PRESETS).map(k => `<button class="chip" data-act="p-preset" data-k="${k}">${k}</button>`).join('')}</div>
        <div class="sl">${[['b', 'Brightness', 40, 200], ['c', 'Contrast', 40, 220], ['s', 'Saturation', 0, 300], ['h', 'Hue', -180, 180], ['g', 'Black & white', 0, 100], ['se', 'Sepia', 0, 100], ['bl', 'Blur', 0, 10]].map(s => R('fx-' + s[0], s[1], s[2], s[3], 1, a[s[0]])).join('')}</div>
        <button class="btn wide" data-act="p-fxreset" style="margin-top:8px">${ic('undo', 16)} Reset filters</button><p class="hint">Filters are remembered for this video.</p>`;
      after = s => { $$('[id^=fx-]', s).forEach(r => { if (r.id.endsWith('-v')) return; r.oninput = () => { const k = r.id.slice(3); if (+r.value === ADJ0[k]) delete this.adj[k]; else this.adj[k] = +r.value; $('#' + r.id + '-v', s).textContent = r.value; this.applyFilter(); this.saveFilt(); }; }); };
    } else if (name === 'audio') {
      title = 'Audio';
      html = `${R('abst', 'Volume boost', 100, 300, 5, Math.round(this.boost * 100), x => x + '%')}
        <div class="lbl">EQUALIZER</div><div class="chips wrapc">${Object.keys(EQ_PRESETS).map(k => `<button class="chip" data-act="p-eq" data-k="${k}">${k}</button>`).join('')}</div>
        ${R('eqb', 'Bass', -12, 12, 1, this.eq.bass, x => (x > 0 ? '+' : '') + x + ' dB')}${R('eqm', 'Voice', -12, 12, 1, this.eq.mid, x => (x > 0 ? '+' : '') + x + ' dB')}${R('eqt', 'Treble', -12, 12, 1, this.eq.treble, x => (x > 0 ? '+' : '') + x + ' dB')}
        ${R('adl', 'Audio delay (if the sound comes too early)', 0, 2000, 10, this.adelay, x => x + ' ms')}
        <div class="rowsw"><span>Mono (same sound in both ears)</span>${sw(this.mono, 'p-sw', 'mono')}</div>
        <p class="hint">Boost above 100% can distort loud scenes. Keep the phone's own volume for normal listening.</p>`;
      after = s => {
        $('#abst', s).oninput = e => { if (!this.audioInit()) return; this.boost = +e.target.value / 100; this.nodes.gain.gain.value = this.boost; $('#abst-v', s).textContent = e.target.value + '%'; };
        const eq = (id, k) => { $('#' + id, s).oninput = e => { if (!this.audioInit()) return; this.eq[k] = +e.target.value; this.nodes[k].gain.value = this.eq[k]; $('#' + id + '-v', s).textContent = (this.eq[k] > 0 ? '+' : '') + this.eq[k] + ' dB'; }; };
        eq('eqb', 'bass'); eq('eqm', 'mid'); eq('eqt', 'treble');
        $('#adl', s).oninput = e => { if (!this.audioInit()) return; this.adelay = +e.target.value; this.nodes.delay.delayTime.value = this.adelay / 1000; $('#adl-v', s).textContent = this.adelay + ' ms'; };
      };
    } else if (name === 'sub') {
      title = 'Subtitles';
      html = `<div class="rowsw"><span>${this.subs.length ? esc(this.subName) : 'No subtitles loaded'}</span>${this.subs.length ? sw(this.subOn, 'p-sw', 'subOn') : ''}</div>
        <div class="trow"><button class="btn pri" data-act="p-subload">${ic('plus', 16)} Load .srt / .vtt / .ass</button>${this.subs.length ? `<button class="btn" data-act="p-subclear">Remove</button>` : ''}</div>
        <div class="lbl">TIMING</div><div class="trow nudge"><button class="btn" data-act="p-subd" data-d="-0.5">−0.5 s</button><button class="btn" data-act="p-subd" data-d="-0.1">−0.1</button><b id="sdv">${this.subDelay.toFixed(1)} s</b><button class="btn" data-act="p-subd" data-d="0.1">+0.1</button><button class="btn" data-act="p-subd" data-d="0.5">+0.5 s</button></div>
        <p class="hint">If subtitles show <b>too late</b>, move them earlier (−). Too early? Use +.</p>
        ${R('ssz', 'Size', 50, 220, 5, ST.subSize, x => x + '%')}${R('spo', 'Height from bottom', 2, 40, 1, ST.subPos, x => x + '%')}${R('sbg', 'Background', 0, 100, 5, Math.round(ST.subBg * 100), x => x + '%')}
        <div class="lbl">COLOUR</div><div class="chips">${['#ffffff', '#ffe066', '#7cf29c', '#6fe3ff', '#ff9eb5'].map(c => `<button class="chip col ${ST.subColor === c ? 'on' : ''}" style="--c:${c}" data-act="p-subcol" data-v="${c}"></button>`).join('')}</div>`;
      after = s => {
        $('#ssz', s).oninput = e => { ST.subSize = +e.target.value; saveST(); $('#ssz-v', s).textContent = ST.subSize + '%'; this.subLayout(); this.previewSub(); };
        $('#spo', s).oninput = e => { ST.subPos = +e.target.value; saveST(); $('#spo-v', s).textContent = ST.subPos + '%'; this.subLayout(); this.previewSub(); };
        $('#sbg', s).oninput = e => { ST.subBg = +e.target.value / 100; saveST(); $('#sbg-v', s).textContent = e.target.value + '%'; this.subLayout(); this.previewSub(); };
      };
    } else if (name === 'ab') {
      title = 'A–B loop';
      const a = this.ab.a, b = this.ab.b;
      html = `<p class="hint">Repeat one part of the video, great for studying a chart replay or a lesson.</p><div class="abrow"><div class="abv"><span>A</span><b>${a != null ? fmtTime(a) : '--:--'}</b></div><div class="abv"><span>B</span><b>${b != null ? fmtTime(b) : '--:--'}</b></div></div>
        <div class="trow"><button class="btn pri" data-act="p-ab" data-v="a">${ic('ab', 16)} Set A here</button><button class="btn pri" data-act="p-ab" data-v="b">Set B here</button><button class="btn" data-act="p-ab" data-v="x">Clear</button></div>`;
    } else if (name === 'frame') {
      title = 'Frame by frame';
      html = `<div class="trow"><button class="tb" data-act="p-frame" data-d="-10">${ic('prev', 22)}<span>−10</span></button><button class="tb" data-act="p-frame" data-d="-1">${ic('left', 22)}<span>−1 frame</span></button><button class="tb" data-act="p-frame" data-d="1">${ic('right', 22)}<span>+1 frame</span></button><button class="tb" data-act="p-frame" data-d="10">${ic('next', 22)}<span>+10</span></button></div>
        <div class="lbl">VIDEO FRAME RATE</div><div class="chips">${[24, 25, 30, 50, 60].map(f => `<button class="chip ${ST.fps === f ? 'on' : ''}" data-act="p-fps" data-v="${f}">${f} fps</button>`).join('')}</div>
        <p class="hint">The player cannot read the frame rate itself, so pick the one your video uses (usually 24, 25 or 30).</p>`;
    } else if (name === 'mark') {
      title = 'Bookmarks';
      const ms = it ? marksOf(it.key) : [];
      html = `<button class="btn pri wide" data-act="p-addmark">${ic('bookmark', 16)} Bookmark ${fmtTime(v.currentTime)}</button><div class="mlist">${ms.length ? ms.map((t, i) => `<div class="mi"><button class="grow" data-act="p-gomark" data-t="${t}">${ic('play', 16)}<span>${fmtTime(t)}</span></button><button class="ib sm" data-act="p-delmark" data-i="${i}">${ic('x', 16)}</button></div>`).join('') : `<p class="hint">No bookmarks yet. They appear as dots on the seek bar.</p>`}</div>`;
    } else if (name === 'sleep') {
      title = 'Sleep timer';
      const left = this.sleepAt ? Math.max(0, Math.round((this.sleepAt - Date.now()) / 60000)) : 0;
      html = `<p class="hint">${this.sleepEnd ? 'Will stop when this video ends.' : this.sleepAt ? `Pausing in about ${left} min.` : 'Pause automatically after a while.'}</p><div class="chips wrapc">${[15, 30, 45, 60, 90].map(m => `<button class="chip" data-act="p-sleep" data-v="${m}">${m} min</button>`).join('')}<button class="chip" data-act="p-sleep" data-v="end">End of video</button><button class="chip" data-act="p-sleep" data-v="0">Off</button></div>`;
    } else if (name === 'mode') {
      title = 'Play mode';
      html = `<div class="lbl">REPEAT</div>${seg([['off', 'Off'], ['one', 'This video'], ['all', 'All']], ST.loop, 'p-set', 'loop')}
        <div class="rowsw"><span>Play the next video automatically</span>${sw(ST.autonext, 'p-sw', 'autonext')}</div><div class="rowsw"><span>Shuffle</span>${sw(ST.shuffle, 'p-sw', 'shuffle')}</div>
        <div class="rowsw"><span>Continue where I left off</span>${sw(ST.resume, 'p-sw', 'resume')}</div><div class="rowsw"><span>Keep the screen on while playing</span>${sw(ST.keepon, 'p-sw', 'keepon')}</div>`;
    } else if (name === 'queue') {
      title = `Up next · ${this.items.length}`;
      const lo = Math.max(0, this.i - 20), hi = Math.min(this.items.length, this.i + 80);
      html = `<div class="qlist">${this.items.slice(lo, hi).map((q, k) => `<button class="qi ${lo + k === this.i ? 'on' : ''}" data-act="p-goto" data-i="${lo + k}"><span class="qn">${lo + k + 1}</span><div><b>${esc(q.n)}</b><small>${fmtDur(q.d)}${q.w ? ' · ' + q.w + '×' + q.h : ''}</small></div></button>`).join('')}</div>`;
    } else if (name === 'info') {
      title = 'Video details';
      html = `<div class="kvs">${[['Name', it.n], ['Size', it.s ? sizeStr(it.s) : '—'], ['Resolution', v.videoWidth ? `${v.videoWidth} × ${v.videoHeight}` : '—'], ['Length', fmtTime(v.duration)], ['Format', it.m || '—'], ['Folder', it.b], ['Date', dateStr(it.t, true)], ['Speed', v.playbackRate + '×']].map(r => `<div class="kv"><span>${r[0]}</span><b>${esc(r[1])}</b></div>`).join('')}</div>`;
    }
    const s = Sheet.open(html, { title, onClose: () => this.armHide() });
    $('#sheet').classList.add('psheet');
    if (after) after(s);
    clearTimeout(this.hideT);
  },
  previewSub() { if (!this.subs.length) { const s = $('#psub'); s.innerHTML = '<span>Subtitle preview</span>'; clearTimeout(this.pvT); this.pvT = setTimeout(() => { if (!this.subShown) s.innerHTML = ''; }, 1500); } },
  saveFilt() { const it = this.cur; if (!it || it.ext) return; if (Object.keys(this.adj).length) UD.filt[it.key] = this.adj; else delete UD.filt[it.key]; saveUD(); },
  async capture() {
    const v = this.v, it = this.cur; if (!v.videoWidth) return toast('Wait for the video to load');
    try {
      const nw = v.videoWidth, nh = v.videoHeight, rad = this.rot * Math.PI / 180, c = Math.abs(Math.cos(rad)), s = Math.abs(Math.sin(rad));
      const cv = document.createElement('canvas'); cv.width = Math.round(nw * c + nh * s); cv.height = Math.round(nw * s + nh * c);
      const cx = cv.getContext('2d'); cx.filter = filterCSS(this.adj); cx.translate(cv.width / 2, cv.height / 2); cx.rotate(rad); cx.scale(this.fx, this.fy); cx.drawImage(v, -nw / 2, -nh / 2, nw, nh);
      const blob = await new Promise((res, rej) => cv.toBlob(b => b ? res(b) : rej(new Error('encode')), 'image/jpeg', 0.95));
      const t = fmtTime(v.currentTime).replace(/:/g, '-');
      const ok = await saveBlobToGallery(blob, `${it.n.replace(/\.[^.]+$/, '')}_${t}_${Date.now().toString(36)}.jpg`, 'image/jpeg', false);
      toast(ok ? 'Frame saved to Pictures/NerdyPlayer' : 'Could not save the frame');
      if (ok) rescan(true);
    } catch (e) { toast('Could not capture this frame'); }
  },
};

/* subtitle file parsing: SRT, WebVTT, ASS/SSA */
function parseSubs(txt, name) {
  txt = txt.replace(/^﻿/, '').replace(/\r/g, '');
  const cues = [];
  const clean = s => s.replace(/<(?!\/?(i|b|u)>)[^>]*>/gi, '').replace(/\{\\[^}]*\}/g, '').replace(/\\N/g, '<br>').replace(/\n/g, '<br>').replace(/&(?!amp;|lt;|gt;)/g, '&amp;').trim();
  const secs = (h, m, s, ms) => (+h || 0) * 3600 + (+m) * 60 + (+s) + (+('0.' + ms.padEnd(3, '0')) || 0);
  if (/\.(ass|ssa)$/i.test(name) || /^\[Script Info\]/m.test(txt)) {
    let fmt = null;
    for (const line of txt.split('\n')) {
      if (/^Format:/i.test(line) && !fmt && /Start/i.test(line)) fmt = line.slice(7).split(',').map(x => x.trim().toLowerCase());
      if (/^Dialogue:/i.test(line) && fmt) {
        const parts = line.slice(9).split(','); const si = fmt.indexOf('start'), ei = fmt.indexOf('end'), ti = fmt.indexOf('text');
        const text = parts.slice(ti).join(',');
        const t = x => { const m = x.trim().match(/(\d+):(\d+):(\d+)[.](\d+)/); return m ? secs(m[1], m[2], m[3], m[4].padEnd(3, '0')) : 0; };
        const c = clean(text.replace(/\\N/g, '\n')); if (c) cues.push({ s: t(parts[si]), e: t(parts[ei]), t: c });
      }
    }
  } else {
    const re = /(?:(\d+):)?(\d{1,2}):(\d{2})[,.](\d{1,3})\s*-->\s*(?:(\d+):)?(\d{1,2}):(\d{2})[,.](\d{1,3})[^\n]*\n([\s\S]*?)(?=\n\n|\n*$)/g;
    let m; while ((m = re.exec(txt))) { const c = clean(m[9]); if (c) cues.push({ s: secs(m[1], m[2], m[3], m[4]), e: secs(m[5], m[6], m[7], m[8]), t: c }); }
  }
  return cues.sort((a, b) => a.s - b.s);
}

/* ----- actions ----- */
ACT['p-back'] = () => Player.back();
ACT['p-play'] = () => Player.toggle();
ACT['p-rew'] = () => Player.skip(-ST.seek);
ACT['p-ff'] = () => Player.skip(ST.seek);
ACT['p-next'] = () => { $('#perr').hidden = true; Player.next(); };
ACT['p-prev'] = () => Player.prev();
ACT['p-panel'] = el => Player.panel(el.dataset.v);
ACT['p-lock'] = () => { Player.locked = true; $('#plock').hidden = false; Player.showUI(false); toast('Controls locked'); };
(function () { // hold the lock button for a moment to unlock
  document.addEventListener('pointerdown', e => {
    const b = e.target.closest('#plock button'); if (!b) return;
    clearTimeout(Player.unT); b.classList.add('hold');
    Player.unT = setTimeout(() => { Player.locked = false; $('#plock').hidden = true; b.classList.remove('hold'); Player.showUI(true); }, 700);
  });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(t => document.addEventListener(t, e => { clearTimeout(Player.unT); const b = $('#plock button'); b && b.classList.remove('hold'); }));
})();
ACT['p-unlock'] = () => { };
ACT['p-pip'] = () => { const it = Player.cur; if (Native.info.pip) Native.call('pipNow', it.w || 16, it.h || 9); else toast('Picture-in-picture is not available here'); };
ACT['p-vlc'] = () => { const it = Player.cur; if (!it || it.ext || Player.vault) return; Native.call('playNative', it.key, Math.round((Player.v.currentTime || 0) * 1000)); };
ACT['p-ext'] = () => { const it = Player.cur; if (it.ext) toast('Open it from your file manager instead'); else Native.call('openWith', it.key, 'view'); };
ACT['p-more'] = () => {
  const it = Player.cur;
  menuSheet(it.n, [
    ['camera', 'Save this frame', () => Player.capture()],
    ['heart', isFav(it.key) ? 'Remove from favourites' : 'Add to favourites', () => { if (!Player.vault) { toggleFav(it.key); toast(isFav(it.key) ? 'Added to favourites' : 'Removed'); } }],
    Player.vault ? null : ['share', 'Share', () => Items.share([it])],
    Player.vault || it.ext || !AB ? null : ['film', 'Play with VLC engine (all formats)', () => ACT['p-vlc']()],
    Player.vault ? null : ['ext', 'Open with another app', () => Native.call('openWith', it.key, 'view')],
    Player.vault ? null : ['lock', 'Move to vault', () => { Items.toVault([it]); }],
    ['info', 'Details', () => Player.panel('info')],
    Player.vault || it.ext ? null : ['trash', 'Delete', () => { Player.v.pause(); Items.del([it]); }, 1],
  ]);
};
ACT['p-spd'] = el => { Player.setSpeed(+el.dataset.v); const s = $('#sheet'); $('#spr', s).value = Player.v.playbackRate; $('#spv', s).textContent = Player.v.playbackRate + '×'; $$('.chip', s).forEach(c => c.classList.toggle('on', Math.abs(Player.v.playbackRate - +c.dataset.v) < .01)); };
ACT['p-sw'] = el => {
  const k = el.dataset.k, P = Player; let on;
  if (k === 'pitch') { on = !(P.v.preservesPitch !== false); P.v.preservesPitch = on; P.v.webkitPreservesPitch = on; }
  else if (k === 'mono') { P.setMono(!P.mono); on = P.mono; }
  else if (k === 'subOn') { P.subOn = !P.subOn; on = P.subOn; if (!on) $('#psub').innerHTML = ''; }
  else { ST[k] = !ST[k]; saveST(); on = ST[k]; }
  el.classList.toggle('on', on); el.setAttribute('aria-checked', on);
};
ACT['p-set'] = el => { ST[el.dataset.k] = el.dataset.v; saveST(); $$(`[data-act=p-set][data-k=${el.dataset.k}]`).forEach(b => b.classList.toggle('on', b.dataset.v === el.dataset.v)); };
ACT['p-rot'] = el => { Player.rot = ((Player.rot + +el.dataset.d) % 360 + 360) % 360; if (Player.rot > 180) Player.rot -= 360; Player.z = 1; Player.px = Player.py = 0; Player.layout(); const r = $('#rotr'); if (r) { r.value = Player.rot; $('#rotr-v').textContent = Player.rot + '°'; } };
ACT['p-flip'] = el => { if (el.dataset.a === 'h') Player.fx *= -1; else Player.fy *= -1; Player.layout(); el.classList.toggle('on'); };
ACT['p-fit'] = el => { Player.setFit(el.dataset.v); $$('[data-act=p-fit]').forEach(b => b.classList.toggle('on', b === el)); const z = $('#zmr'); if (z) { z.value = 100; $('#zmr-v').textContent = '100%'; } };
ACT['p-orient'] = el => { Player.orient = el.dataset.v; const m = el.dataset.v; if (m === 'lock') Dev.orientation('lock'); else if (m === 'auto') Dev.orientation('auto'); else Dev.orientation(m); $$('[data-act=p-orient]').forEach(b => b.classList.toggle('on', b === el)); };
ACT['p-tfreset'] = () => { Player.rot = 0; Player.fx = Player.fy = 1; Player.z = 1; Player.px = Player.py = 0; Player.fit = ST.fit; Player.layout(); Player.panel('tf'); };
ACT['p-preset'] = el => { Player.adj = Object.assign({}, PRESETS[el.dataset.k]); Player.applyFilter(); Player.saveFilt(); Player.panel('fx'); $$('#sheet .chip').forEach(c => c.classList.toggle('on', c.dataset.k === el.dataset.k)); };
ACT['p-fxreset'] = () => { Player.adj = {}; Player.applyFilter(); Player.saveFilt(); Player.panel('fx'); };
ACT['p-eq'] = el => {
  if (!Player.audioInit()) return; const p = EQ_PRESETS[el.dataset.k], P = Player;
  P.eq = { bass: p[0], mid: p[1], treble: p[2] }; P.nodes.bass.gain.value = p[0]; P.nodes.mid.gain.value = p[1]; P.nodes.treble.gain.value = p[2]; P.panel('audio');
};
ACT['p-subload'] = () => $('#subpick').click();
ACT['p-subclear'] = () => { Player.subs = []; Player.subName = ''; $('#psub').innerHTML = ''; Player.panel('sub'); };
ACT['p-subd'] = el => { Player.subDelay = Math.round((Player.subDelay + +el.dataset.d) * 10) / 10; $('#sdv').textContent = Player.subDelay.toFixed(1) + ' s'; };
ACT['p-subcol'] = el => { ST.subColor = el.dataset.v; saveST(); Player.subLayout(); Player.previewSub(); $$('[data-act=p-subcol]').forEach(b => b.classList.toggle('on', b === el)); };
$('#subpick').addEventListener('change', e => { const f = e.target.files[0]; e.target.value = ''; if (f) Player.loadSubs(f); });
ACT['p-ab'] = el => {
  const P = Player, t = P.v.currentTime, k = el.dataset.v;
  if (k === 'a') { P.ab.a = t; if (P.ab.b != null && P.ab.b <= t) P.ab.b = null; } else if (k === 'b') { if (P.ab.a == null) P.ab.a = 0; P.ab.b = t; if (P.ab.b <= P.ab.a) { P.ab.b = null; return toast('B must be after A'); } } else P.ab = { a: null, b: null };
  P.drawMarks(); P.panel('ab');
};
ACT['p-frame'] = el => { const d = +el.dataset.d; Player.v.pause(); if (Math.abs(d) === 10) Player.frame(d); else Player.frame(d); };
ACT['p-fps'] = el => { ST.fps = +el.dataset.v; saveST(); $$('[data-act=p-fps]').forEach(b => b.classList.toggle('on', b === el)); };
ACT['p-addmark'] = () => { const it = Player.cur; if (it.ext) return toast('Bookmarks work for videos in your gallery'); const m = marksOf(it.key).concat([Math.round(Player.v.currentTime * 10) / 10]).sort((a, b) => a - b); setMarks(it.key, [...new Set(m)]); Player.drawMarks(); Player.panel('mark'); };
ACT['p-gomark'] = el => { Player.v.currentTime = +el.dataset.t; Sheet.close(); };
ACT['p-delmark'] = el => { const it = Player.cur; const m = marksOf(it.key).slice(); m.splice(+el.dataset.i, 1); setMarks(it.key, m); Player.drawMarks(); Player.panel('mark'); };
ACT['p-sleep'] = el => { const v = el.dataset.v, P = Player; P.sleepAt = 0; P.sleepEnd = false; if (v === 'end') P.sleepEnd = true; else if (+v) P.sleepAt = Date.now() + +v * 60000; toast(v === '0' ? 'Sleep timer off' : v === 'end' ? 'Will stop after this video' : `Pausing in ${v} min`); Sheet.close(); };
ACT['p-goto'] = el => { Sheet.close(); Player.load(+el.dataset.i); };
ACT['p-shot'] = () => Player.capture();
Player.panelOrig = Player.panel;
Player.panel = function (name) { if (name === 'shot') return Player.capture(); const r = Player.panelOrig(name); if (name === 'mark' || name === 'ab') Player.drawMarks(); return r; };
document.getElementById('pv') || 0;
