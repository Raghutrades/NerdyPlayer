'use strict';
/* ===== NerdyPlayer · settings, library and your own data =====
   Everything is kept on this phone: settings and favourites in the app's own storage,
   the file list comes live from Android's media database. */

const DEF = {
  theme: 'cinema', splash: true, heads: 'bold',
  // gallery
  cols: 3, tile: 'square', group: 'day', viewV: 'list', viewP: 'grid', autoPreview: true, previewSound: false, reelSound: false, appFull: true, engine: 'vlc', hw: true, deint: false, quick: true, uiStyle: 'glass', sortV: 'date', sortP: 'date', dir: 'desc',
  // video
  seek: 10, dtap: true, gest: true, hold2x: true, resume: true, autonext: true, loop: 'off', shuffle: false,
  fit: 'fit', autoland: true, keepon: true, bg: 'pause', speed: 1, remSpeed: true, ctlHide: 4, fps: 30,
  subSize: 100, subColor: '#ffffff', subBg: 0.45, subPos: 9,
  // photos
  ssInt: 4, ssTrans: 'fade', ssShuffle: false, ssLoop: true, ssVideos: false, ssKB: true, ssCap: false, ssScope: 'view',
  dtz: 2.5, exifBtn: true,
  // confirm
  confirmDel: true,
};
const ST = Object.assign({}, DEF, Store.get('np-settings', {}));
if (ST.engine === 'auto') ST.engine = 'vlc';
const saveST = debounce(() => Store.set('np-settings', ST), 200);

/* ---------- the library (photos + videos on the phone) ---------- */
const LIB = { items: [], map: new Map(), buckets: new Map(), ready: false, scanning: false, tmp: null, trash: [], tmpTrash: null, denied: false };

function mkItem(r) {
  const v = !!r[1];
  const added = (r[5] || 0) * 1000;
  let taken = r[6] || 0;
  if (taken < 631152000000) taken = added || (r[12] ? r[12] * 1000 : 0);
  return {
    key: (v ? 'v' : 'i') + r[0], id: r[0], k: v ? 'v' : 'i', v, n: r[2] || 'file', m: r[3] || (v ? 'video/*' : 'image/*'),
    s: r[4] || 0, a: added, t: taken, d: r[7] || 0, w: r[8] || 0, h: r[9] || 0, b: r[10] || 'Other', p: r[11] || '', x: r[12] || 0,
  };
}

function rebuildLib(raw) {
  LIB.raw = raw;
  /* files already copied into the vault whose originals Android has not removed yet:
     never show them anywhere in the app. Forget keys that are really gone. */
  let list = raw;
  if (UD.pend && UD.pend.length) {
    const present = new Set(raw.map(i => i.key));
    const before = UD.pend.length;
    UD.pend = UD.pend.filter(k => present.has(k) || !LIB.ready);
    if (UD.pend.length !== before) saveUD();
    const hide = new Set(UD.pend);
    list = raw.filter(i => !hide.has(i.key));
  }
  LIB.items = list;
  LIB.map = new Map(list.map(i => [i.key, i]));
  LIB.buckets = new Map();
  for (const it of list) {
    let b = LIB.buckets.get(it.b);
    if (!b) { b = { name: it.b, items: [], size: 0, v: 0, i: 0 }; LIB.buckets.set(it.b, b); }
    b.items.push(it); b.size += it.s; if (it.v) b.v++; else b.i++;
  }
  LIB.ready = true;
}

Native.on('scan', o => {
  if (o.denied) { LIB.denied = true; LIB.scanning = false; LIB.ready = true; App.onLibrary(); return; }
  if (o.rows) {
    if (o.first || !LIB.tmp) LIB.tmp = [];
    for (const r of o.rows) LIB.tmp.push(mkItem(r));
  }
  if (o.done) {
    rebuildLib(LIB.tmp || []);
    LIB.tmp = null; LIB.scanning = false; LIB.denied = false; LIB.lastScan = Date.now();
    App.onLibrary();
  }
});
Native.on('trash', o => {
  if (o.rows) { if (o.first || !LIB.tmpTrash) LIB.tmpTrash = []; for (const r of o.rows) LIB.tmpTrash.push(mkItem(r)); }
  if (o.done) { LIB.trash = LIB.tmpTrash || []; LIB.tmpTrash = null; if (App.view === 'trash') App.render(); }
});

function rescan(force) {
  if (!AB) { rebuildLib([]); App.onLibrary(); return; }
  if (LIB.scanning) return;
  if (!force && LIB.lastScan && Date.now() - LIB.lastScan < 20000) return;
  LIB.scanning = true;
  Native.call('scan', false);
}

/* ---------- your own data: favourites, resume points, bookmarks, collections ---------- */
const UD = Object.assign({ fav: [], pend: [], pos: {}, hist: [], marks: {}, cols: [], lockedB: [], speed: {}, filt: {}, seen: {} }, Store.get('np-ud', {}));
const favSet = new Set(UD.fav);
const saveUD = debounce(() => { UD.fav = [...favSet]; Store.set('np-ud', UD); }, 400);
const isFav = k => favSet.has(k);
function toggleFav(keys) {
  keys = [].concat(keys);
  const allFav = keys.every(k => favSet.has(k));
  keys.forEach(k => allFav ? favSet.delete(k) : favSet.add(k));
  saveUD();
  return !allFav;
}
function savePos(key, t, d) {
  if (!key || !(d > 0)) return;
  if (t < 5 || t > d - 3) delete UD.pos[key]; else UD.pos[key] = { t: Math.round(t * 10) / 10, d: Math.round(d), at: Date.now() };
  saveUD();
}
const posOf = key => UD.pos[key] || null;
function pushHist(key) {
  UD.hist = [key, ...UD.hist.filter(k => k !== key)].slice(0, 80);
  saveUD();
}
const marksOf = key => UD.marks[key] || [];
function setMarks(key, arr) { if (arr.length) UD.marks[key] = arr; else delete UD.marks[key]; saveUD(); }

/* ---------- collections (your own albums) ---------- */
function addToCollection(cid, keys) {
  const c = UD.cols.find(x => x.id === cid); if (!c) return 0;
  let n = 0; for (const k of keys) if (!c.keys.includes(k)) { c.keys.push(k); n++; }
  saveUD(); return n;
}
function newCollection(name) { const c = { id: uid(), name, keys: [], at: Date.now() }; UD.cols.push(c); saveUD(); return c; }

/* ---------- locked folders (hidden in the app until you unlock with your PIN) ---------- */
const SESS = { unlockedFolders: false };
const isLockedBucket = b => UD.lockedB.includes(b);
/* all items the gallery may show right now */
function visible() {
  if (!UD.lockedB.length || SESS.unlockedFolders) return LIB.items;
  return LIB.items.filter(i => !UD.lockedB.includes(i.b));
}

/* ---------- sorting ---------- */
function sortItems(list, by, dir) {
  const m = dir === 'asc' ? 1 : -1;
  const f = {
    date: (a, b) => a.t - b.t,
    added: (a, b) => a.a - b.a,
    name: (a, b) => a.n.localeCompare(b.n, undefined, { numeric: true, sensitivity: 'base' }),
    size: (a, b) => a.s - b.s,
    dur: (a, b) => a.d - b.d,
    res: (a, b) => (a.w * a.h) - (b.w * b.h),
    ext: (a, b) => (extOf(a) || '~').localeCompare(extOf(b) || '~') || a.t - b.t,
    folder: (a, b) => a.b.localeCompare(b.b, undefined, { sensitivity: 'base' }) || a.t - b.t,
    random: (a, b) => 0,
  }[by] || ((a, b) => a.t - b.t);
  if (by === 'random') { const l = list.slice(); for (let i = l.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [l[i], l[j]] = [l[j], l[i]]; } return l; }
  return list.slice().sort((a, b) => m * f(a, b) || b.a - a.a);
}

/* ---------- opening files from outside ("Open with", "Share to", "Open a file") ---------- */
function extItem(o) { // {id,name,mime} from the shell
  const v = !!o.video || (o.mime || '').startsWith('video') || /\.(mp4|mkv|webm|3gp|mov|avi|m4v|mpg|mpeg|wmv|flv|ts|m2ts|vob|ogv|3g2|asf|rmvb|divx|part|crdownload)$/i.test(o.name || '');
  return { key: 'x' + o.id, id: o.id, k: v ? 'v' : 'i', v, ext: true, url: '/s/' + o.id, n: o.name || 'file', m: o.mime || '', s: 0, a: Date.now(), t: Date.now(), d: 0, w: 0, h: 0, b: 'Opened file', p: '' };
}
