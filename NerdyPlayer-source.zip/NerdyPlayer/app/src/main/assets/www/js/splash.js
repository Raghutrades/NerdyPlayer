'use strict';
/* Animated splash: an iris opens, a play button pops in, the name types up. */
const Splash = {
  start: Date.now(),
  html() {
    const blades = [0, 60, 120, 180, 240, 300].map((a, i) => `<path class="sp-blade" style="animation-delay:${(0.15 + i * 0.09).toFixed(2)}s" transform="rotate(${a} 60 60)" d="M60 60 L60 14 A46 46 0 0 1 99.8 37 Z" opacity=".0"/>`).join('');
    const name = 'NerdyPlayer'.split('').map((c, i) => `<span style="animation-delay:${(1.0 + i * 0.06).toFixed(2)}s">${c}</span>`).join('');
    return `<svg viewBox="0 0 120 120"><defs><linearGradient id="spg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#22d3ee"/></linearGradient></defs>
      <circle class="sp-ring" cx="60" cy="60" r="52"/>${blades}<path class="sp-play" d="M48 40 L48 80 L82 60 Z"/></svg>
      <div class="sp-name">${name}</div><div class="sp-tag">PRIVATE · OFFLINE · YOURS</div>`;
  },
  mount() { $('#splash').innerHTML = this.html(); },
  hide() {
    const wait = Math.max(0, 2500 - (Date.now() - this.start));
    setTimeout(() => { const s = $('#splash'); s.classList.add('out'); setTimeout(() => s.remove(), 600); }, wait);
  }
};
