'use strict';
/* ===== NerdyPlayer · welcome screen: logo, name, a thin progress line and a soft two-note chime (made on the phone) ===== */
const Splash = {
  el: null, timer: null, replaying: false, ac: null, T: 2300,
  run(replay) {
    const el = this.el = $('#splash');
    if (!el) return;
    if (!replay && ST.splash === false) { el.remove(); return; }
    clearTimeout(this.timer);
    this.replaying = !!replay;
    el.hidden = false; el.classList.remove('out');
    el.classList.remove('go'); void el.offsetWidth; el.classList.add('go');
    if (ST.splashSound !== false) this.chime();
    el.onclick = () => this.hide();
    this.timer = setTimeout(() => this.hide(), this.T);
  },
  hide() {
    const el = this.el;
    if (!el || el.classList.contains('out')) return;
    clearTimeout(this.timer);
    el.classList.add('out');
    setTimeout(() => { if (el.classList.contains('out')) { if (this.replaying) el.hidden = true; else el.remove(); } }, 500);
  },
  chime() {
    try {
      const ac = this.ac || (this.ac = new (window.AudioContext || window.webkitAudioContext)());
      ac.resume && ac.resume();
      const t = ac.currentTime + 0.25, g = ac.createGain();
      g.gain.value = 0.5; g.connect(ac.destination);
      [[523.25, 0], [783.99, 0.18]].forEach(([f, d]) => {
        const o = ac.createOscillator(), e = ac.createGain();
        o.type = 'sine'; o.frequency.value = f;
        e.gain.setValueAtTime(0.0001, t + d); e.gain.exponentialRampToValueAtTime(0.22, t + d + 0.04); e.gain.exponentialRampToValueAtTime(0.0001, t + d + 1.1);
        o.connect(e); e.connect(g); o.start(t + d); o.stop(t + d + 1.2);
      });
    } catch (e) { }
  },
};
