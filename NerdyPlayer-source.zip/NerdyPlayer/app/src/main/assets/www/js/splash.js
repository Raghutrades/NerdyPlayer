'use strict';
/* ===== NerdyPlayer · cinematic welcome animation with synthesized music =====
   Everything is generated on the phone: particles on a canvas, and a short score
   made with the Web Audio API (no audio files, works offline). */
const Splash = {
  el: null, timer: null, replaying: false, raf: 0, ac: null, master: null, T: 4900,
  run(replay) {
    const el = this.el = $('#splash');
    if (!el) return;
    if (!replay && ST.splash === false) { el.remove(); return; }
    clearTimeout(this.timer); cancelAnimationFrame(this.raf);
    this.replaying = !!replay;
    el.hidden = false; el.classList.remove('out');
    // restart every CSS animation
    el.classList.remove('go'); void el.offsetWidth; el.classList.add('go');
    this.buildName();
    this.visual();
    if (ST.splashSound !== false) this.music();
    this.timer = setTimeout(() => this.hide(), replay ? this.T : Math.max(1500, this.T - performance.now()));
  },
  hide() {
    const el = this.el;
    if (!el || el.classList.contains('out')) return;
    clearTimeout(this.timer);
    this.fade();
    el.classList.add('out');
    setTimeout(() => { cancelAnimationFrame(this.raf); if (el.classList.contains('out')) { if (this.replaying) el.hidden = true; else el.remove(); } }, 800);
  },
  buildName() {
    const n = $('#splash .nm'); if (!n) return;
    const word = (w, d0, cls) => `<span class="w ${cls || ''}">${[...w].map((c, i) => `<span style="animation-delay:${(d0 + i * 0.075).toFixed(3)}s">${c}</span>`).join('')}</span>`;
    n.innerHTML = word('Nerdy', 2.15) + word('Player', 2.55, 'b');
  },

  /* ---------- picture ---------- */
  visual() {
    const cv = $('#spc'); if (!cv) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const W = cv.width = innerWidth * dpr, H = cv.height = innerHeight * dpr, c = cv.getContext('2d');
    const cs = getComputedStyle(document.documentElement);
    const a1 = (cs.getPropertyValue('--a1') || '#7c5cff').trim(), a2 = (cs.getPropertyValue('--a2') || '#22d3ee').trim();
    const cx = W / 2, cy = H * 0.4, R = Math.min(W, H) * 0.62;
    const P = Array.from({ length: 260 }, (_, i) => ({ a: Math.random() * 6.283, r: R * (0.55 + Math.random() * 0.6), s: 0.6 + Math.random() * 1.8, z: 0.6 + Math.random() * 1.7, c: i % 2 ? a1 : a2, vx: 0, vy: 0 }));
    const t0 = performance.now(); let burst = false;
    const ease = x => 1 - Math.pow(1 - Math.min(1, Math.max(0, x)), 3);
    const frame = now => {
      const t = (now - t0) / 1000;
      c.globalCompositeOperation = 'source-over';
      c.fillStyle = 'rgba(5,5,12,0.24)'; c.fillRect(0, 0, W, H);
      c.globalCompositeOperation = 'lighter';
      const k = ease(t / 1.9);
      if (t >= 1.95 && !burst) { burst = true; P.forEach(p => { const x = cx + Math.cos(p.a) * p.r * (1 - k), y = cy + Math.sin(p.a) * p.r * (1 - k); p.x = x; p.y = y; const ang = Math.atan2(y - cy, x - cx) + (Math.random() - .5) * 1.2; const v = (4 + Math.random() * 14) * dpr; p.vx = Math.cos(ang) * v; p.vy = Math.sin(ang) * v; }); }
      for (const p of P) {
        let x, y, al;
        if (!burst) { const rr = p.r * (1 - k); const ang = p.a + t * 1.4 * p.z + k * 5; x = cx + Math.cos(ang) * rr; y = cy + Math.sin(ang) * rr * 0.72; al = 0.25 + k * 0.75; }
        else { p.vx *= 0.955; p.vy *= 0.955; p.x += p.vx; p.y += p.vy; x = p.x; y = p.y; al = Math.max(0, 1 - (t - 1.95) / 1.7); }
        if (al <= 0) continue;
        const rad = (burst ? 2.2 : 1.6) * p.s * dpr;
        const g = c.createRadialGradient(x, y, 0, x, y, rad * 4);
        g.addColorStop(0, p.c); g.addColorStop(1, 'rgba(0,0,0,0)');
        c.globalAlpha = al * 0.9; c.fillStyle = g; c.beginPath(); c.arc(x, y, rad * 4, 0, 6.283); c.fill();
      }
      c.globalAlpha = 1;
      // light streak at the moment of impact
      const f = t - 1.95;
      if (f > 0 && f < 1.4) {
        const w = W * (0.2 + f * 1.1), a = Math.max(0, 1 - f / 1.4);
        const g = c.createLinearGradient(cx - w, cy, cx + w, cy);
        g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.5, `rgba(255,255,255,${0.85 * a})`); g.addColorStop(1, 'rgba(255,255,255,0)');
        c.fillStyle = g; c.fillRect(cx - w, cy - 2 * dpr, w * 2, 4 * dpr);
        const r2 = c.createRadialGradient(cx, cy, 0, cx, cy, R * 0.7 * Math.min(1, f * 1.4));
        r2.addColorStop(0, `rgba(255,255,255,${0.5 * a})`); r2.addColorStop(0.4, a1); r2.addColorStop(1, 'rgba(0,0,0,0)');
        c.globalAlpha = 0.45 * a; c.fillStyle = r2; c.beginPath(); c.arc(cx, cy, R * 0.7, 0, 6.283); c.fill(); c.globalAlpha = 1;
      }
      if (t < 5.2) this.raf = requestAnimationFrame(frame);
    };
    cv.style.width = '100%'; cv.style.height = '100%';
    c.fillStyle = '#05050c'; c.fillRect(0, 0, W, H);
    this.raf = requestAnimationFrame(frame);
  },

  /* ---------- music ---------- */
  music() {
    try {
      const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
      const ac = this.ac = new AC();
      if (ac.state === 'suspended') ac.resume().catch(() => { });
      const comp = ac.createDynamicsCompressor(); comp.connect(ac.destination);
      const m = this.master = ac.createGain(); m.gain.value = 0.0001; m.connect(comp);
      const t = ac.currentTime + 0.06;
      m.gain.exponentialRampToValueAtTime(0.9, t + 0.4);
      // echo for sparkle
      const dl = ac.createDelay(1); dl.delayTime.value = 0.28; const fb = ac.createGain(); fb.gain.value = 0.38; const wet = ac.createGain(); wet.gain.value = 0.5;
      dl.connect(fb); fb.connect(dl); dl.connect(wet); wet.connect(m);
      const env = (g, a, pk, d, end) => { g.gain.setValueAtTime(0.0001, a); g.gain.exponentialRampToValueAtTime(pk, a + d[0]); g.gain.exponentialRampToValueAtTime(0.0001, a + d[0] + d[1]); };
      const tone = (type, f0, f1, a, pk, att, dec, dest, detune) => {
        const o = ac.createOscillator(), g = ac.createGain(); o.type = type; o.frequency.setValueAtTime(f0, a); if (f1) o.frequency.exponentialRampToValueAtTime(f1, a + att + dec);
        if (detune) o.detune.value = detune; env(g, a, pk, [att, dec]); o.connect(g); g.connect(dest || m); o.start(a); o.stop(a + att + dec + 0.1); return g;
      };
      // 1) deep rising sub + tension pad
      tone('sine', 38, 92, t, 0.7, 1.9, 0.05);
      [110, 164.8, 220].forEach((f, i) => { const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.setValueAtTime(200, t); lp.frequency.exponentialRampToValueAtTime(2600, t + 1.9); lp.connect(m); tone('sawtooth', f, f * 1.5, t, 0.07, 1.9, 0.05, lp, i * 6 - 6); });
      // 2) whoosh (filtered noise sweep)
      const len = ac.sampleRate * 2, buf = ac.createBuffer(1, len, ac.sampleRate), d = buf.getChannelData(0); for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      const ns = ac.createBufferSource(); ns.buffer = buf; const bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 1.4; bp.frequency.setValueAtTime(250, t + 0.5); bp.frequency.exponentialRampToValueAtTime(7000, t + 1.95);
      const ng = ac.createGain(); ng.gain.setValueAtTime(0.0001, t + 0.5); ng.gain.exponentialRampToValueAtTime(0.5, t + 1.9); ng.gain.exponentialRampToValueAtTime(0.0001, t + 2.3);
      ns.connect(bp); bp.connect(ng); ng.connect(m); ns.start(t + 0.5); ns.stop(t + 2.4);
      // 3) impact
      const hit = t + 1.9;
      tone('sine', 120, 34, hit, 1.0, 0.01, 1.1);
      const nb = ac.createBufferSource(); nb.buffer = buf; const lp2 = ac.createBiquadFilter(); lp2.type = 'lowpass'; lp2.frequency.setValueAtTime(2400, hit); lp2.frequency.exponentialRampToValueAtTime(120, hit + 0.8);
      const ng2 = ac.createGain(); ng2.gain.setValueAtTime(0.7, hit); ng2.gain.exponentialRampToValueAtTime(0.0001, hit + 0.9); nb.connect(lp2); lp2.connect(ng2); ng2.connect(m); nb.start(hit); nb.stop(hit + 1);
      // 4) bright arpeggio (A major) with echo
      [[659.3, 0], [880, 0.09], [1108.7, 0.18], [1318.5, 0.27], [1760, 0.38], [2217, 0.5]].forEach(([f, o]) => { tone('triangle', f, null, hit + 0.05 + o, 0.22, 0.01, 1.4, dl); tone('sine', f * 2, null, hit + 0.05 + o, 0.05, 0.01, 0.9, m); });
      // 5) warm resolving chord
      [110, 164.8, 220, 277.2, 329.6, 440].forEach((f, i) => { const g = ac.createGain(); g.gain.setValueAtTime(0.0001, hit); g.gain.exponentialRampToValueAtTime(0.16, hit + 0.5 + i * 0.05); g.gain.exponentialRampToValueAtTime(0.0001, hit + 2.9); const o = ac.createOscillator(); o.type = i < 2 ? 'triangle' : 'sine'; o.frequency.value = f; o.connect(g); g.connect(m); o.start(hit); o.stop(hit + 3); });
      // 6) tiny "film tick" clicks as the name appears
      for (let i = 0; i < 11; i++) { const a = t + 2.15 + i * 0.075 + (i > 4 ? 0.1 : 0); tone('square', 1800 + i * 40, 900, a, 0.03, 0.002, 0.05); }
    } catch (e) { /* silent phone, or sound blocked: the animation still plays */ }
  },
  fade() {
    try {
      if (this.master && this.ac) { const t = this.ac.currentTime; this.master.gain.cancelScheduledValues(t); this.master.gain.setValueAtTime(Math.max(0.0001, this.master.gain.value), t); this.master.gain.exponentialRampToValueAtTime(0.0001, t + 0.5); const ac = this.ac; setTimeout(() => { try { ac.close(); } catch (e) { } }, 700); }
    } catch (e) { }
    this.ac = this.master = null;
  },
};
document.addEventListener('click', e => { if (e.target.closest('#splash')) Splash.hide(); });
