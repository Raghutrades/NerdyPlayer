'use strict';
/* ===== NerdyPlayer · bridge to the Android shell =====
   Everything the page cannot do itself goes through window.NerdyBridge (see MainActivity.java).
   Messages coming back arrive at window.nrNative({e:'…'}). */
const Native = {
  handlers: {},
  info: { sdk: 0, perm: false, canTrash: false, pip: false },
  sec: {},
  on(e, f) { (this.handlers[e] = this.handlers[e] || []).push(f); },
  call(name, ...a) {
    if (name === 'scanTrash') { name = 'scan'; a = [true]; }
    try { return AB && AB[name] ? AB[name](...a) : undefined; } catch (e) { console.warn('bridge', name, e); }
  },
  json(name, ...a) {
    try { const r = this.call(name, ...a); return r ? JSON.parse(r) : null; } catch (e) { return null; }
  },
  refreshInfo() { const i = this.json('info'); if (i) this.info = i; return this.info; },
  refreshSec() { const s = this.json('sec'); if (s) this.sec = s; return this.sec; },
};
window.nrNative = o => { (Native.handlers[o.e] || []).slice().forEach(f => { try { f(o); } catch (e) { console.error(e); } }); };

/* where the bytes of an item come from */
const Src = {
  /* pictures the WebView cannot draw itself (HEIC, TIFF, RAW, JPEG-2000...) are converted by the phone */
  WEBIMG: /\.(jpe?g|png|gif|webp|avif|bmp|svg|ico)$/i,
  needsConv(it) { return !it.v && !it.vault && !it.url && AB && !(this.WEBIMG.test(it.n || '') && !/heic|heif|tiff?|dng|raw/i.test(it.m || '')); },
  url(it) {
    if (it.url) return it.url;                       // a file opened from outside (blob or /s/…)
    if (it.vault) return '/vf/' + it.id;
    if (this.needsConv(it)) return '/ci/' + it.id;
    return `/m/${it.k}/${it.id}`;
  },
  thumb(it, s = 256) {
    if (it.vault) return it.th ? '/vt/' + it.id : '';
    if (it.url) return it.v ? '' : it.url;
    return `/t/${it.k}/${it.id}?s=${s}`;
  },
};

/* ---- thin helpers around the bridge ---- */
const Dev = {
  bars(color, dark) { Native.call('setBars', color, !!dark); },
  fullscreen(on) { Native.call('fullscreen', !!on); },
  orientation(m) { Native.call('orientation', m); },
  keepOn(on) { Native.call('keepScreenOn', !!on); },
  brightness: { get: () => { const v = Native.call('getBrightness'); return typeof v === 'number' ? v : 0.5; }, set: v => Native.call('setBrightness', v) },
  volume: { get: () => { const v = Native.call('getVolume'); return typeof v === 'number' ? v : 0.5; }, set: v => Native.call('setVolume', v) },
};

/* save a canvas / blob into Pictures/NerdyPlayer through the shell */
async function saveBlobToGallery(blob, name, mime, video) {
  if (!AB) { // plain browser: just download it
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click();
    return true;
  }
  return new Promise(async res => {
    const off = e => { if (e.e === 'saved') { clear(); res(e.ok ? e : false); } };
    const clear = () => { const l = Native.handlers.saved || []; const i = l.indexOf(off); if (i >= 0) l.splice(i, 1); };
    Native.on('saved', off);
    try {
      Native.call('saveBegin', name, mime, !!video);
      const buf = new Uint8Array(await blob.arrayBuffer());
      const CH = 3 * 80000; // multiple of 3 so each chunk is valid base64 on its own
      for (let i = 0; i < buf.length; i += CH) {
        const part = buf.subarray(i, i + CH);
        let bin = ''; const S = 0x8000;
        for (let j = 0; j < part.length; j += S) bin += String.fromCharCode.apply(null, part.subarray(j, j + S));
        Native.call('saveChunk', btoa(bin));
      }
      Native.call('saveEnd');
    } catch (e) { clear(); res(false); }
  });
}
