'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sizeStr = b => b < 1024 ? b + ' B' : b < 1048576 ? (b / 1024).toFixed(0) + ' KB' : b < 1073741824 ? (b / 1048576).toFixed(1) + ' MB' : (b / 1073741824).toFixed(2) + ' GB';
const durStr = ms => { ms = Math.max(0, Math.round(ms / 1000)); const h = (ms / 3600) | 0, m = ((ms % 3600) / 60) | 0, s = ms % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(s).padStart(2, '0'); };
const MON = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
function dayLabel(ms) {
  const d = new Date(ms), n = new Date();
  const a = new Date(d.getFullYear(), d.getMonth(), d.getDate()), b = new Date(n.getFullYear(), n.getMonth(), n.getDate());
  const diff = Math.round((b - a) / 864e5);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  if (diff < 7 && diff > 0) return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][d.getDay()];
  return d.getDate() + ' ' + MON[d.getMonth()].slice(0, 3) + (d.getFullYear() !== n.getFullYear() ? ' ' + d.getFullYear() : '');
}
const fullDate = ms => ms ? new Date(ms).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '—';

const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
};

let _tt;
function toast(m, ms = 2400) {
  const t = $('#toast'); if (!t) return;
  t.textContent = m; t.classList.add('on'); clearTimeout(_tt);
  _tt = setTimeout(() => t.classList.remove('on'), ms);
}

/* bottom sheet: items [{i:icon,t:text,fn,dn}] */
function sheet(title, items, extra) {
  const bg = document.createElement('div');
  bg.className = 'sheetbg';
  bg.innerHTML = `<div class="sheet"><h3>${esc(title)}</h3>${extra || ''}${(items || []).map((o, k) => `<button class="opt ${o.dn ? 'dn' : ''}" data-k="${k}">${o.i ? ic(o.i, 20) : ''}<span class="grow">${esc(o.t)}</span>${o.on ? ic('check', 18) : ''}</button>`).join('')}</div>`;
  document.body.appendChild(bg);
  const close = () => bg.remove();
  bg.addEventListener('click', e => {
    if (e.target === bg) return close();
    const b = e.target.closest('.opt'); if (!b) return;
    close(); const o = items[+b.dataset.k]; o && o.fn && o.fn();
  });
  return { el: bg.firstChild, close };
}
function confirmBox(title, text, okText, danger) {
  return new Promise(res => {
    const bg = document.createElement('div');
    bg.className = 'sheetbg c';
    bg.innerHTML = `<div class="dlg"><h3>${esc(title)}</h3><p>${esc(text)}</p><div class="row"><button class="btn" data-v="0">Cancel</button><button class="btn ${danger ? 'danger' : 'pri'}" data-v="1">${esc(okText || 'OK')}</button></div></div>`;
    document.body.appendChild(bg);
    bg.addEventListener('click', e => {
      const b = e.target.closest('[data-v]');
      if (b || e.target === bg) { bg.remove(); res(!!b && b.dataset.v === '1'); }
    });
  });
}
function askText(title, ph, type) {
  return new Promise(res => {
    const bg = document.createElement('div');
    bg.className = 'sheetbg c';
    bg.innerHTML = `<div class="dlg"><h3>${esc(title)}</h3><input class="tx" ${type ? 'type="' + type + '"' : ''} placeholder="${esc(ph || '')}" style="margin-bottom:14px"><div class="row"><button class="btn" data-v="0">Cancel</button><button class="btn pri" data-v="1">OK</button></div></div>`;
    document.body.appendChild(bg);
    const inp = $('input', bg); setTimeout(() => inp.focus(), 50);
    bg.addEventListener('click', e => {
      const b = e.target.closest('[data-v]');
      if (b || e.target === bg) { const v = inp.value; bg.remove(); res(b && b.dataset.v === '1' ? v : null); }
    });
  });
}
const hap = (n = 12) => { try { navigator.vibrate && navigator.vibrate(n); } catch (e) { } };
const shuffled = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.random() * (i + 1) | 0;[a[i], a[j]] = [a[j], a[i]]; } return a; };
