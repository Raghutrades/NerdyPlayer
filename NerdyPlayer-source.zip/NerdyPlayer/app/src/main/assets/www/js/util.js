'use strict';
/* ===== NerdyPlayer · helpers, icons, toast, sheets, dialogs ===== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const AB = window.NerdyBridge || null; // Android bridge (null in a normal browser)
const ACT = {};                        // click actions: data-act="name"

const IC = {
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
  film: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2.5"/><circle cx="9" cy="9" r="1.8"/><path d="M21 16l-5-5-9 9"/>',
  folder: '<path d="M3 6a1 1 0 011-1h5l2 2h9a1 1 0 011 1v10a1 1 0 01-1 1H4a1 1 0 01-1-1z"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
  unlock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 017.5-2"/>',
  star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  heart: '<path d="M12 20s-7-4.4-9-9a5 5 0 019-3 5 5 0 019 3c-2 4.6-9 9-9 9z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  check: '<path d="M5 12l5 5L20 7"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 10.5l6.8-4M8.6 13.5l6.8 4"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
  play: '<path d="M7 4l13 8-13 8z"/>',
  pause: '<rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/>',
  next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
  prev: '<path d="M18 5l-9 7 9 7zM6 5v14"/>',
  rew: '<path d="M3 12a9 9 0 109-9 9 9 0 00-6.4 2.6L3 8"/><path d="M3 3v5h5"/>',
  ff: '<path d="M21 12a9 9 0 11-9-9 9 9 0 016.4 2.6L21 8"/><path d="M21 3v5h-5"/>',
  rotcw: '<path d="M21 12a9 9 0 11-3-6.7L21 8"/><path d="M21 3v5h-5"/>',
  rotccw: '<path d="M3 12a9 9 0 103-6.7L3 8"/><path d="M3 3v5h5"/>',
  fliph: '<path d="M12 3v3M12 10.5v3M12 18v3"/><path d="M9 6l-6 12h6zM15 6l6 12h-6z"/>',
  flipv: '<path d="M3 12h3M10.5 12h3M18 12h3"/><path d="M6 9l6-6 6 6zM6 15l6 6 6-6z"/>',
  zoomin: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M11 8v6M8 11h6"/>',
  zoomout: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M8 11h6"/>',
  expand: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
  shrink: '<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
  vol: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16.5 8.5a5 5 0 010 7M19 6a8.5 8.5 0 010 12"/>',
  mute: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M17 9l5 6M22 9l-5 6"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',
  sliders: '<path d="M3 6h9M18 6h3M3 12h3M12 12h9M3 18h11M20 18h1"/><circle cx="15" cy="6" r="2.2"/><circle cx="9" cy="12" r="2.2"/><circle cx="17" cy="18" r="2.2"/>',
  repeat: '<path d="M17 2l4 4-4 4M3 11V9a3 3 0 013-3h15M7 22l-4-4 4-4M21 13v2a3 3 0 01-3 3H3"/>',
  repeat1: '<path d="M17 2l4 4-4 4M3 11V9a3 3 0 013-3h15M7 22l-4-4 4-4M21 13v2a3 3 0 01-3 3H3"/><path d="M11 10l1.5-1v7"/>',
  shuffle: '<path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>',
  ab: '<text x="2.5" y="15" font-size="11" font-weight="700" fill="currentColor" stroke="none">A</text><text x="13" y="15" font-size="11" font-weight="700" fill="currentColor" stroke="none">B</text><path d="M3 19h18"/>',
  camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
  cc: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M10.5 10.5a2.5 2.5 0 100 3M17.5 10.5a2.5 2.5 0 100 3"/>',
  timer: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2M9 2h6"/>',
  gauge: '<path d="M4 17a8.5 8.5 0 1116 0"/><path d="M12 17l4-5"/>',
  pip: '<rect x="3" y="5" width="18" height="14" rx="2"/><rect x="12" y="12" width="7" height="5" rx="1"/>',
  more: '<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>',
  sort: '<path d="M7 4v16M3 8l4-4 4 4M17 20V4M13 16l4 4 4-4"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/>',
  filter: '<path d="M3 5h18l-7 8v6l-4-2v-4z"/>',
  eyeoff: '<path d="M3 3l18 18"/><path d="M10.6 6.1A9.6 9.6 0 0112 6c6.5 0 10 6 10 6a17 17 0 01-3.2 3.9M6.6 7.7A17 17 0 002 12s3.5 6 10 6a9.5 9.5 0 003.4-.6"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M10.8 12.2L20 3M16 7l3 3M14 9l2 2"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  finger: '<path d="M12 3a7 7 0 00-7 7v2"/><path d="M12 7a3 3 0 00-3 3v5a4 4 0 004 4"/><path d="M12 11v4"/><path d="M16 9v6a6 6 0 01-3 5"/><path d="M19 12v1a9 9 0 01-1.2 4.2"/>',
  offline: '<path d="M2 9a15 15 0 0120 0M5.5 12.5a10 10 0 0113 0M9 16a5 5 0 016 0"/><circle cx="12" cy="19.5" r=".7"/><path d="M4 4l16 16"/>',
  dl: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
  ul: '<path d="M12 20V9M7 13l5-5 5 5M5 4h14"/>',
  crop: '<path d="M6 2v14a2 2 0 002 2h14M18 22V8a2 2 0 00-2-2H2"/>',
  wand: '<path d="M5 19L17 7"/><path d="M14 4l1-2 1 2 2 1-2 1-1 2-1-2-2-1z"/><path d="M19.5 11l.7-1.5 1.3-.5-1.3-.5-.7-1.5-.7 1.5-1.3.5 1.3.5z"/>',
  palette: '<path d="M12 3a9 9 0 100 18c1.5 0 2-1 1.5-2.2-.5-1.2.3-2.3 1.7-2.3H17a4 4 0 004-4c0-5-4-9.5-9-9.5z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7.5" r="1"/>',
  layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.3"/>',
  bookmark: '<path d="M6 3h12v18l-6-4-6 4z"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 012-2h9"/>',
  ext: '<path d="M14 4h6v6M20 4l-9 9M18 14v6H4V6h6"/>',
  left: '<path d="M15 18l-6-6 6-6"/>',
  right: '<path d="M9 18l6-6-6-6"/>',
  down: '<path d="M6 9l6 6 6-6"/>',
  up: '<path d="M6 15l6-6 6 6"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/>',
  disk: '<path d="M3 15l3-9h12l3 9"/><rect x="3" y="15" width="18" height="5" rx="1.5"/><circle cx="7" cy="17.5" r=".6"/>',
  undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 010 12h-3"/>',
  music: '<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>',
  slides: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M10 8.5l5 2.5-5 2.5zM8 21h8M12 17v4"/>',
  aspect: '<rect x="3" y="6" width="18" height="12" rx="1.5"/><path d="M7 10v4M17 10v4"/>',
  bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  spark: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16l.7 1.8 1.8.7-1.8.7L19 21l-.7-1.8-1.8-.7 1.8-.7z"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  swap: '<path d="M4 8h13l-3-3M20 16H7l3 3"/>',
  hand: '<path d="M8 13V5.5a1.5 1.5 0 013 0V11M11 10V4.5a1.5 1.5 0 013 0V11M14 10V6a1.5 1.5 0 013 0v8a7 7 0 01-7 7h-1a6 6 0 01-5-3l-2-3.5a1.5 1.5 0 012.4-1.7L8 15"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
};
const ic = (n, s = 20) => `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n] || ''}</svg>`;
const icFill = (n, s = 20) => ic(n, s).replace('fill="none"', 'fill="currentColor"');

/* ---------- formatting ---------- */
const pad2 = n => String(n).padStart(2, '0');
function fmtTime(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  return h ? `${h}:${pad2(m)}:${pad2(s)}` : `${m}:${pad2(s)}`;
}
const fmtDur = ms => fmtTime((ms || 0) / 1000);
function sizeStr(b) {
  b = +b || 0;
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(0) + ' KB';
  if (b < 1073741824) return (b / 1048576).toFixed(b < 10485760 ? 1 : 0) + ' MB';
  return (b / 1073741824).toFixed(2) + ' GB';
}
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MONL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
function dateStr(ms, long) {
  const d = new Date(ms);
  if (isNaN(d)) return '';
  return long ? `${d.getDate()} ${MON[d.getMonth()]} ${d.getFullYear()}, ${pad2(d.getHours())}:${pad2(d.getMinutes())}` : `${d.getDate()} ${MON[d.getMonth()]} ${d.getFullYear()}`;
}
function dayLabel(ms) {
  const d = new Date(ms), n = new Date();
  const a = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const b = new Date(n.getFullYear(), n.getMonth(), n.getDate()).getTime();
  const diff = Math.round((b - a) / 86400000);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  if (diff < 7 && diff > 0) return DAYS[d.getDay()];
  return `${DAYS[d.getDay()]}, ${d.getDate()} ${MON[d.getMonth()]}${d.getFullYear() !== n.getFullYear() ? ' ' + d.getFullYear() : ''}`;
}
const monthLabel = ms => { const d = new Date(ms); return `${MONL[d.getMonth()]} ${d.getFullYear()}`; };
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

/* ---------- toast ---------- */
let toastT;
function toast(msg, ms = 2600) {
  const t = $('#toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('on');
  clearTimeout(toastT);
  toastT = setTimeout(() => t.classList.remove('on'), ms);
}

/* ---------- local storage with a safety net ---------- */
const Store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } },
  del(k) { try { localStorage.removeItem(k); } catch (e) { } },
};
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

/* ---------- bottom sheet ---------- */
const Sheet = {
  stack: [],
  open(html, opts = {}) {
    const w = $('#sheetwrap'), s = $('#sheet');
    s.innerHTML = `<div class="grab"></div>${opts.title ? `<h3 class="sh-t">${opts.title}</h3>` : ''}<div class="sh-b">${html}</div>`;
    w.hidden = false;
    requestAnimationFrame(() => w.classList.add('on'));
    this.onClose = opts.onClose || null;
    this.isOpen = true;
    return s;
  },
  close() {
    const w = $('#sheetwrap');
    if (!this.isOpen) return false;
    this.isOpen = false;
    w.classList.remove('on');
    setTimeout(() => { if (!this.isOpen) w.hidden = true; }, 220);
    const f = this.onClose; this.onClose = null;
    if (f) f();
    return true;
  },
};
ACT['sheet-close'] = () => Sheet.close();

/* ---------- popup menu (anchored list of actions) ---------- */
function menuSheet(title, items) {
  // items: [icon, label, fn, danger?]
  const s = Sheet.open(`<div class="mlist">${items.filter(Boolean).map((it, i) => `<button class="mi ${it[3] ? 'danger' : ''}" data-mi="${i}">${ic(it[0], 20)}<span>${esc(it[1])}</span></button>`).join('')}</div>`, { title: esc(title || '') });
  const real = items.filter(Boolean);
  $$('.mi', s).forEach(b => b.onclick = () => { Sheet.close(); setTimeout(() => real[+b.dataset.mi][2](), 60); });
}

/* ---------- confirm dialog ---------- */
function confirmBox(title, text, okLabel = 'OK', danger = false, cancelLabel = 'Cancel') {
  return new Promise(res => {
    const d = $('#dialog');
    d.innerHTML = `<div class="dlg"><h3>${esc(title)}</h3><p>${text}</p><div class="dbtns"><button class="btn" id="dno">${esc(cancelLabel)}</button><button class="btn ${danger ? 'danger' : 'pri'}" id="dyes">${esc(okLabel)}</button></div></div>`;
    d.hidden = false;
    requestAnimationFrame(() => d.classList.add('on'));
    const done = v => { d.classList.remove('on'); setTimeout(() => d.hidden = true, 150); res(v); };
    $('#dno').onclick = () => done(false);
    $('#dyes').onclick = () => done(true);
    d.onclick = e => { if (e.target === d) done(false); };
  });
}
/* a choice dialog with several buttons: opts = [[value,label,class]] */
function choiceBox(title, text, opts) {
  return new Promise(res => {
    const d = $('#dialog');
    d.innerHTML = `<div class="dlg"><h3>${esc(title)}</h3><p>${text}</p><div class="dbtns col">${opts.map((o, i) => `<button class="btn ${o[2] || ''}" data-i="${i}">${esc(o[1])}</button>`).join('')}</div></div>`;
    d.hidden = false;
    requestAnimationFrame(() => d.classList.add('on'));
    const done = v => { d.classList.remove('on'); setTimeout(() => d.hidden = true, 150); res(v); };
    $$('button', d).forEach(b => b.onclick = () => done(opts[+b.dataset.i][0]));
    d.onclick = e => { if (e.target === d) done(null); };
  });
}
function promptBox(title, placeholder, value = '', okLabel = 'Save') {
  return new Promise(res => {
    const d = $('#dialog');
    d.innerHTML = `<div class="dlg"><h3>${esc(title)}</h3><input class="field" id="pin1" maxlength="60" placeholder="${esc(placeholder)}" value="${esc(value)}"><div class="dbtns"><button class="btn" id="dno">Cancel</button><button class="btn pri" id="dyes">${esc(okLabel)}</button></div></div>`;
    d.hidden = false;
    requestAnimationFrame(() => { d.classList.add('on'); const i = $('#pin1'); i.focus(); i.select(); });
    const done = v => { d.classList.remove('on'); setTimeout(() => d.hidden = true, 150); res(v); };
    $('#dno').onclick = () => done(null);
    $('#dyes').onclick = () => done($('#pin1').value.trim() || null);
    $('#pin1').onkeydown = e => { if (e.key === 'Enter') done($('#pin1').value.trim() || null); };
    d.onclick = e => { if (e.target === d) done(null); };
  });
}

/* ---------- generic UI bits ---------- */
const seg = (opts, cur, act, k) => `<div class="seg">${opts.map(([v, t]) => `<button class="${String(cur) === String(v) ? 'on' : ''}" data-act="${act}" data-k="${k || ''}" data-v="${v}">${t}</button>`).join('')}</div>`;
const sw = (on, act, k) => `<button class="sw ${on ? 'on' : ''}" role="switch" aria-checked="${!!on}" data-act="${act}" data-k="${k || ''}"><i></i></button>`;

/* delegated clicks */
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const f = ACT[el.dataset.act];
  if (f) { e.preventDefault(); f(el, e); }
});

/* copy text (no clipboard permission needed in a user tap) */
function copyText(t) {
  try { navigator.clipboard.writeText(t); toast('Copied'); } catch (e) {
    const a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select();
    try { document.execCommand('copy'); toast('Copied'); } catch (e2) { } a.remove();
  }
}
