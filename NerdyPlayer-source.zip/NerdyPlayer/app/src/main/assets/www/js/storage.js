'use strict';
/* ===== NerdyPlayer · storage insights, duplicate finder, trash ===== */

VIEWS.storage = main => {
  const vis = visible();
  if (!vis.length) { main.innerHTML = emptyHTML('v'); return { title: 'Storage', back: true }; }
  const vids = vis.filter(i => i.v), imgs = vis.filter(i => !i.v);
  const sv = vids.reduce((a, b) => a + b.s, 0), si = imgs.reduce((a, b) => a + b.s, 0), tot = sv + si || 1;
  const bs = [...LIB.buckets.values()].map(b => ({ name: b.name, s: b.size, n: b.items.length })).sort((a, b) => b.s - a.s).slice(0, 8);
  const maxb = bs[0] ? bs[0].s : 1;
  const years = {}; vis.forEach(i => { const y = new Date(i.t).getFullYear(); years[y] = (years[y] || 0) + i.s; });
  const yl = Object.entries(years).sort((a, b) => b[0] - a[0]).slice(0, 8); const maxy = Math.max(1, ...yl.map(y => y[1]));
  const bigs = sortItems(vis, 'size', 'desc').slice(0, 40);
  const dup = findDups(vis);
  main.innerHTML = `<section class="card sto"><div class="stot"><b>${sizeStr(tot)}</b><span>${plural(vis.length, 'file')} in your gallery</span></div>
      <div class="stbar"><i class="v" style="width:${sv / tot * 100}%"></i><i class="p" style="width:${si / tot * 100}%"></i></div>
      <div class="stleg"><span><i class="v"></i>Videos ${sizeStr(sv)} · ${vids.length}</span><span><i class="p"></i>Photos ${sizeStr(si)} · ${imgs.length}</span></div></section>
    <section class="card"><h3>Biggest folders</h3>${bs.map(b => `<button class="brow" data-act="folder-open" data-b="${esc(b.name)}"><span class="bn">${esc(b.name)}</span><div class="bb"><i style="width:${b.s / maxb * 100}%"></i></div><b>${sizeStr(b.s)}</b></button>`).join('')}</section>
    <section class="card"><h3>By year</h3>${yl.map(y => `<div class="brow"><span class="bn">${y[0]}</span><div class="bb y"><i style="width:${y[1] / maxy * 100}%"></i></div><b>${sizeStr(y[1])}</b></div>`).join('')}</section>
    <button class="card tool wide" data-act="go" data-v="dups">${ic('copy', 22)}<b>Find duplicates</b><span>${dup.groups.length ? `${plural(dup.groups.length, 'set')} that look identical · ${sizeStr(dup.waste)} could be freed` : 'No obvious duplicates found'}</span></button>
    <div class="sechd"><h2>Biggest files</h2><span class="mute xs">long-press to select and delete</span></div><div id="gv"></div>`;
  App.gv = mkGrid($('#gv'), bigs, { mode: 'list', group: 'none', by: 'x' });
  return { title: 'Storage insights', back: true };
};

/* files that very probably are the same: same kind, size and length / resolution */
function findDups(list) {
  const m = new Map();
  for (const i of list) {
    if (!i.s) continue;
    const k = `${i.k}|${i.s}|${i.v ? Math.round(i.d / 100) : i.w + 'x' + i.h}`;
    if (!m.has(k)) m.set(k, []); m.get(k).push(i);
  }
  const groups = [...m.values()].filter(g => g.length > 1).map(g => g.sort((a, b) => a.a - b.a)).sort((a, b) => b[0].s * (b.length - 1) - a[0].s * (a.length - 1));
  const waste = groups.reduce((a, g) => a + g[0].s * (g.length - 1), 0);
  return { groups, waste };
}
const DUP = { sel: new Set(), groups: [] };
VIEWS.dups = main => {
  const d = findDups(visible()); DUP.groups = d.groups;
  const keep = new Set(d.groups.flat().map(i => i.key));
  DUP.sel = new Set([...DUP.sel].filter(k => keep.has(k)));
  if (!d.groups.length) { main.innerHTML = `<div class="empty">${ic('check', 44)}<h3>No duplicates</h3><p>Nothing in your gallery has the same size, length and resolution as another file.</p></div>`; return { title: 'Duplicates', back: true }; }
  const sel = [...DUP.sel].map(k => LIB.map.get(k)).filter(Boolean);
  const freed = sel.reduce((a, b) => a + b.s, 0);
  main.innerHTML = `<p class="sub">These files match in type, size and ${'length / resolution'}. They are almost certainly copies, but look before you delete.</p>
    <div class="row gap wrap" style="margin:0 2px 12px"><button class="btn" data-act="dup-auto">${ic('check', 16)} Keep the oldest of each</button><button class="btn" data-act="dup-none">Clear</button></div>
    ${d.groups.slice(0, 120).map((g, gi) => `<section class="card dg"><div class="dgh"><b>${plural(g.length, 'copy', 'copies').replace('copys', 'copies')}</b><span>${sizeStr(g[0].s)} each</span></div>
      <div class="dgrid">${g.map((it, ix) => `<button class="dgi ${DUP.sel.has(it.key) ? 'sel' : ''}" data-act="dup-toggle" data-key="${it.key}"><div class="dth">${Src.thumb(it, 240) ? `<img loading="lazy" src="${Src.thumb(it, 240)}" alt="" onerror="this.classList.add('bad')">` : ''}<span class="ph">${ic(it.v ? 'film' : 'image', 22)}</span>${it.v ? `<span class="dur">${fmtDur(it.d)}</span>` : ''}<i class="chk">${ic('check', 15)}</i></div><span class="dn">${esc(it.n)}</span><small>${esc(it.b)} · ${dateStr(it.a || it.t)}${ix === 0 ? ' · oldest' : ''}</small></button>`).join('')}</div></section>`).join('')}
    <div class="dfoot"><button class="btn danger wide" data-act="dup-del" ${sel.length ? '' : 'disabled'}>${ic('trash', 16)} Delete ${sel.length ? plural(sel.length, 'file') + ' · ' + sizeStr(freed) : 'selected'}</button></div>`;
  return { title: 'Duplicates', back: true };
};
ACT['dup-toggle'] = el => { const k = el.dataset.key; DUP.sel.has(k) ? DUP.sel.delete(k) : DUP.sel.add(k); const y = $('#main').scrollTop; App.render(); $('#main').scrollTop = y; };
ACT['dup-auto'] = () => { DUP.sel = new Set(DUP.groups.flatMap(g => g.slice(1).map(i => i.key))); const y = $('#main').scrollTop; App.render(); $('#main').scrollTop = y; };
ACT['dup-none'] = () => { DUP.sel.clear(); App.render(); };
ACT['dup-del'] = () => { const l = [...DUP.sel].map(k => LIB.map.get(k)).filter(Boolean); if (l.length) Items.del(l); };

/* ---------- Trash (Android 11+) ---------- */
VIEWS.trash = main => {
  if (!Native.info.canTrash) { main.innerHTML = `<div class="empty">${ic('trash', 44)}<h3>Trash needs Android 11 or newer</h3><p>On this phone, deleting is permanent, so NerdyPlayer always asks first.</p></div>`; return { title: 'Trash', back: true }; }
  if (!App.trashAsked) { App.trashAsked = true; Native.call('scanTrash'); }
  const l = LIB.trash;
  if (!l.length) { main.innerHTML = `<div class="empty">${ic('trash', 44)}<h3>Trash is empty</h3><p>Things you delete go here for 30 days, so you can bring them back.</p></div>`; return { title: 'Trash', back: true }; }
  main.innerHTML = `<div class="count">${plural(l.length, 'item')} · ${sizeStr(l.reduce((a, b) => a + b.s, 0))} · removed for good after about 30 days</div><div id="gv"></div>`;
  const gv = new GridView($('#gv'), l, {
    mode: 'list', group: 'none', cols: 3, root: $('#main'),
    onTap: it => { if (SEL.on) selToggle(it); else Sheet.open(`<div class="kvs"><div class="kv"><span>Name</span><b>${esc(it.n)}</b></div><div class="kv"><span>Size</span><b>${sizeStr(it.s)}</b></div><div class="kv"><span>Folder</span><b>${esc(it.b)}</b></div>${it.x ? `<div class="kv"><span>Removed for good in</span><b>${Math.max(0, Math.ceil((it.x * 1000 - Date.now()) / 86400000))} days</b></div>` : ''}</div><div class="row gap" style="margin-top:14px"><button class="btn pri grow" id="trr">${ic('undo', 16)} Restore</button><button class="btn danger grow" id="trd">${ic('trash', 16)} Delete now</button></div>`, { title: it.n });
      $('#trr').onclick = () => { Sheet.close(); Native.call('restoreTrash', JSON.stringify([it.key])); }; $('#trd').onclick = () => { Sheet.close(); trashDelete([it]); }; },
    onLong: it => { SEL.ctx = 'trash'; SEL.grid = gv; selEnter(it, gv); }, onMore: null,
  });
  App.gv = gv; SEL.grid = gv; SEL.ctx = 'trash';
  return { title: 'Trash', back: true };
};
async function trashDelete(list) {
  const ok = await confirmBox(`Delete ${plural(list.length, 'item')} for good?`, 'They are removed from the trash and cannot be brought back.', 'Delete forever', true);
  if (ok) Native.call('deleteKeys', JSON.stringify(list.map(i => i.key)), true);
}
ACT['trash-restore'] = () => { const k = selKeys(); selExit(); Native.call('restoreTrash', JSON.stringify(k)); };
ACT['trash-del'] = () => { const l = selItems(); selExit(); trashDelete(l); };
