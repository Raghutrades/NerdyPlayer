'use strict';
/* ===== NerdyPlayer · video engines =====
   One player screen, two engines behind it:
   - Standard: the phone's own decoder through an HTML5 <video> (fast start, MP4 / WebM / 3GP ...)
   - VLC: a native engine drawn behind the page (MKV, AVI, WMV, FLV, TS, HEVC, AC3/DTS audio, half-downloaded files ...)
   The player code talks to both through the same small interface, so nothing looks or works differently. */

const NATIVE_EXT = /\.(mkv|avi|wmv|flv|f4v|ts|m2ts|mts|mpg|mpeg|vob|rm|rmvb|asf|divx|xvid|ogv|ogm|mxf|dat|m2v|3g2|mka|part|crdownload|tmp|download|!qb|aria2)$/i;
function wantsNative(it) {
  if (!AB || !Native.info.vlc) return false;
  if (it.url && it.url.startsWith('blob:')) return false;          // a browser blob cannot be handed to the native side
  if (ST.engine === 'standard') return false;
  if (ST.engine === 'vlc') return true;
  return NATIVE_EXT.test(it.n || '') || /matroska|x-msvideo|x-ms-wmv|flv|mp2t|mpeg$/i.test(it.m || '') || (it.ext && !/\.(mp4|m4v|webm|3gp|mov)$/i.test(it.n || ''));
}

class NV extends EventTarget {
  constructor() { super(); this.style = {}; this.volume = 1; this.muted = false; this.preservesPitch = true; this.reset(); }
  reset() { this._t = 0; this._at = 0; this._d = NaN; this._paused = true; this._rate = 1; this._ended = false; this.videoWidth = 0; this.videoHeight = 0; this.readyState = 0; this._meta = false; this._open = false; }
  emit(n) { this.dispatchEvent(new Event(n)); }
  get currentTime() { if (!this._paused && !this._ended && this._at) { const t = this._t + (performance.now() - this._at) / 1000 * this._rate; return isFinite(this._d) ? Math.min(this._d, t) : t; } return this._t; }
  set currentTime(s) { s = Math.max(0, +s || 0); this._t = s; this._at = performance.now(); this._ended = false; Native.call('npSeek', Math.round(s * 1000)); this.emit('seeking'); clearTimeout(this._sk); this._sk = setTimeout(() => this.emit('seeked'), 300); }
  get duration() { return this._d; }
  get paused() { return this._paused; }
  get ended() { return this._ended; }
  get playbackRate() { return this._rate; }
  set playbackRate(r) { this._rate = r; Native.call('npRate', r); this.emit('ratechange'); }
  set defaultPlaybackRate(r) { }
  play() { if (this._ended) { this._t = 0; Native.call('npSeek', 0); this._ended = false; } Native.call('npPlay'); if (this._paused) { this._paused = false; this._at = performance.now(); this.emit('play'); } return Promise.resolve(); }
  pause() { if (!this._paused) { this._t = this.currentTime; this._paused = true; Native.call('npPause'); this.emit('pause'); } else Native.call('npPause'); }
  load() { } removeAttribute() { } setAttribute() { }
  open(it, startMs) {
    this.reset(); this.videoWidth = it.w || 0; this.videoHeight = it.h || 0; this._open = true;
    const spec = it.ext ? { kind: 's', id: it.id } : it.vault ? { kind: 'v', id: it.id } : { kind: 'm', key: it.key };
    spec.start = startMs || 0;
    Native.call('npOpen', JSON.stringify(spec));
    this._paused = false; this._at = performance.now();
  }
  /* events that arrive from the native side */
  onNative(o) {
    if (!this._open) return;
    const now = performance.now();
    if (o.t === 'len') { this._d = o.ms > 0 ? o.ms / 1000 : NaN; this.readyState = 4; if (!this._meta) { this._meta = true; this.emit('loadedmetadata'); } this.emit('durationchange'); }
    else if (o.t === 'time') { this._t = o.ms / 1000; this._at = now; this.emit('timeupdate'); }
    else if (o.t === 'buf') { if (o.p < 100) this.emit('waiting'); else this.emit('canplay'); }
    else if (o.t === 'state') {
      if (o.s === 'playing') { const was = this._paused; this._paused = false; this._at = now; this.readyState = 4; if (!this._meta) { this._meta = true; this.emit('loadedmetadata'); } this.emit('play'); this.emit('playing'); }
      else if (o.s === 'paused') { if (!this._paused) { this._t = this.currentTime; this._paused = true; this.emit('pause'); } }
      else if (o.s === 'ended') { this._ended = true; this._paused = true; this._t = isFinite(this._d) ? this._d : this._t; this.emit('ended'); }
      else if (o.s === 'error') { this.emit('error'); }
    } else if (o.t === 'error') this.emit('error');
    else if (o.t === 'tracks') { if (typeof Player !== 'undefined' && Player.onTracks) Player.onTracks(); }
  }
}
Native.on('np', o => { if (typeof Player !== 'undefined' && Player.nv) Player.nv.onNative(o); });
Native.on('npshot', o => toast(o.ok ? 'Frame saved to Pictures/NerdyPlayer' : 'Could not save the frame'));

/* CSS filter values -> an Android colour matrix (4x5, 20 numbers) */
function colorMatrix(a) {
  const x = Object.assign({}, ADJ0, a || {});
  let M = [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0];
  const mul = B => { const R = new Array(20); for (let r = 0; r < 4; r++) for (let c = 0; c < 5; c++) { let s = 0; for (let k = 0; k < 4; k++) s += B[r * 5 + k] * M[k * 5 + c]; if (c === 4) s += B[r * 5 + 4]; R[r * 5 + c] = s; } M = R; };
  const lin = (k, o = 0) => [k, 0, 0, 0, o, 0, k, 0, 0, o, 0, 0, k, 0, o, 0, 0, 0, 1, 0];
  if (x.b !== 100) mul(lin(x.b / 100));
  if (x.c !== 100) { const c = x.c / 100; mul(lin(c, 255 * 0.5 * (1 - c))); }
  const sat = s => [0.213 + 0.787 * s, 0.715 - 0.715 * s, 0.072 - 0.072 * s, 0, 0, 0.213 - 0.213 * s, 0.715 + 0.285 * s, 0.072 - 0.072 * s, 0, 0, 0.213 - 0.213 * s, 0.715 - 0.715 * s, 0.072 + 0.928 * s, 0, 0, 0, 0, 0, 1, 0];
  if (x.s !== 100) mul(sat(x.s / 100));
  if (x.h) { const r = x.h * Math.PI / 180, c = Math.cos(r), s = Math.sin(r); mul([0.213 + c * 0.787 - s * 0.213, 0.715 - c * 0.715 - s * 0.715, 0.072 - c * 0.072 + s * 0.928, 0, 0, 0.213 - c * 0.213 + s * 0.143, 0.715 + c * 0.285 + s * 0.140, 0.072 - c * 0.072 - s * 0.283, 0, 0, 0.213 - c * 0.213 - s * 0.787, 0.715 - c * 0.715 + s * 0.715, 0.072 + c * 0.928 + s * 0.072, 0, 0, 0, 0, 0, 1, 0]); }
  if (x.g) mul(sat(1 - x.g / 100));
  if (x.se) { const k = x.se / 100; mul([1 - 0.607 * k, 0.769 * k, 0.189 * k, 0, 0, 0.349 * k, 1 - 0.314 * k, 0.168 * k, 0, 0, 0.272 * k, 0.534 * k, 1 - 0.869 * k, 0, 0, 0, 0, 0, 1, 0]); }
  if (x.inv) { const k = x.inv / 100; mul([1 - 2 * k, 0, 0, 0, 255 * k, 0, 1 - 2 * k, 0, 0, 255 * k, 0, 0, 1 - 2 * k, 0, 255 * k, 0, 0, 0, 1, 0]); }
  return M.map(v => Math.round(v * 1000) / 1000);
}
