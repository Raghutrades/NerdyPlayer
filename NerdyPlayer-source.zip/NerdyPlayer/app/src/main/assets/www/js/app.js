'use strict';
/* ===== NerdyPlayer · core: state, library, albums, selection, router ===== */
const CFG0 = { theme: 'midnight', accent: null, card: 'soft', btn: 'gradient', nav: 'bar', vw: { all: 'grid', photos: 'grid', videos: 'feed', fav: 'grid' }, live: true, vlock: true, ambient: true, autoland: true, immersive: true, cols: 3, names: false, dates: true, interval: 4, trans: 'fade', shuffle: false, loop: true, twist: false, resume: true, seek: 10, gest: true, xform: true, hold: 2, speed: 1, autopip: false, aspect: 0, bio: true };
let CFG = Object.assign({}, CFG0, store.get('np_cfg_js', {}));
if (!CFG.vw) CFG.vw = Object.assign({}, CFG0.vw);
if (CFG.accent === '#8b5cf6') CFG.accent = null;
const HID = new Set(store.get('np_hid', []));
const saveHid = () => store.set('np_hid', [...HID]);
const S = { media: [], vault: [], fav: new Set(store.get('np_fav', [])), view: 'lib', params: {}, stack: [], tab: 'all', q: '', search: false, sort: store.get('np_sort', 'new'), sel: new Set(), selMode: false, st: {}, pick: false, loaded: false, stuck: [], resumes: {}, cur: { items: [], ctx: 'lib' }, map: new Map() };
const K = it => it.t + it.i;
const nat = (fn, ...a) => { try { return window.Native && Native[fn] ? Native[fn](...a) : undefined; } catch (e) { return undefined; } };
const isVid = it => it.t === 'v';
const thumbUrl = it => it.vault ? '/vt/' + it.uid : '/thumb/' + it.t + '/' + it.i;

function saveCfg() {
  store.set('np_cfg_js', CFG);
  applyTheme();
  nat('setCfg', 'resume', !!CFG.resume);
  nat('setCfg', 'autopip', !!CFG.autopip);
  nat('setCfg', 'ambient', !!CFG.ambient);
  nat('setCfg', 'autoland', !!CFG.autoland);
}
function applyTheme() {
  const r = document.documentElement;
  if (CFG.theme === 'midnight') r.removeAttribute('data-theme'); else r.setAttribute('data-theme', CFG.theme);
  r.setAttribute('data-card', CFG.card); r.setAttribute('data-btn', CFG.btn); r.setAttribute('data-nav', CFG.nav);
  if (CFG.accent) { r.style.setProperty('--ac', CFG.accent); r.style.removeProperty('--ac2'); } else { r.style.removeProperty('--ac'); r.style.removeProperty('--ac2'); }
  r.style.setProperty('--cols', CFG.cols);
  const c = (getComputedStyle(r).getPropertyValue('--bg2') || '#121522').trim();
  nat('bars', c.length === 4 ? '#' + c[1] + c[1] + c[2] + c[2] + c[3] + c[3] : (c || '#121522'), ['light', 'paper'].includes(CFG.theme));
}
const saveFav = () => store.set('np_fav', [...S.fav]);
function toggleFav(k) { if (S.fav.has(k)) S.fav.delete(k); else S.fav.add(k); saveFav(); }

/* ---------- data ---------- */
async function loadMedia() {
  try {
    const r = await fetch('/api/media', { cache: 'no-store' });
    if (r.status === 403) { S.media = []; S.stuck = []; S.loaded = false; return; }
    const a = await r.json();
    a.sort((x, y) => y.d - x.d);
    /* items already copied into the vault are never shown again in here, even if Android has not removed the original yet */
    const present = new Set(a.map(K));
    let changed = false;
    for (const k of [...HID]) if (!present.has(k)) { HID.delete(k); changed = true; }
    if (changed) saveHid();
    S.stuck = a.filter(x => HID.has(K(x)));
    S.media = a.filter(x => !HID.has(K(x)));
    S.loaded = true;
    try { S.resumes = JSON.parse(nat('resumes') || '{}'); } catch (e) { S.resumes = {}; }
  } catch (e) { S.media = []; }
}
async function loadVault() {
  try {
    const r = await fetch('/api/vault', { cache: 'no-store' });
    if (r.status === 403) { S.vault = []; return false; }
    const a = await r.json();
    S.vault = a.map(e => ({ vault: 1, uid: e.u, t: e.t, i: e.u, n: e.n, s: e.s, w: e.w, h: e.h, u: e.u2 || 0, m: e.m, b: e.b, d: e.d, a: e.a })).sort((x, y) => y.a - x.a);
    return true;
  } catch (e) { S.vault = []; return false; }
}

/* ---------- list helpers ---------- */
const SORTS = { new: 'Newest first', old: 'Oldest first', name: 'Name A–Z', size: 'Largest first', dur: 'Longest video' };
function sortItems(a) {
  const f = { new: (x, y) => y.d - x.d, old: (x, y) => x.d - y.d, name: (x, y) => x.n.localeCompare(y.n), size: (x, y) => y.s - x.s, dur: (x, y) => (y.u - x.u) || (y.d - x.d) }[S.sort];
  return a.slice().sort(f);
}
function filterQ(a) {
  const q = S.q.trim().toLowerCase();
  return q ? a.filter(it => (it.n + ' ' + (it.b || '') + ' ' + (it.p || '')).toLowerCase().includes(q)) : a;
}
function tabItems() {
  let a = S.media;
  if (S.tab === 'photos') a = a.filter(x => x.t === 'i');
  else if (S.tab === 'videos') a = a.filter(x => x.t === 'v');
  else if (S.tab === 'fav') a = a.filter(x => S.fav.has(K(x)));
  return sortItems(filterQ(a));
}
function albums() {
  const m = new Map();
  for (const it of S.media) { const b = it.b || 'Other'; if (!m.has(b)) m.set(b, []); m.get(b).push(it); }
  return [...m.entries()].map(([name, items]) => ({ name, items, size: items.reduce((s, x) => s + x.s, 0) })).sort((a, b) => b.items.length - a.items.length);
}
function smart(id) {
  const now = Date.now();
  switch (id) {
    case 'recent': return S.media.filter(x => now - x.d < 7 * 864e5);
    case 'shots': return S.media.filter(x => /screenshot|screen_?shot|screen ?record/i.test((x.b || '') + ' ' + x.n + ' ' + (x.p || '')));
    case 'large': return S.media.filter(x => x.s > 50 * 1048576).sort((a, b) => b.s - a.s);
    case 'long': return S.media.filter(x => x.t === 'v' && x.u > 600000).sort((a, b) => b.u - a.u);
    case 'fav': return S.media.filter(x => S.fav.has(K(x)));
    case 'camera': return S.media.filter(x => /camera|dcim/i.test((x.b || '') + ' ' + (x.p || '')));
    default: return [];
  }
}
const SMART = { recent: ['Recently added', 'Last 7 days', 'clock'], shots: ['Screenshots & recordings', 'Screens you captured', 'camera'], large: ['Large files', 'Over 50 MB, biggest first', 'pie'], long: ['Long videos', 'Longer than 10 minutes', 'film'], camera: ['Camera roll', 'Taken with this phone', 'camera'], fav: ['Favourites', 'Things you marked', 'heart'] };

/* ---------- grid ---------- */
function groupDays(items) {
  const out = []; let last = null, head = null;
  for (const it of items) {
    const l = dayLabel(it.d);
    if (l !== last) { head = { hd: l, n: 0 }; out.push(head); last = l; }
    head.n++; out.push(it);
  }
  return out;
}
function cellHTML(it, o) {
  const k = K(it), sel = S.sel.has(k) ? ' sel' : '';
  const b = isVid(it) ? `<span class="b">${ic('play', 11)}${durStr(it.u)}</span>` : '';
  const fv = S.fav.has(k) ? `<span class="fv">${ic('heartfill', 15)}</span>` : '';
  const nm = CFG.names ? `<div class="nm">${esc(it.n)}</div>` : '';
  const ar = o && o.mosaic && it.w && it.h ? ` style="aspect-ratio:${(Math.max(0.55, Math.min(1.9, it.w / it.h))).toFixed(3)}"` : '';
  const pg = isVid(it) && S.resumes['m:' + it.i] && it.u ? `<span style="position:absolute;left:0;bottom:0;height:3px;background:var(--ac);width:${Math.min(100, S.resumes['m:' + it.i] / it.u * 100)}%"></span>` : '';
  return `<div class="cell${sel}" data-k="${esc(k)}"${ar}>${pg}<img loading="lazy" src="${thumbUrl(it)}" onload="this.classList.add('ok')" onerror="this.classList.add('ok')">${b}${fv}${nm}<span class="ck">${ic('check', 14)}</span></div>`;
}
let _io = null;
function mountGrid(host, items, o = {}) {
  S.cur = { items, ctx: o.ctx || 'lib' };
  S.map = new Map(items.map(i => [K(i), i]));
  if (!items.length) { host.innerHTML = o.empty || ''; return; }
  const mos = o.style === 'mosaic';
  const flat = (!mos && o.group !== false && CFG.dates && !o.vault) ? groupDays(items) : items;
  host.innerHTML = `<div class="${mos ? 'mosaic' : 'grid'}" id="gd"></div><div id="sent" style="height:2px"></div>`;
  const g = $('#gd', host), sent = $('#sent', host);
  let pos = 0;
  const more = () => {
    if (pos >= flat.length) { if (_io) _io.disconnect(); return; }
    let html = '';
    const end = Math.min(flat.length, pos + 120);
    for (; pos < end; pos++) { const x = flat[pos]; html += x.hd ? `<div class="dh" style="grid-column:1/-1"><span>${esc(x.hd)}</span><span class="mute xs">${x.n}</span></div>` : cellHTML(x, { mosaic: mos }); }
    g.insertAdjacentHTML('beforeend', html);
  };
  more();
  S.renderAll = () => { while (pos < flat.length) more(); };
  if (_io) _io.disconnect();
  _io = new IntersectionObserver(es => { if (es[0].isIntersecting) more(); }, { root: $('#main'), rootMargin: '1200px' });
  _io.observe(sent);
}
function mountView(host, items, o = {}) {
  const st = o.style || 'grid';
  Preview.stopAll();
  S.cur = { items, ctx: o.ctx || 'lib' };
  S.map = new Map(items.map(i => [K(i), i]));
  S.renderAll = null;
  if (!items.length) { host.innerHTML = o.empty || ''; return; }
  if (st === 'feed') return Feed.mount(host, items);
  if (st === 'stack') return Stack.mount(host, items);
  mountGrid(host, items, Object.assign({}, o, { style: st }));
}
function refreshCell(k) {
  const c = $(`.cell[data-k="${k}"]`); if (!c) return;
  c.classList.toggle('sel', S.sel.has(k));
}

/* ---------- selection ---------- */
function startSel(k) {
  S.selMode = true; if (k) S.sel.add(k);
  document.body.classList.add('selmode'); renderBar(); renderSel();
  if (k) refreshCell(k);
}
function endSel() {
  const was = [...S.sel]; S.sel.clear(); S.selMode = false; S.pick = false;
  document.body.classList.remove('selmode'); was.forEach(refreshCell); renderBar(); renderSel();
  if (S.view === 'lib') renderMain();
}
function toggleSel(k) {
  if (S.sel.has(k)) S.sel.delete(k); else S.sel.add(k);
  refreshCell(k);
  if (!S.sel.size && !S.pick) return endSel();
  renderBar(); renderSel();
}
function selectAll() {
  const all = S.cur.items.map(K);
  if (S.sel.size === all.length) S.sel.clear(); else all.forEach(k => S.sel.add(k));
  $$('.cell').forEach(c => c.classList.toggle('sel', S.sel.has(c.dataset.k)));
  renderBar(); renderSel();
}
const selItems = () => [...S.sel].map(k => S.map.get(k)).filter(Boolean);

function renderSel() {
  const b = $('#selbar');
  b.classList.toggle('on', S.selMode);
  if (!S.selMode) return;
  const n = S.sel.size, v = S.cur.ctx === 'vault';
  const btn = (id, i, t, cls = '') => `<button data-sa="${id}" class="${cls}" ${n ? '' : 'disabled style="opacity:.4"'}>${ic(i, 22)}<span>${t}</span></button>`;
  b.innerHTML = `<button data-sa="all">${ic('check', 22)}<span>All</span></button>` + (v
    ? btn('restore', 'undo', 'Restore') + btn('vdel', 'trash', 'Delete', 'dn')
    : (n === 1 ? btn('share', 'share', 'Share') : '') + btn('fav', 'heart', 'Favourite') + btn('hide', 'eyeoff', 'Hide') + btn('del', 'trash', 'Delete', 'dn'));
}
async function selAction(a) {
  const items = selItems();
  if (a === 'all') return selectAll();
  if (!items.length) return;
  if (a === 'share') return nat('share', items[0].t, items[0].i);
  if (a === 'fav') { const all = items.every(x => S.fav.has(K(x))); items.forEach(x => all ? S.fav.delete(K(x)) : S.fav.add(K(x))); saveFav(); toast(all ? 'Removed from favourites' : 'Added to favourites'); return endSel(); }
  if (a === 'del') {
    const ok = await confirmBox('Delete ' + items.length + (items.length > 1 ? ' items' : ' item') + '?', 'Android will ask you to confirm. This removes them from your phone.', 'Delete', true);
    if (ok) nat('del', JSON.stringify(items.map(x => [x.t, +x.i])));
  }
  if (a === 'hide') Sec.needVault(async () => {
    const ok = await confirmBox('Move to private vault?', items.length + ' item(s) will be encrypted and hidden from the gallery and other apps. Android will then ask to remove the originals.', 'Hide');
    if (ok) { toast('Encrypting…', 6000); nat('hide', JSON.stringify(items.map(x => [x.t, +x.i]))); }
  });
  if (a === 'restore') {
    nat('restore', JSON.stringify(items.map(x => x.uid))); toast('Restoring…', 5000);
  }
  if (a === 'vdel') {
    const ok = await confirmBox('Delete forever?', items.length + ' item(s) will be erased from the vault. This cannot be undone.', 'Delete forever', true);
    if (ok) nat('vdelete', JSON.stringify(items.map(x => x.uid)));
  }
}

/* ---------- opening items ---------- */
function openItem(it, list) {
  const items = list || S.cur.items;
  if (isVid(it)) {
    const vids = items.filter(isVid);
    const arr = vids.map(v => ({ s: v.vault ? 'v:' + v.uid : 'm:' + v.i, t: v.n }));
    nat('play', JSON.stringify({ i: Math.max(0, vids.indexOf(it)), items: arr }));
  } else {
    const imgs = items.filter(x => !isVid(x));
    Viewer.open(imgs, imgs.indexOf(it), S.cur.ctx === 'vault' ? 'vault' : 'lib');
  }
}

/* ---------- router ---------- */
const NAVMAP = { lib: 'lib', albums: 'albums', album: 'albums', vault: 'vault', tools: 'tools', smart: 'tools', dups: 'tools', storage: 'tools', more: 'more', settings: 'more', about: 'more' };
function leaveVault() {
  if (S.view === 'vault' && CFG.vlock && S.st.vault && !S.pick) {
    nat('lockVault'); S.st.vault = false; S.vault = []; S.vaultOpen = false;
    if (Viewer.isOn() && Viewer.ctx() === 'vault') Viewer.close(true);
  }
}
function go(view, params = {}, push = true) {
  if (view !== 'vault') leaveVault();
  if (S.selMode) endSel();
  if (push && !['lib', 'albums', 'vault', 'tools', 'more'].includes(view)) S.stack.push({ view: S.view, params: S.params });
  else if (['lib', 'albums', 'vault', 'tools', 'more'].includes(view)) S.stack = [];
  S.view = view; S.params = params; S.search = false; S.q = '';
  render();
}
function back() {
  if (!S.stack.length) return false;
  leaveVault();
  const p = S.stack.pop(); S.view = p.view; S.params = p.params; S.search = false; S.q = ''; render(); return true;
}
function render() {
  renderBar(); renderMain(); renderSel();
  $$('#nav button').forEach(b => b.classList.toggle('on', b.dataset.v === NAVMAP[S.view]));
  $('#main').scrollTop = 0;
}
const TITLES = { lib: 'NerdyPlayer', albums: 'Albums', vault: 'Private vault', tools: 'Tools', more: 'More', settings: 'Settings', about: 'About', dups: 'Duplicates', storage: 'Storage insights' };
function renderBar() {
  const bar = $('#bar');
  if (S.selMode) {
    bar.innerHTML = `<button class="ib" data-b="endsel">${ic('close', 22)}</button><h1>${S.sel.size} selected</h1>`;
    return;
  }
  if (S.search) {
    bar.innerHTML = `<button class="ib" data-b="closesearch">${ic('back', 22)}</button><input id="q" class="tx" placeholder="Search name or album" value="${esc(S.q)}" style="flex:1">`;
    return;
  }
  const sub = S.stack.length > 0;
  let title = TITLES[S.view] || 'NerdyPlayer';
  if (S.view === 'album') title = S.params.name;
  if (S.view === 'smart') title = SMART[S.params.id][0];
  const canSearch = ['lib', 'album'].includes(S.view);
  const menu = ['lib', 'album', 'albums'].includes(S.view);
  bar.innerHTML = `${sub ? `<button class="ib" data-b="back">${ic('back', 22)}</button>` : `<span style="width:8px"></span>`}<h1>${esc(title)}</h1>
    ${canSearch ? `<button class="ib" data-b="search">${ic('search', 22)}</button>` : ''}
    ${S.view === 'vault' && S.vaultOpen ? `<button class="ib" data-b="vlock">${ic('lock', 22)}</button>` : ''}
    ${menu ? `<button class="ib" data-b="menu">${ic('more', 22)}</button>` : ''}`;
}
function renderMain() {
  const m = $('#main');
  if (S.view !== 'lib') Scrub.refresh(false);
  document.body.classList.toggle('selmode', S.selMode);
  switch (S.view) {
    case 'lib': return viewLib(m);
    case 'albums': return viewAlbums(m);
    case 'album': return viewList(m, albums().find(a => a.name === S.params.name)?.items || [], { sorted: true });
    case 'smart': return viewList(m, smart(S.params.id), {});
    case 'vault': return Vault_.render(m);
    case 'tools': return viewTools(m);
    case 'more': return viewMore(m);
    case 'settings': return viewSettings(m);
    case 'about': return m.innerHTML = vAbout();
    case 'dups': return viewDups(m);
    case 'storage': return viewStorage(m);
  }
}

function permScreen(m) {
  m.innerHTML = `<div class="empty"><div class="big">${ic('image', 34)}</div><h2 style="color:var(--tx);margin:0 0 6px">Allow access to your photos and videos</h2><p>NerdyPlayer reads your media only on this phone. It has no internet permission, so nothing can be uploaded.</p><button class="btn pri" data-b="perm">Allow access</button></div>`;
}
function memories() {
  const n = new Date(), md = n.getMonth() + '-' + n.getDate(), by = new Map();
  for (const it of S.media) { const d = new Date(it.d); if (d.getFullYear() === n.getFullYear()) continue; if (d.getMonth() + '-' + d.getDate() !== md) continue; const y = d.getFullYear(); if (!by.has(y)) by.set(y, []); by.get(y).push(it); }
  return [...by.entries()].sort((a, b) => b[0] - a[0]).map(([year, items]) => ({ year, items, ago: n.getFullYear() - year }));
}
function continueList() {
  const out = [];
  for (const it of S.media) { if (it.t !== 'v') continue; const p = S.resumes['m:' + it.i]; if (p && p > 5000 && it.u && p < it.u - 5000) out.push(it); }
  return out.slice(0, 12);
}
function railsHTML() {
  let h = '';
  if (S.q) return h;
  const mem = S.tab === 'all' ? memories() : [];
  if (mem.length) h += `<div class="rh">${ic('calendar', 18)} On this day</div><div class="rail">${mem.map((m, i) => `<div class="rc2" data-mem="${i}"><img src="${thumbUrl(m.items[0])}" onload="this.classList.add('ok')"><div class="t">${m.ago} year${m.ago > 1 ? 's' : ''} ago · ${m.items.length}</div></div>`).join('')}</div>`;
  S._mem = mem;
  const cw = (S.tab === 'all' || S.tab === 'videos') ? continueList() : [];
  if (cw.length) h += `<div class="rh">${ic('play', 18)} Continue watching</div><div class="rail">${cw.map(v => `<div class="rc2 w" data-cw="${esc(K(v))}"><img src="${thumbUrl(v)}"><span class="pl">${ic('play', 13)}</span><div class="t">${esc(v.n)}</div><span class="pgb" style="width:${Math.min(100, S.resumes['m:' + v.i] / v.u * 100)}%"></span></div>`).join('')}</div>`;
  S._cw = cw;
  return h;
}
function viewLib(m) {
  if (!S.st.perm) return permScreen(m);
  const tabs = [['all', 'All'], ['photos', 'Photos'], ['videos', 'Videos'], ['fav', 'Favourites']];
  const items = tabItems();
  const style = CFG.vw[S.tab] || 'grid';
  const vi = VIEWS.find(v => v[0] === style) || VIEWS[0];
  const banner = S.pick ? `<div class="banner">${ic('eyeoff', 18)}<span>Select photos or videos to move into your private vault.</span></div>` : '';
  const stuck = S.stuck.length && !S.pick ? `<div class="banner warn">${ic('warn', 18)}<span>${S.stuck.length} hidden item${S.stuck.length > 1 ? 's are' : ' is'} still in your phone’s gallery, so other apps can see ${S.stuck.length > 1 ? 'them' : 'it'}.</span><button data-b="rmstuck">Remove</button></div>` : '';
  m.innerHTML = `<div id="tabs">${tabs.map(t => `<button class="chip ${S.tab === t[0] ? 'on' : ''}" data-tab="${t[0]}">${t[1]}${S.tab === t[0] ? ' · ' + items.length : ''}</button>`).join('')}<button class="chip vwchip" data-b="views">${ic(vi[2], 16)} ${vi[1]}</button></div>${banner}${stuck}${railsHTML()}<div id="gh"></div>`;
  mountView($('#gh'), items, { style, empty: emptyHTML(S.q ? 'No matches' : S.tab === 'fav' ? 'No favourites yet. Long-press a photo and tap Favourite.' : S.loaded ? 'Nothing here yet' : 'Loading…', 'image') });
  Scrub.refresh(style === 'grid' && !S.pick);
}
function viewMenu() {
  const cur = CFG.vw[S.tab] || 'grid';
  sheet('How to see your ' + (S.tab === 'videos' ? 'videos' : S.tab === 'photos' ? 'photos' : 'media'), VIEWS.map(v => ({ i: v[2], t: v[1], s: v[3], on: cur === v[0], fn: () => { CFG.vw[S.tab] = v[0]; saveCfg(); renderMain(); } })).concat([{ i: 'reels', t: 'Reels', s: 'Full screen', fn: () => Reels.open(tabItems(), 0) }]), '', true);
}
function emptyHTML(t, i) { return `<div class="empty"><div class="big">${ic(i || 'image', 32)}</div>${esc(t)}</div>`; }
function viewList(m, items, o) {
  const it = o.sorted ? sortItems(filterQ(items)) : filterQ(items);
  const sub = S.view === 'smart' ? `<p class="sub pad" style="margin:0">${esc(SMART[S.params.id][1])} · ${it.length} item${it.length === 1 ? '' : 's'}${it.length ? ' · ' + sizeStr(it.reduce((s, x) => s + x.s, 0)) : ''}</p>` : '';
  m.innerHTML = sub + '<div id="gh"></div>';
  mountView($('#gh'), it, { style: CFG.vw.all === 'feed' || CFG.vw.all === 'stack' || CFG.vw.all === 'mosaic' ? CFG.vw.all : 'grid', empty: emptyHTML('Nothing here', 'image') });
}
function viewAlbums(m) {
  if (!S.st.perm) return permScreen(m);
  const al = albums();
  if (!al.length) { m.innerHTML = emptyHTML('No albums yet', 'folder'); return; }
  const cover = a => { const c = a.items[0]; return `<div class="cell" style="aspect-ratio:1.25"><img loading="lazy" src="${thumbUrl(c)}" onload="this.classList.add('ok')" onerror="this.classList.add('ok')"></div>`; };
  m.innerHTML = `<div class="alb">${al.map((a, i) => `<div class="albc" data-al="${i}">${cover(a)}<div class="t"><b>${esc(a.name)}</b><span class="xs mute">${a.items.length} items · ${sizeStr(a.size)}</span></div></div>`).join('')}</div>`;
  S._al = al;
}

/* ---------- tools & more ---------- */
function viewTools(m) {
  const row = (id, i, t, s, act) => `<div class="li" data-act="${act}" data-id="${id}"><span class="ico">${ic(i, 20)}</span><div class="grow"><b>${t}</b><div class="xs mute">${s}</div></div>${ic('back', 16).replace('<svg', '<svg style="transform:rotate(180deg);opacity:.5"')}</div>`;
  const sm = id => { const n = smart(id).length; return SMART[id][1] + (S.st.perm ? ' · ' + n : ''); };
  m.innerHTML = `<div class="pad"><p class="sub">Smart lists and clean-up helpers. Everything is worked out on your phone.</p>
  <div class="card list">
   ${row('', 'show', 'Slideshow', 'Play your photos with transitions', 'show')}
   ${row('', 'layers', 'Duplicate finder', 'Same size, shape and length', 'dups')}
   ${row('', 'pie', 'Storage insights', 'What takes up the space', 'storage')}
  </div><h3 style="margin:18px 0 8px">Smart lists</h3><div class="card list">
   ${['recent', 'shots', 'camera', 'large', 'long', 'fav'].map(id => row(id, SMART[id][2], SMART[id][0], sm(id), 'smart')).join('')}
  </div></div>`;
}
function viewMore(m) {
  const row = (i, t, s, act) => `<div class="li" data-act="${act}"><span class="ico">${ic(i, 20)}</span><div class="grow"><b>${t}</b><div class="xs mute">${s}</div></div></div>`;
  m.innerHTML = `<div class="pad"><div class="card list">
   ${row('settings', 'Settings', 'Look, security, player and slideshow', 'settings')}
   ${row('shield', 'Privacy & security', 'PIN, app lock, screenshots', 'sec')}
   ${row('info', 'About', 'The person behind NerdyPlayer', 'about')}
   ${row('lock', 'Lock now', 'Locks the vault' + (Guard_appLock() ? ' and the whole app' : ''), 'locknow')}
  </div><p class="xs mute tc">NerdyPlayer 1.0 · fully offline · no internet permission</p></div>`;
}
const Guard_appLock = () => S.st.applock;

function viewDups(m) {
  const g = new Map();
  for (const it of S.media) { if (!it.s) continue; const k = [it.t, it.s, it.w, it.h, it.u].join('|'); if (!g.has(k)) g.set(k, []); g.get(k).push(it); }
  const groups = [...g.values()].filter(a => a.length > 1).sort((a, b) => b[0].s * (b.length - 1) - a[0].s * (a.length - 1));
  const waste = groups.reduce((s, a) => s + a[0].s * (a.length - 1), 0);
  S._dups = groups;
  m.innerHTML = `<div class="pad"><p class="sub">${groups.length ? `${groups.length} groups of likely duplicates · ${sizeStr(waste)} could be freed.` : 'No duplicates found.'}</p>${groups.slice(0, 60).map((a, gi) => `<div class="card"><div class="row"><b class="grow">${esc(a[0].n)}</b><span class="xs mute">${a.length} copies · ${sizeStr(a[0].s)}</span></div><div class="dup">${a.map(x => `<div class="cell" data-dk="${esc(K(x))}"><img src="${thumbUrl(x)}" onload="this.classList.add('ok')"><span class="b">${esc(x.b || '')}</span></div>`).join('')}</div><button class="btn sm danger" data-dd="${gi}">${ic('trash', 14)} Delete extra copies (keep the oldest)</button></div>`).join('')}</div>`;
  S.map = new Map(S.media.map(i => [K(i), i]));
}
function viewStorage(m) {
  const P = S.media.filter(x => x.t === 'i'), V = S.media.filter(x => x.t === 'v');
  const sum = a => a.reduce((s, x) => s + x.s, 0), tp = sum(P), tv = sum(V), tot = tp + tv || 1;
  const al = albums().sort((a, b) => b.size - a.size).slice(0, 8);
  const top = S.media.slice().sort((a, b) => b.s - a.s).slice(0, 10);
  S.cur = { items: top, ctx: 'lib' }; S.map = new Map(S.media.map(i => [K(i), i]));
  m.innerHTML = `<div class="pad"><div class="card"><div class="kv"><span>Photos</span><b>${P.length} · ${sizeStr(tp)}</b></div><div class="bar"><i style="width:${tp / tot * 100}%"></i></div><div class="kv"><span>Videos</span><b>${V.length} · ${sizeStr(tv)}</b></div><div class="bar"><i style="width:${tv / tot * 100}%"></i></div><div class="kv"><span>Vault</span><b>${S.st.vault ? S.vault.length + ' items' : 'locked'}</b></div></div>
  <h3 style="margin:16px 0 8px">Biggest albums</h3><div class="card">${al.map(a => `<div class="kv"><span>${esc(a.name)}</span><b>${sizeStr(a.size)}</b></div><div class="bar"><i style="width:${a.size / (al[0].size || 1) * 100}%"></i></div>`).join('') || '<span class="mute">Nothing yet</span>'}</div>
  <h3 style="margin:16px 0 8px">Biggest files</h3><div class="card list">${top.map(x => `<div class="li" data-open="${esc(K(x))}"><div class="cell" style="width:46px;height:46px;border-radius:10px;flex:none"><img src="${thumbUrl(x)}" onload="this.classList.add('ok')"></div><div class="grow"><b style="display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(x.n)}</b><span class="xs mute">${esc(x.b || '')}</span></div><b>${sizeStr(x.s)}</b></div>`).join('')}</div></div>`;
}

/* ---------- menus ---------- */
function topMenu() {
  const items = [
    { i: 'sort', t: 'Sort', s: SORTS[S.sort].replace(' first', ''), fn: sortMenu },
    { i: 'mosaic', t: 'View style', s: 'Grid, feed, stack…', fn: viewMenu },
    { i: 'grid', t: 'Columns', s: CFG.cols + ' across', fn: () => { CFG.cols = CFG.cols >= 6 ? 2 : CFG.cols + 1; saveCfg(); renderMain(); } },
    { i: 'check', t: 'Select', s: 'Pick several', fn: () => startSel() },
    { i: 'show', t: 'Slideshow', s: 'Play photos', fn: () => Show.setup(S.view === 'album' ? S.cur.items : S.media) },
    { i: 'reels', t: 'Reels', s: 'Full screen', fn: () => Reels.open(S.view === 'lib' ? tabItems() : S.cur.items, 0) },
    { i: 'eyeoff', t: 'To vault', s: 'Hide items', fn: () => Sec.needVault(() => { S.pick = true; go('lib'); S.tab = 'all'; startSel(); renderMain(); }) },
    { i: 'palette', t: 'Looks', s: 'Themes & styles', fn: () => go('settings', { jump: 'look' }) },
    { i: 'rotate', t: 'Refresh', s: 'Rescan phone', fn: async () => { await loadMedia(); renderMain(); toast('Library refreshed'); } }
  ];
  sheet('Options', items, '', true);
}
function sortMenu() {
  sheet('Sort by', Object.entries(SORTS).map(([k, v]) => ({ i: k === 'new' || k === 'old' ? 'clock' : k === 'name' ? 'list' : k === 'size' ? 'pie' : 'film', t: v.replace(' first', ''), s: v.includes('first') ? v.split(' ')[0] === 'Newest' ? 'newest' : v.split(' ')[0].toLowerCase() : '', on: S.sort === k, fn: () => { S.sort = k; store.set('np_sort', k); renderMain(); } })), '', true);
}

/* ---------- delegated events ---------- */
let LP = null;
function wire() {
  const main = $('#main');
  main.addEventListener('pointerdown', e => {
    const c = e.target.closest('.cell[data-k]'); if (!c) return;
    LP = { c, x: e.clientX, y: e.clientY, fired: false, moved: false, t: setTimeout(() => { LP.fired = true; hap(25); if (!S.selMode && S.view !== 'albums') startSel(c.dataset.k); }, 430) };
  });
  main.addEventListener('pointermove', e => { if (LP && Math.hypot(e.clientX - LP.x, e.clientY - LP.y) > 10) { clearTimeout(LP.t); LP.moved = true; } });
  main.addEventListener('pointerup', () => {
    if (!LP) return; clearTimeout(LP.t);
    const l = LP; LP = null;
    if (l.fired || l.moved) return;
    const k = l.c.dataset.k;
    if (S.selMode) return toggleSel(k);
    const it = S.map.get(k); if (it) openItem(it);
  });
  main.addEventListener('pointercancel', () => { if (LP) { clearTimeout(LP.t); LP = null; } });
  main.addEventListener('contextmenu', e => e.preventDefault());
  main.addEventListener('click', e => {
    const t = e.target.closest('[data-tab]'); if (t) { S.tab = t.dataset.tab; return renderMain(); }
    const a = e.target.closest('[data-al]'); if (a) return go('album', { name: S._al[+a.dataset.al].name });
    const b = e.target.closest('[data-b="perm"]'); if (b) return nat('askPerm');
    if (e.target.closest('[data-b="views"]')) return viewMenu();
    if (e.target.closest('[data-b="rmstuck"]')) {
      return confirmBox('Remove the originals?', S.stuck.length + ' hidden item(s) are still visible to other apps. They are already safe in your vault. Android may ask you to confirm.', 'Remove', true)
        .then(ok => ok && nat('del', JSON.stringify(S.stuck.map(x => [x.t, +x.i]))));
    }
    const me = e.target.closest('[data-mem]'); if (me) { const g = S._mem[+me.dataset.mem]; S.map = new Map(g.items.map(i => [K(i), i])); S.cur = { items: g.items, ctx: 'lib' }; return openItem(g.items[0], g.items); }
    const cw = e.target.closest('[data-cw]'); if (cw) { const v = S.media.find(x => K(x) === cw.dataset.cw); if (v) nat('play', JSON.stringify({ i: 0, items: [{ s: 'm:' + v.i, t: v.n }] })); return; }
    const dd = e.target.closest('[data-dd]'); if (dd) {
      const g = S._dups[+dd.dataset.dd], extra = g.slice().sort((x, y) => x.d - y.d).slice(1);
      return confirmBox('Delete ' + extra.length + ' extra copies?', 'The oldest copy stays. Android will ask you to confirm.', 'Delete', true).then(ok => ok && nat('del', JSON.stringify(extra.map(x => [x.t, +x.i]))));
    }
    const dk = e.target.closest('[data-dk]'); if (dk) { const it = S.map.get(dk.dataset.dk); if (it) { S.cur = { items: [it], ctx: 'lib' }; openItem(it, [it]); } return; }
    const op = e.target.closest('[data-open]'); if (op) { const it = S.map.get(op.dataset.open); if (it) openItem(it, [it]); return; }
    const r = e.target.closest('[data-act]'); if (r) return rowAct(r.dataset.act, r.dataset.id);
    Settings.click(e);
  });
  $('#bar').addEventListener('click', e => {
    const b = e.target.closest('[data-b]'); if (!b) return;
    ({
      back: () => back(), search: () => { S.search = true; renderBar(); const q = $('#q'); q && q.focus(); }, closesearch: () => { S.search = false; S.q = ''; renderBar(); renderMain(); },
      menu: topMenu, endsel: endSel, vlock: () => Sec.lockNow()
    })[b.dataset.b]();
  });
  $('#bar').addEventListener('input', e => {
    if (e.target.id !== 'q') return;
    S.q = e.target.value;
    if (S.view === 'lib') { const items = tabItems(); mountView($('#gh'), items, { style: CFG.vw[S.tab] || 'grid', empty: emptyHTML('No matches', 'search') }); }
    else renderMain();
    const q = $('#q'); if (q) { q.focus(); }
  });
  $('#nav').addEventListener('click', e => { const b = e.target.closest('button'); if (b) go(b.dataset.v); });
  $('#selbar').addEventListener('click', e => { const b = e.target.closest('[data-sa]'); if (b && !b.disabled) selAction(b.dataset.sa); });
}
function rowAct(a, id) {
  if (a === 'show') return Show.setup(S.media);
  if (a === 'dups' || a === 'storage') return go(a);
  if (a === 'smart') return go('smart', { id });
  if (a === 'settings') return go('settings');
  if (a === 'sec') return go('settings', { jump: 'sec' });
  if (a === 'about') return go('about');
  if (a === 'locknow') { Sec.lockNow(); toast('Locked'); }
}

/* ---------- timeline scrubber (drag to jump through dates) ---------- */
const Scrub = (() => {
  let el = null, drag = false, hideT = 0;
  const geo = () => el.getBoundingClientRect();
  function label(y) {
    const m = $('#main'); let txt = '';
    for (const h of $$('.dh', m)) { if (h.offsetTop <= m.scrollTop + 40) txt = h.firstElementChild.textContent; else break; }
    const bb = $('.bb', el); bb.textContent = txt; bb.style.top = y + 'px';
  }
  function place() {
    const m = $('#main'), max = m.scrollHeight - m.clientHeight, r = geo();
    const y = (max > 0 ? m.scrollTop / max : 0) * Math.max(0, r.height - 44);
    $('.hd', el).style.top = y + 'px'; label(y);
  }
  function jump(e) {
    const m = $('#main'), r = geo();
    const f = Math.max(0, Math.min(1, (e.clientY - r.top - 22) / Math.max(1, r.height - 44)));
    m.scrollTop = f * (m.scrollHeight - m.clientHeight); place();
  }
  function ensure() {
    if (el) return;
    el = document.createElement('div'); el.id = 'scrub'; el.innerHTML = '<div class="bb"></div><div class="hd"></div>';
    document.body.appendChild(el);
    $('#main').addEventListener('scroll', () => {
      if (!el.classList.contains('on')) return;
      place(); el.classList.add('show'); clearTimeout(hideT); hideT = setTimeout(() => { if (!drag) el.classList.remove('show'); }, 1300);
    }, { passive: true });
    el.addEventListener('pointerdown', e => { drag = true; el.setPointerCapture(e.pointerId); el.classList.add('drag', 'show'); if (S.renderAll) S.renderAll(); jump(e); });
    el.addEventListener('pointermove', e => { if (drag) jump(e); });
    const end = () => { drag = false; el.classList.remove('drag'); hideT = setTimeout(() => el.classList.remove('show'), 900); };
    el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
  }
  function refresh(on) { ensure(); el.classList.toggle('on', !!on && S.cur.items.length > 60 && !!CFG.dates); if (!on) el.classList.remove('show'); }
  return { refresh };
})();

/* ---------- events from the Android side ---------- */
window.Np = {
  back() {
    const sb = $$('.sheetbg'); if (sb.length) { sb[sb.length - 1].remove(); return true; }
    if ($('#lock').classList.contains('on')) { return Sec.lockBack(); }
    if (Reels.isOn()) { Reels.close(); return true; }
    if (Show.isOn()) { Show.close(); return true; }
    if (Viewer.isOn()) { Viewer.close(); return true; }
    if (S.search) { S.search = false; S.q = ''; renderBar(); renderMain(); return true; }
    if (S.selMode) { endSel(); return true; }
    if (back()) return true;
    if (S.view !== 'lib') { go('lib'); return true; }
    return false;
  },
  async onPerm(ok) { S.st.perm = ok; if (ok) { await loadMedia(); } renderMain(); },
  onLock() { Sec.onNativeLock(); },
  onShow() {
    try { const keep = S.st.ext; S.st = JSON.parse(nat('state') || '{}'); S.st.ext = keep; } catch (e) { }
    if (!S.st.vault && (S.vault.length || S.vaultOpen)) { S.vault = []; S.vaultOpen = false; if (S.view === 'vault') renderMain(); }
    if (S.view === 'settings') renderMain();
    if (S.st.perm && S.loaded) loadMedia().then(() => { if (S.view === 'lib' && !S.selMode && !S.search) renderMain(); });
  },
  onCopied(json) {
    try { JSON.parse(json).forEach(a => HID.add(a[0] + a[1])); saveHid(); } catch (e) { }
    S.media = S.media.filter(x => !HID.has(K(x)));
    if (S.view === 'lib') renderMain();
  },
  onBio(ok) { Sec.onBio(ok); },
  async onExt() { const s = JSON.parse(nat('state') || '{}'); if (s.ext) Viewer.openExt(s.ext); },
  async onDone(kind, ok, n, msg) {
    const wasPick = S.pick;
    S.sel.clear(); S.selMode = false; S.pick = false; document.body.classList.remove('selmode');
    if (kind === 'delete' || kind === 'hide') {
      if (ok) { toast(kind === 'hide' ? n + ' moved to your private vault' : n + ' deleted'); Viewer.dropPending(); }
      else {
        Viewer.clearPending();
        toast(kind === 'hide' ? (msg === 'cancelled' ? 'Copied to the vault, but the originals were not removed' : (msg || 'Could not hide')) : (msg === 'cancelled' ? 'Delete cancelled' : 'Could not delete'), 4200);
      }
      await loadMedia();
      if (kind === 'hide' && CFG.vlock && S.view !== 'vault') { nat('lockVault'); S.st.vault = false; S.vault = []; }
      if (S.st.vault) await loadVault();
    } else if (kind === 'restore') {
      if (ok) Viewer.dropPending(); else Viewer.clearPending();
      toast(ok ? n + ' restored to your gallery' : 'Nothing restored'); await loadVault(); await loadMedia();
    } else if (kind === 'vdelete') { Viewer.dropPending(); toast(n + ' deleted from the vault'); await loadVault(); }
    else if (kind === 'wipe') { toast('Vault erased'); S.vault = []; }
    renderBar(); renderSel(); renderMain();
  }
};
