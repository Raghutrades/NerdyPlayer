'use strict';
/* ===== NerdyPlayer · the app shell: header, tabs, menu, back button, start-up ===== */

const LOGO = `<svg class="lg" width="26" height="26" viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="13" fill="none" stroke="url(#lgg)" stroke-width="3"/><path d="M13 10.5l9 5.5-9 5.5z" fill="currentColor"/><defs><linearGradient id="lgg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--a1)"/><stop offset="1" stop-color="var(--a2)"/></linearGradient></defs></svg><span>Nerdy<b>Player</b></span>`;

const App = {
  view: 'home', params: {}, stack: [], sub: {}, gv: null, q: '', qk: 'all',
  TABS: [['home', 'Home', 'home'], ['videos', 'Videos', 'film'], ['photos', 'Photos', 'image'], ['albums', 'Albums', 'folder'], ['vault', 'Vault', 'lock']],
  go(view, params = {}) {
    if (SEL.on) selExit();
    const isTab = this.TABS.some(t => t[0] === view);
    if (isTab) this.stack = [];
    else if (!(view === this.view && JSON.stringify(params) === JSON.stringify(this.params))) this.stack.push({ view: this.view, params: this.params, y: $('#main').scrollTop });
    closeDrawer();
    this.view = view; this.params = params;
    this.render(true);
    $('#main').scrollTop = 0;
  },
  back() {
    if (SEL.on) { selExit(); return true; }
    if (this.stack.length) { const s = this.stack.pop(); this.view = s.view; this.params = s.params; this.render(true); $('#main').scrollTop = s.y || 0; return true; }
    if (this.view !== 'home') { this.go('home'); return true; }
    return false;
  },
  render(fresh) {
    const main = $('#main'); const y = main.scrollTop;
    if (SEL.on && SEL.ctx !== 'pick') selExit();
    if (this.gv) { try { this.gv.destroy(); } catch (e) { } this.gv = null; }
    SEL.grid = null; main.classList.remove('flush'); Prev.reset();
    const f = VIEWS[this.view] || VIEWS.home;
    let head = {};
    try { head = f(main, this.params) || {}; } catch (e) { console.error(e); main.innerHTML = `<div class="empty"><h3>Something went wrong</h3><p>${esc(e.message)}</p></div>`; }
    this.head(head); this.navUI();
    if (!fresh) main.scrollTop = y;
    if (Native.call) Native.call('vaultScreen', this.view === 'vault');
  },
  head(h) {
    const top = $('#top');
    const title = h.title || (this.TABS.find(t => t[0] === this.view) || [])[1];
    const isHome = this.view === 'home';
    top.innerHTML = `${h.back ? `<button class="ib" data-act="back" aria-label="Back">${ic('left', 24)}</button>` : `<button class="ib" data-act="menu" aria-label="Menu">${ic('menu', 24)}</button>`}
      ${isHome && !h.back ? `<button class="logo" data-act="go" data-v="home" aria-label="NerdyPlayer home">${LOGO}</button>` : `<h1 class="tt">${esc(title || '')}</h1>`}
      <div class="tright">${(h.actions || []).map(a => `<button class="ib" data-act="${a[1]}" aria-label="${a[1]}">${ic(a[0], 22)}</button>`).join('')}
      ${this.view === 'search' ? '' : `<button class="ib" data-act="go" data-v="search" aria-label="Search">${ic('search', 22)}</button>`}<button class="ib" data-act="top-more" aria-label="More">${ic('more', 22)}</button></div>`;
  },
  navUI() {
    const cur = { album: 'albums', collection: 'albums', smart: 'albums' }[this.view] || this.view;
    $('#nav').innerHTML = this.TABS.map(t => `<button class="${cur === t[0] ? 'on' : ''}" data-act="go" data-v="${t[0]}" aria-label="${t[1]}"><i>${ic(t[2], 22)}</i><span>${t[1]}</span></button>`).join('');
  },
  onLibrary() {
    if (SEL.on || Picker.gv) return;
    if (['home', 'videos', 'photos', 'albums', 'album', 'smart', 'collection', 'storage', 'dups'].includes(this.view)) this.render();
  },
};
ACT['back'] = () => App.back();

ACT['top-more'] = () => {
  const sec = Native.refreshSec();
  menuSheet('NerdyPlayer', [
    ['dl', 'Refresh library', () => { rescan(true); toast('Refreshing…'); }],
    ['plus', 'Open a file…', () => $('#filepick').click()],
    ['gear', 'Settings', () => App.go('settings')],
    sec.pinSet ? ['lock', 'Lock now', () => Native.call('lock')] : null,
    ['info', 'About', () => App.go('about')],
  ]);
};

/* ---------- menu drawer ---------- */
function openDrawer() {
  const sec = Native.refreshSec();
  const item = (i, t, a, v, x) => `<button class="di ${App.view === v ? 'on' : ''}" data-act="${a}" ${v ? `data-v="${v}"` : ''} ${x || ''}>${ic(i, 21)}<span>${t}</span></button>`;
  $('#drawer').innerHTML = `<div class="dhead"><div class="dav"><span>R</span><img src="raghu.jpg" alt="" onerror="this.remove()"></div><div><div class="logo">${LOGO}</div><small>Private · offline · yours</small></div></div>
    <nav class="dlist">
      ${App.TABS.map(t => item(t[2], t[1], 'go', t[0])).join('')}
      <hr>
      ${item('slides', 'Slideshow', 'slideshow-all')}${item('disk', 'Storage insights', 'go', 'storage')}${item('copy', 'Find duplicates', 'go', 'dups')}
      ${Native.info.canTrash ? item('trash', 'Trash', 'go', 'trash') : ''}${item('plus', 'Open a file', 'open-file')}${AB ? item('film', 'Play any file (VLC)', 'play-any') : ''}
      <hr>
      ${item('palette', 'Themes', 'go', 'themes')}${item('gear', 'Settings', 'go', 'settings')}${item('shield', 'Privacy & security', 'go', 'privacy')}${item('info', 'About', 'go', 'about')}
      <hr>
      ${sec.pinSet ? item('lock', 'Lock now', 'lock-now') : ''}${item('x', 'Exit', 'exit')}
    </nav>`;
  $('#drawer').classList.add('on'); $('#scrim').classList.add('on'); $('#drawer').setAttribute('aria-hidden', 'false');
}
function closeDrawer() { $('#drawer').classList.remove('on'); $('#scrim').classList.remove('on'); $('#drawer').setAttribute('aria-hidden', 'true'); }
const drawerOpen = () => $('#drawer').classList.contains('on');
ACT['menu'] = () => drawerOpen() ? closeDrawer() : openDrawer();
ACT['menu-close'] = () => closeDrawer();
ACT['lock-now'] = () => { closeDrawer(); Native.call('lock'); };
ACT['exit'] = () => { if (AB) Native.call('exit'); else toast('Close the tab to exit'); };

/* ---------- opening files from outside the gallery ---------- */
$('#filepick').addEventListener('change', e => {
  const fs = [...e.target.files]; e.target.value = '';
  if (!fs.length) return;
  const items = fs.map(f => {
    const v = f.type.startsWith('video') || /\.(mp4|mkv|webm|3gp|mov|avi|m4v)$/i.test(f.name);
    return { key: 'x' + uid(), id: uid(), k: v ? 'v' : 'i', v, ext: true, url: URL.createObjectURL(f), n: f.name, m: f.type, s: f.size, a: Date.now(), t: f.lastModified || Date.now(), d: 0, w: 0, h: 0, b: 'Opened file', p: '' };
  });
  if (items[0].v) Player.open(items.filter(i => i.v), 0); else Viewer.open(items.filter(i => !i.v), 0);
});
window.nrIncoming = () => {
  const j = Native.call('takePending'); if (!j) return;
  let list = []; try { list = JSON.parse(j).map(extItem); } catch (e) { }
  if (!list.length) return;
  if (list[0].v) Player.open(list.filter(i => i.v), 0); else Viewer.open(list.filter(i => !i.v), 0);
};

/* ---------- back button, pause / resume ---------- */
window.nrBack = () => {
  if (!$('#dialog').hidden) { $('#dialog').click(); return true; }
  if (Sheet.close()) return true;
  if (Lock.visible) return false;
  if (!$('#picker').hidden) { Picker.close(); return true; }
  if (Player.active) { Player.back(); return true; }
  if (Viewer.active) { Viewer.back(); return true; }
  if (drawerOpen()) { closeDrawer(); return true; }
  return App.back();
};
window.nrPause = inPip => { Player.onPause(inPip); Viewer.onPause && Viewer.onPause(); };
window.nrResume = () => {
  Native.refreshSec();
  if (Native.sec.appLock && !Native.sec.appOk && !Lock.visible) Lock.show('app');
  Player.onResume();
  if (AB && LIB.ready) rescan(false);
};
Native.on('locked', () => {
  SESS.unlockedFolders = false;
  Native.refreshSec();
  Vault.onLocked();
  if (Native.sec.appLock) { Player.forceClose(); Viewer.forceClose(); Picker.close(); Sheet.close(); Lock.show('app'); }
  else {
    if (Viewer.active && Viewer.vault) Viewer.forceClose();
    if (Player.active && Player.vault) Player.forceClose();
    if (App.view === 'vault') App.render();
    toast('Locked');
  }
});
Native.on('pip', o => Player.onPip(o.on));

/* ---------- start ---------- */
function boot() {
  applyTheme();
  Splash.run();
  Native.call('appFull', ST.appFull !== false);
  Native.refreshInfo(); Native.refreshSec();
  const go = () => {
    App.go('home');
    if (AB) {
      if (Native.info.perm) rescan(true);
      else if (!Store.get('np-asked', false)) { Store.set('np-asked', true); setTimeout(() => Native.call('askPerm'), 600); }
      window.nrIncoming();
    } else { rebuildLib([]); App.render(); }
  };
  if (AB && Native.sec.appLock && !Native.sec.appOk) { App.render(); Lock.show('app', go); } else go();
}
window.addEventListener('error', e => { try { console.error(e.message); } catch (x) { } });
boot();
ACT['drawer-close'] = () => closeDrawer();

ACT['play-any'] = () => { closeDrawer(); Native.call('pickAny'); };
