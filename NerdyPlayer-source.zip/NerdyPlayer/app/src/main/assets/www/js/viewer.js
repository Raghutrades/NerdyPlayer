'use strict';
/* ===== NerdyPlayer · photo viewer: swipe, pinch-zoom, pan, rotate, flip, adjust, info ===== */
const Viewer = (() => {
  const root = () => $('#viewer');
  let V = null, slides = [], track = null, P = new Map(), g = null, pz = null, lastTap = null, tapT = null, T = null, uiTimer = 0;
  const newT = () => ({ z: 1, x: 0, y: 0, rot: 0, fh: 1, fv: 1, fit: 'fit', f: { b: 100, c: 100, s: 100, g: 0, se: 0, inv: 0, h: 0 } });
  const srcFor = it => it.src || (it.vault ? '/vi/' + it.uid : '/img/' + it.i);
  const W = () => root().clientWidth, H = () => root().clientHeight;
  const cur = () => V && V.list[V.idx];

  function build() {
    root().innerHTML = `<div class="vtop"><button class="ib" data-v="close">${ic('back', 24)}</button><div class="tt"><b id="vtt"></b><span class="xs" style="opacity:.7" id="vtc"></span></div><button class="ib" data-v="fav" id="vfav">${ic('heart', 22)}</button><button class="ib" data-v="info">${ic('info', 22)}</button></div>
    <div class="vtrack" id="vtrack"><div class="vs"><img alt=""></div><div class="vs"><img alt=""></div><div class="vs"><img alt=""></div></div>
    <div class="vbot" id="vbot"></div><div class="vpanel" id="vp"></div>`;
    track = $('#vtrack');
    slides = $$('.vs', track).map(el => ({ el, img: $('img', el), i: -9, nw: 0, nh: 0 }));
    const bot = [];
    const b = (id, i, t, cls = '') => `<button data-v="${id}" class="${cls}">${ic(i, 22)}<span>${t}</span></button>`;
    bot.push(b('rot', 'rotater', 'Rotate'), b('flip', 'flip', 'Flip'), b('adj', 'sliders', 'Adjust'));
    if (V.ctx === 'lib') bot.push(b('show', 'show', 'Slideshow'), b('share', 'share', 'Share'), b('hide', 'eyeoff', 'Hide'), b('del', 'trash', 'Delete', 'dn'));
    if (V.ctx === 'vault') bot.push(b('restore', 'undo', 'Restore'), b('del', 'trash', 'Delete', 'dn'));
    $('#vbot').innerHTML = bot.join('');
    slides.forEach(s => { s.img.onload = () => { s.nw = s.img.naturalWidth; s.nh = s.img.naturalHeight; layout(s); }; });
    $('#vfav').style.display = V.ctx === 'lib' ? '' : 'none';
  }

  function open(list, idx, ctx) {
    if (!list.length || idx < 0) return;
    V = { list: list.slice(), idx, ctx: ctx || 'lib', pend: null };
    T = newT();
    root().classList.add('on'); root().classList.remove('hideui');
    build(); fillAll(); updateTop();
  }
  function openExt(tok) {
    open([{ t: 'i', i: 'ext', n: 'Image', s: 0, d: 0, src: '/ext/' + tok }], 0, 'ext');
  }
  function fillAll() {
    for (let k = 0; k < 3; k++) setSlide(slides[k], V.idx + k - 1);
  }
  function setSlide(s, i) {
    s.i = i;
    const it = V.list[i];
    s.nw = s.nh = 0;
    if (!it) { s.img.removeAttribute('src'); s.img.style.display = 'none'; return; }
    s.img.style.display = '';
    s.img.style.transform = '';
    s.img.src = srcFor(it);
  }
  /* position an image slide */
  function layout(s) {
    if (!s.nw) return;
    const isCur = s === slides[1];
    const t = isCur ? T : newT();
    const w = W(), h = H(), r = t.rot * Math.PI / 180, c = Math.abs(Math.cos(r)), n = Math.abs(Math.sin(r));
    const bw = s.nw * c + s.nh * n, bh = s.nw * n + s.nh * c;
    s.fs = t.fit === 'orig' ? 1 / (window.devicePixelRatio || 1) : t.fit === 'fill' ? Math.max(w / bw, h / bh) : Math.min(w / bw, h / bh);
    s.bw = bw; s.bh = bh;
    const im = s.img;
    im.style.width = s.nw + 'px'; im.style.height = s.nh + 'px';
    im.style.marginLeft = (-s.nw / 2) + 'px'; im.style.marginTop = (-s.nh / 2) + 'px';
    im.style.transform = `translate(${t.x}px,${t.y}px) scale(${s.fs * t.z}) rotate(${t.rot}deg) scale(${t.fh},${t.fv})`;
    const f = t.f;
    im.style.filter = (f.b === 100 && f.c === 100 && f.s === 100 && !f.g && !f.se && !f.inv && !f.h) ? '' : `brightness(${f.b}%) contrast(${f.c}%) saturate(${f.s}%) grayscale(${f.g}%) sepia(${f.se}%) invert(${f.inv}%) hue-rotate(${f.h}deg)`;
  }
  const curSlide = () => slides[1];
  const apply = () => layout(curSlide());
  function limits() {
    const s = curSlide(); if (!s.nw) return { x: 0, y: 0 };
    return { x: Math.max(0, (s.bw * s.fs * T.z - W()) / 2), y: Math.max(0, (s.bh * s.fs * T.z - H()) / 2) };
  }
  function clamp() { const l = limits(); T.x = Math.max(-l.x, Math.min(l.x, T.x)); T.y = Math.max(-l.y, Math.min(l.y, T.y)); }
  function animateTo(fn) {
    const im = curSlide().img; im.style.transition = 'transform .22s ease'; fn(); apply();
    setTimeout(() => { im.style.transition = ''; }, 240);
  }
  const zoomed = () => T.z > 1.03;

  function updateTop() {
    const it = cur(); if (!it) return;
    $('#vtt').textContent = it.n;
    $('#vtc').textContent = (V.idx + 1) + ' / ' + V.list.length;
    const fv = $('#vfav'); if (fv) { const on = S.fav.has(K(it)); fv.innerHTML = ic(on ? 'heartfill' : 'heart', 22); fv.style.color = on ? '#ff5a7a' : ''; }
  }

  /* ----- gestures ----- */
  const rel = e => { const b = root().getBoundingClientRect(); return { x: e.clientX - b.left - b.width / 2, y: e.clientY - b.top - b.height / 2 }; };
  function down(e) {
    if (e.target.closest('.vtop,.vbot,.vpanel')) return;
    root().setPointerCapture && root().setPointerCapture(e.pointerId);
    P.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (P.size === 1) {
      g = { x0: e.clientX, y0: e.clientY, tx0: T.x, ty0: T.y, t0: Date.now(), mode: null, dx: 0, dy: 0 };
      track.style.transition = '';
    } else if (P.size === 2) {
      const [a, b] = [...P.values()];
      const m = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      const bb = root().getBoundingClientRect();
      pz = { d0: Math.hypot(a.x - b.x, a.y - b.y) || 1, z0: T.z, a0: Math.atan2(b.y - a.y, b.x - a.x), r0: T.rot, mx: m.x - bb.left - bb.width / 2, my: m.y - bb.top - bb.height / 2, tx0: T.x, ty0: T.y };
      if (g) g.mode = 'pinch';
      clearTimeout(tapT);
    }
  }
  function move(e) {
    if (!P.has(e.pointerId)) return;
    P.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (!g) return;
    if (g.mode === 'pinch' && P.size >= 2) {
      const [a, b] = [...P.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      const bb = root().getBoundingClientRect();
      const mx = (a.x + b.x) / 2 - bb.left - bb.width / 2, my = (a.y + b.y) / 2 - bb.top - bb.height / 2;
      const z = Math.max(0.4, Math.min(14, pz.z0 * d / pz.d0)), k = z / pz.z0;
      T.z = z;
      T.x = mx - (pz.mx - pz.tx0) * k; T.y = my - (pz.my - pz.ty0) * k;
      if (CFG.twist) T.rot = pz.r0 + (Math.atan2(b.y - a.y, b.x - a.x) - pz.a0) * 180 / Math.PI;
      apply(); return;
    }
    if (P.size !== 1) return;
    g.dx = e.clientX - g.x0; g.dy = e.clientY - g.y0;
    if (!g.mode && Math.hypot(g.dx, g.dy) > 9) {
      clearTimeout(tapT);
      g.mode = zoomed() ? 'pan' : (Math.abs(g.dx) > Math.abs(g.dy) ? 'swipe' : 'drag');
    }
    if (g.mode === 'pan') {
      const l = limits(); let nx = g.tx0 + g.dx, ny = g.ty0 + g.dy;
      /* swipe to the next photo when already at the edge */
      if (nx > l.x + 60 || nx < -l.x - 60) { if (Math.abs(g.dx) > Math.abs(g.dy)) { /* allow pager only when not much vertical */ } }
      T.x = Math.max(-l.x - 40, Math.min(l.x + 40, nx)); T.y = Math.max(-l.y - 40, Math.min(l.y + 40, ny)); apply();
    } else if (g.mode === 'swipe') {
      let dx = g.dx;
      if ((V.idx === 0 && dx > 0) || (V.idx === V.list.length - 1 && dx < 0)) dx *= 0.3;
      track.style.transform = `translateX(${dx}px)`;
    } else if (g.mode === 'drag') {
      track.style.transform = `translateY(${g.dy}px) scale(${1 - Math.min(Math.abs(g.dy), 300) / 1500})`;
      root().style.background = `rgba(0,0,0,${1 - Math.min(Math.abs(g.dy), 300) / 450})`;
    }
  }
  function up(e) {
    if (!P.has(e.pointerId)) return;
    P.delete(e.pointerId);
    if (!g) return;
    if (g.mode === 'pinch') {
      if (P.size === 0) {
        if (T.z < 1) animateTo(() => { T.z = 1; T.x = T.y = 0; });
        else { animateTo(clamp); }
        g = null;
      } else {
        const p = [...P.values()][0]; g = { x0: p.x, y0: p.y, tx0: T.x, ty0: T.y, t0: Date.now(), mode: 'pan-after', dx: 0, dy: 0 };
        g.mode = zoomed() ? 'pan' : 'none';
      }
      return;
    }
    if (P.size > 0) return;
    const gg = g; g = null;
    const dt = Date.now() - gg.t0;
    if (!gg.mode) {
      const now = Date.now();
      if (lastTap && now - lastTap.t < 300 && Math.hypot(e.clientX - lastTap.x, e.clientY - lastTap.y) < 40) {
        clearTimeout(tapT); lastTap = null; doubleTap(e); return;
      }
      lastTap = { t: now, x: e.clientX, y: e.clientY };
      tapT = setTimeout(() => { root().classList.toggle('hideui'); lastTap = null; }, 280);
      return;
    }
    if (gg.mode === 'pan') { animateTo(clamp); return; }
    if (gg.mode === 'swipe') {
      const w = W(), v = gg.dx / Math.max(dt, 1);
      if ((gg.dx < -w * 0.2 || v < -0.55) && V.idx < V.list.length - 1) return slide(1);
      if ((gg.dx > w * 0.2 || v > 0.55) && V.idx > 0) return slide(-1);
      track.style.transition = 'transform .2s ease'; track.style.transform = '';
      return;
    }
    if (gg.mode === 'drag') {
      if (gg.dy > 110) { close(true); return; }
      if (gg.dy < -90) { track.style.transition = 'transform .2s ease'; track.style.transform = ''; root().style.background = ''; panel('info'); return; }
      track.style.transition = 'transform .2s ease'; track.style.transform = ''; root().style.background = '';
    }
  }
  function doubleTap(e) {
    const p = rel(e);
    if (zoomed()) animateTo(() => { T.z = 1; T.x = T.y = 0; });
    else {
      const z = 2.6, k = z / T.z;
      animateTo(() => { T.x = p.x - (p.x - T.x) * k; T.y = p.y - (p.y - T.y) * k; T.z = z; clamp(); });
    }
  }
  function slide(dir) {
    if (dir > 0 && V.idx >= V.list.length - 1) return;
    if (dir < 0 && V.idx <= 0) return;
    track.style.transition = 'transform .22s ease';
    track.style.transform = `translateX(${-dir * W()}px)`;
    setTimeout(() => {
      track.style.transition = 'none'; track.style.transform = '';
      V.idx += dir; T = newT();
      if (dir > 0) { slides.push(slides.shift()); track.appendChild(slides[2].el); setSlide(slides[2], V.idx + 1); }
      else { slides.unshift(slides.pop()); track.insertBefore(slides[0].el, track.firstChild); setSlide(slides[0], V.idx - 1); }
      layout(slides[1]);
      updateTop(); closePanel();
    }, 230);
  }
  function rebuild() { T = newT(); fillAll(); updateTop(); }

  /* ----- panels ----- */
  const PRESETS = { None: [100, 100, 100, 0, 0, 0, 0], 'B&W': [100, 110, 0, 100, 0, 0, 0], Sepia: [100, 100, 100, 0, 80, 0, 0], Vivid: [105, 115, 150, 0, 0, 0, 0], Cool: [100, 100, 110, 0, 0, 0, -18], Warm: [104, 100, 115, 0, 25, 0, 0], Fade: [112, 80, 80, 0, 10, 0, 0], Invert: [100, 100, 100, 0, 0, 100, 0] };
  function panel(kind) {
    const p = $('#vp'), it = cur(); if (!it) return;
    if (p.classList.contains('on') && p.dataset.k === kind) return closePanel();
    p.dataset.k = kind; p.classList.add('on');
    if (kind === 'info') {
      const kv = (a, b) => `<div class="kv"><span style="color:#9aa1bd">${a}</span><b style="text-align:right;max-width:65%;word-break:break-all">${esc(b)}</b></div>`;
      p.innerHTML = `<h3 style="margin:0 0 6px">Details</h3>${kv('Name', it.n)}${it.w ? kv('Size', it.w + ' × ' + it.h + ' px · ' + ((it.w * it.h) / 1e6).toFixed(1) + ' MP') : ''}${it.s ? kv('File size', sizeStr(it.s)) : ''}${it.d ? kv('Date', fullDate(it.d)) : ''}${it.m ? kv('Type', it.m) : ''}${it.b ? kv('Album', it.b) : ''}${it.p ? kv('Path', it.p) : ''}${it.vault ? kv('Stored', 'Encrypted in the vault') : ''}`;
    } else {
      const f = T.f;
      const sl = (id, label, min, max, v, unit = '') => `<label><span>${label}</span><span id="${id}v">${v}${unit}</span></label><input type="range" data-s="${id}" min="${min}" max="${max}" value="${v}">`;
      p.innerHTML = `<h3 style="margin:0 0 4px">Adjust</h3>
      <div class="seg" style="margin:6px 0 4px">${Object.keys(PRESETS).map(n => `<button data-pre="${n}">${n}</button>`).join('')}</div>
      ${sl('b', 'Brightness', 40, 180, f.b, '%')}${sl('c', 'Contrast', 40, 180, f.c, '%')}${sl('s', 'Saturation', 0, 220, f.s, '%')}${sl('h', 'Tint', -90, 90, f.h, '°')}${sl('r', 'Straighten / rotate', -180, 180, Math.round(T.rot), '°')}
      <div class="seg" style="margin-top:12px"><button data-pa="l90">${ic('rotate', 15)} −90°</button><button data-pa="r90">${ic('rotater', 15)} +90°</button><button data-pa="fh">${ic('flip', 15)} Flip ↔</button><button data-pa="fv">${ic('flipv', 15)} Flip ↕</button></div>
      <div class="seg" style="margin-top:10px">${[['fit', 'Fit'], ['fill', 'Fill'], ['orig', '1 : 1']].map(a => `<button data-fit="${a[0]}" class="${T.fit === a[0] ? 'on' : ''}">${a[1]}</button>`).join('')}<button data-pa="reset">Reset all</button></div>`;
    }
  }
  function closePanel() { const p = $('#vp'); if (p) { p.classList.remove('on'); p.dataset.k = ''; } }

  function panelEvents(e) {
    const s = e.target.closest('[data-s]');
    if (s && e.type === 'input') {
      const v = +s.value, id = s.dataset.s;
      if (id === 'r') { T.rot = v; } else T.f[id] = v;
      const lab = $('#' + id + 'v'); if (lab) lab.textContent = v + (id === 'h' || id === 'r' ? '°' : '%');
      if (id === 'r') { T.x = T.y = 0; }
      return apply();
    }
    if (e.type !== 'click') return;
    const pre = e.target.closest('[data-pre]');
    if (pre) { const v = PRESETS[pre.dataset.pre]; T.f = { b: v[0], c: v[1], s: v[2], g: v[3], se: v[4], inv: v[5], h: v[6] }; apply(); $('#vp').dataset.k = ''; return panel('adj'); }
    const f = e.target.closest('[data-fit]');
    if (f) { T.fit = f.dataset.fit; T.z = 1; T.x = T.y = 0; apply(); $('#vp').dataset.k = ''; return panel('adj'); }
    const a = e.target.closest('[data-pa]');
    if (a) {
      const k = a.dataset.pa;
      if (k === 'l90') rot(-90); else if (k === 'r90') rot(90);
      else if (k === 'fh') { T.fh *= -1; apply(); } else if (k === 'fv') { T.fv *= -1; apply(); }
      else if (k === 'reset') { T = newT(); apply(); }
      $('#vp').dataset.k = ''; panel('adj');
    }
  }
  function rot(d) { T.rot = Math.round((T.rot + d) / 90) * 90; T.x = T.y = 0; T.z = 1; animateTo(() => { }); }

  /* ----- actions ----- */
  async function act(a) {
    const it = cur(); if (!it) return;
    if (a === 'close') return close();
    if (a === 'fav') { toggleFav(K(it)); return updateTop(); }
    if (a === 'info') return panel('info');
    if (a === 'adj') return panel('adj');
    if (a === 'rot') return rot(90);
    if (a === 'flip') { T.fh *= -1; return animateTo(() => { }); }
    if (a === 'share') return nat('share', it.t, +it.i);
    if (a === 'show') { const list = V.list.slice(), i = V.idx; return Show.setup(list, i); }
    if (a === 'del') {
      const vault = V.ctx === 'vault';
      const ok = await confirmBox(vault ? 'Delete forever?' : 'Delete this photo?', vault ? 'It will be erased from the vault.' : 'Android will ask you to confirm.', 'Delete', true);
      if (!ok) return;
      V.pend = [it];
      if (vault) nat('vdelete', JSON.stringify([it.uid])); else nat('del', JSON.stringify([[it.t, +it.i]]));
    }
    if (a === 'hide') Sec.needVault(async () => {
      const ok = await confirmBox('Move to private vault?', 'It will be encrypted and hidden from the gallery.', 'Hide');
      if (!ok) return;
      V.pend = [it]; toast('Encrypting…', 5000); nat('hide', JSON.stringify([[it.t, +it.i]]));
    });
    if (a === 'restore') { V.pend = [it]; nat('restore', JSON.stringify([it.uid])); toast('Restoring…', 4000); }
  }
  function dropPending() {
    if (!V || !V.pend) return;
    const gone = new Set(V.pend.map(K)); V.pend = null;
    V.list = V.list.filter(x => !gone.has(K(x)));
    if (!V.list.length) return close(true);
    V.idx = Math.min(V.idx, V.list.length - 1);
    rebuild();
  }
  const clearPending = () => { if (V) V.pend = null; };

  function close(force) {
    if (!V) return;
    const p = $('#vp');
    if (!force && p && p.classList.contains('on')) { closePanel(); return; }
    const list = V.list; V = null; P.clear(); g = null;
    root().classList.remove('on'); root().style.background = ''; root().innerHTML = '';
    list.forEach(it => { const c = $(`.cell[data-k="${K(it)}"]`); if (c) { const has = c.querySelector('.fv'); const on = S.fav.has(K(it)); if (on && !has) c.insertAdjacentHTML('beforeend', `<span class="fv">${ic('heartfill', 15)}</span>`); if (!on && has) has.remove(); } });
  }

  /* wire once */
  document.addEventListener('DOMContentLoaded', () => {
    const r = root();
    r.addEventListener('pointerdown', down); r.addEventListener('pointermove', move);
    r.addEventListener('pointerup', up); r.addEventListener('pointercancel', up);
    r.addEventListener('click', e => { const b = e.target.closest('[data-v]'); if (b) act(b.dataset.v); else panelEvents(e); });
    r.addEventListener('input', panelEvents);
    window.addEventListener('resize', () => { if (V) { slides.forEach(layout); } });
  });
  return { open, openExt, close, isOn: () => !!V, ctx: () => V && V.ctx, dropPending, clearPending };
})();
