'use strict';
/* ===== NerdyPlayer · photo viewer: swipe, zoom, pan, rotate, flip, edit, crop, slideshow ===== */

const ADJ0 = { b: 100, c: 100, s: 100, h: 0, bl: 0, g: 0, se: 0, inv: 0 };
const PRESETS = {
  Normal: {}, Vivid: { c: 112, s: 150 }, Mono: { g: 100, c: 108 }, Noir: { g: 100, c: 140, b: 88 }, Warm: { se: 30, s: 115, h: -8 },
  Cool: { h: 14, s: 108, b: 102 }, Vintage: { se: 55, c: 92, b: 106, s: 85 }, Fade: { c: 82, b: 112, s: 88 }, Dramatic: { c: 150, s: 120, b: 92 }, Invert: { inv: 100 },
};
const filterCSS = a => {
  const x = Object.assign({}, ADJ0, a || {});
  const parts = [];
  if (x.b !== 100) parts.push(`brightness(${x.b}%)`); if (x.c !== 100) parts.push(`contrast(${x.c}%)`); if (x.s !== 100) parts.push(`saturate(${x.s}%)`);
  if (x.h) parts.push(`hue-rotate(${x.h}deg)`); if (x.bl) parts.push(`blur(${x.bl}px)`); if (x.g) parts.push(`grayscale(${x.g}%)`);
  if (x.se) parts.push(`sepia(${x.se}%)`); if (x.inv) parts.push(`invert(${x.inv}%)`);
  return parts.join(' ') || 'none';
};

/* ---------- a small EXIF reader (JPEG) ---------- */
async function readExif(it) {
  try {
    if (it.ext && it.url.startsWith('blob:')) { /* fine */ }
    if (!/jpe?g/i.test(it.m) && !/\.jpe?g$/i.test(it.n)) return null;
    const r = await fetch(Src.url(it), { headers: { Range: 'bytes=0-262143' } });
    const buf = await r.arrayBuffer();
    return parseExif(new DataView(buf));
  } catch (e) { return null; }
}
function parseExif(dv) {
  if (dv.byteLength < 12 || dv.getUint16(0) !== 0xFFD8) return null;
  let p = 2;
  while (p + 4 < dv.byteLength) {
    const mk = dv.getUint16(p), len = dv.getUint16(p + 2);
    if (mk === 0xFFE1 && dv.getUint32(p + 4) === 0x45786966) return readTiff(dv, p + 10);
    if ((mk & 0xFF00) !== 0xFF00 || mk === 0xFFDA) break;
    p += 2 + len;
  }
  return null;
}
function readTiff(dv, t) {
  const le = dv.getUint16(t) === 0x4949;
  const u16 = o => dv.getUint16(o, le), u32 = o => dv.getUint32(o, le);
  const sz = { 1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 7: 1, 9: 4, 10: 8 };
  const val = (e, base) => {
    const type = u16(e + 2), n = u32(e + 4), s = (sz[type] || 1) * n; const o = s > 4 ? t + u32(e + 8) : e + 8;
    if (o + s > dv.byteLength) return null;
    if (type === 2) { let r = ''; for (let i = 0; i < n - 1; i++) r += String.fromCharCode(dv.getUint8(o + i)); return r.trim(); }
    if (type === 3) return n === 1 ? u16(o) : Array.from({ length: n }, (_, i) => u16(o + i * 2));
    if (type === 4) return n === 1 ? u32(o) : Array.from({ length: n }, (_, i) => u32(o + i * 4));
    if (type === 5) { const a = Array.from({ length: n }, (_, i) => { const d = u32(o + i * 8 + 4); return d ? u32(o + i * 8) / d : 0; }); return n === 1 ? a[0] : a; }
    return null;
  };
  const ifd = off => { const out = {}; try { const c = u16(t + off); for (let i = 0; i < c; i++) { const e = t + off + 2 + i * 12; out[u16(e)] = { v: val(e), raw: e }; } } catch (e) { } return out; };
  const a = ifd(u32(t + 4));
  const res = {};
  const g = (o, k) => o[k] ? o[k].v : null;
  res.make = g(a, 0x10F); res.model = g(a, 0x110); res.orient = g(a, 0x112); res.soft = g(a, 0x131);
  if (a[0x8769]) {
    const x = ifd(a[0x8769].v);
    res.date = g(x, 0x9003); res.exp = g(x, 0x829A); res.f = g(x, 0x829D); res.iso = g(x, 0x8827); res.focal = g(x, 0x920A); res.lens = g(x, 0xA434);
    res.flash = g(x, 0x9209); res.w = g(x, 0xA002); res.h = g(x, 0xA003);
  }
  if (a[0x8825]) {
    const gp = ifd(a[0x8825].v);
    const lat = g(gp, 2), lon = g(gp, 4), lr = g(gp, 1), nr = g(gp, 3);
    if (Array.isArray(lat) && Array.isArray(lon)) {
      res.lat = (lat[0] + lat[1] / 60 + lat[2] / 3600) * (lr === 'S' ? -1 : 1);
      res.lon = (lon[0] + lon[1] / 60 + lon[2] / 3600) * (nr === 'W' ? -1 : 1);
    }
    res.alt = g(gp, 6);
  }
  return res;
}

/* ---------- the viewer ---------- */
const Viewer = {
  active: false, built: false, items: [], i: 0, vault: false, ui: true,
  z: 1, x: 0, y: 0, edits: {}, vw: 0, vh: 0, L: [], tool: null,
  ss: { on: false, timer: null, paused: false, ctl: false },

  build() {
    if (this.built) return;
    const v = $('#viewer');
    v.innerHTML = `<div class="vbg"></div><div class="vstage" id="vstage"><div class="vtrack" id="vtrack"></div></div>
      <header class="vtop" id="vtop"></header>
      <div class="vcap" id="vcap"></div>
      <footer class="vbot" id="vbot"></footer>
      <div class="ssprog" id="ssprog"><i></i></div>
      <div class="ssctl" id="ssctl" hidden></div>
      <div class="vtools" id="vtools" hidden></div>
      <div class="vcrop" id="vcrop" hidden><div class="cbox" id="cbox"><i class="h tl"></i><i class="h tr"></i><i class="h bl"></i><i class="h br"></i><i class="g1"></i><i class="g2"></i></div></div>`;
    this.stage = $('#vstage'); this.track = $('#vtrack');
    this.L = [0, 1, 2].map(() => {
      const d = document.createElement('div'); d.className = 'vl';
      d.innerHTML = `<img class="vph" alt="" draggable="false"><div class="vin"><img class="vimg" alt="" draggable="false"></div><button class="vplay" hidden aria-label="Play video">${icFill('play', 34)}</button><div class="vmiss" hidden>${ic('image', 40)}<p>Can't show this picture</p></div>`;
      this.track.appendChild(d);
      const l = { el: d, ph: d.children[0], in: d.children[1], img: d.children[1].firstElementChild, play: d.children[2], miss: d.children[3], it: null };
      l.img.onload = () => { l.ready = true; l.ph.style.opacity = 0; this.place(l); if (l === this.L[1]) this.afterLoad(); };
      l.img.onerror = () => { if (l.it) { l.miss.hidden = false; } if (l === this.L[1]) this.afterLoad(); };
      l.play.onclick = () => { const it = l.it; if (!it) return; const vids = this.items.filter(x => x.v); Player.open(vids, Math.max(0, vids.indexOf(it)), { vault: this.vault }); };
      return l;
    });
    this.bindGestures();
    window.addEventListener('resize', () => { if (this.active) this.measure(true); });
    document.addEventListener('keydown', e => {
      if (!this.active || Player.active) return;
      const k = e.key;
      if (k === 'ArrowRight') this.step(1); else if (k === 'ArrowLeft') this.step(-1); else if (k === 'Escape') this.back();
      else if (k === '+' || k === '=') this.zoomTo(this.z * 1.3); else if (k === '-') this.zoomTo(this.z / 1.3); else if (k === 'r') this.rotate(90);
      else if (k === ' ') { e.preventDefault(); this.ss.on ? this.ssToggle() : this.ssStart(); }
    });
    this.built = true;
  },

  open(items, index, o = {}) {
    this.build();
    if (!items.length) return;
    this.items = items; this.i = clamp(index, 0, items.length - 1); this.vault = !!o.vault; this.edits = {};
    this.active = true; this.ui = true;
    $('#viewer').hidden = false; requestAnimationFrame(() => $('#viewer').classList.add('on'));
    Dev.bars('#000000', false);
    this.measure(); this.resetZoom(true); this.fillAll(); this.chrome();
    if (o.slideshow) setTimeout(() => this.ssStart(), 300);
  },
  close() {
    if (!this.active) return;
    this.ssStop(true); this.closeTool();
    this.active = false;
    const v = $('#viewer'); v.classList.remove('on');
    setTimeout(() => { if (!this.active) { v.hidden = true; this.L.forEach(l => { l.img.removeAttribute('src'); l.ph.removeAttribute('src'); l.it = null; }); } }, 220);
    Dev.fullscreen(false); applyTheme();
  },
  back() {
    if (this.cropOn) return this.cropCancel();
    if (this.tool) return this.closeTool();
    if (this.ss.on) return this.ssStop();
    this.close();
  },
  forceClose() { if (this.active) { this.ssStop(true); this.close(); } },
  onPause() { if (this.ss.on && !this.ss.paused) this.ssToggle(); },
  afterDelete(gone) {
    const cur = this.items[this.i];
    this.items = this.items.filter(x => !gone.has(x.key));
    if (!this.items.length) return this.close();
    this.i = Math.min(this.i, this.items.length - 1);
    this.resetZoom(true); this.fillAll(); this.chrome();
  },
  get cur() { return this.items[this.i]; },
  E(it) { return this.edits[it.key] || (this.edits[it.key] = { rot: 0, fx: 1, fy: 1, adj: {} }); },

  measure(redo) {
    this.vw = this.stage.clientWidth || innerWidth; this.vh = this.stage.clientHeight || innerHeight;
    if (redo) { this.L.forEach(l => this.place(l)); }
  },

  /* ----- content ----- */
  fillAll() {
    const [p, c, n] = this.L;
    this.fill(p, this.i - 1); this.fill(c, this.i); this.fill(n, this.i + 1);
    this.pos();
  },
  fill(l, idx) {
    const it = this.items[idx] || null;
    l.it = it; l.ready = false; l.miss.hidden = true; l.el.style.opacity = ''; l.el.classList.remove('kb');
    if (!it) { l.img.removeAttribute('src'); l.ph.removeAttribute('src'); l.play.hidden = true; l.ph.style.opacity = 0; return; }
    const th = Src.thumb(it, 600);
    if (th) { l.ph.src = th; l.ph.style.opacity = 1; } else { l.ph.removeAttribute('src'); l.ph.style.opacity = 0; }
    l.play.hidden = !it.v;
    if (it.v) {            // videos show their poster; play opens the player
      l.img.removeAttribute('src'); l.in.style.visibility = 'hidden';
      l.ph.className = 'vph poster'; return;
    }
    l.ph.className = 'vph'; l.in.style.visibility = '';
    l.img.src = Src.url(it);
  },
  pos() { // the three layers sit side by side
    this.L.forEach((l, k) => { l.el.style.left = ((k - 1) * 100) + '%'; });
    this.track.style.transition = 'none'; this.track.style.transform = 'translateX(0)';
  },
  fitScale(nw, nh, rot) {
    const r = rot * Math.PI / 180, c = Math.abs(Math.cos(r)), s = Math.abs(Math.sin(r));
    const bw = nw * c + nh * s, bh = nw * s + nh * c;
    return { fit: Math.min(this.vw / bw, this.vh / bh), bw, bh };
  },
  place(l, mine) {
    const it = l.it; if (!it) return;
    const e = this.E(it), img = l.img;
    const nw = img.naturalWidth || it.w || 1000, nh = img.naturalHeight || it.h || 1000;
    if (it.v) { l.in.style.visibility = 'hidden'; this.placePh(l, e); return; }
    img.style.width = nw + 'px'; img.style.height = nh + 'px'; img.style.marginLeft = -nw / 2 + 'px'; img.style.marginTop = -nh / 2 + 'px';
    const { fit } = this.fitScale(nw, nh, e.rot);
    const cur = l === this.L[1];
    const t = `translate(${cur ? this.x : 0}px,${cur ? this.y : 0}px) scale(${fit * (cur ? this.z : 1)}) rotate(${e.rot}deg) scale(${e.fx},${e.fy})`;
    img.style.transform = t; img.style.filter = filterCSS(e.adj);
    this.placePh(l, e, nw, nh, fit, cur, t);
  },
  placePh(l, e, nw, nh, fit, cur, t) {
    const ph = l.ph, it = l.it;
    if (!it) return;
    if (it.v || !l.ready) { // poster / blurred preview sized to the real picture
      const w = it.w || nw || 800, h = it.h || nh || 600;
      const f = this.fitScale(w, h, it.v ? 0 : e.rot).fit;
      ph.style.cssText += `;width:${w}px;height:${h}px;margin-left:${-w / 2}px;margin-top:${-h / 2}px;transform:translate(${cur ? this.x : 0}px,${cur ? this.y : 0}px) scale(${f * (cur ? this.z : 1)}) rotate(${it.v ? 0 : e.rot}deg) scale(${it.v ? 1 : e.fx},${it.v ? 1 : e.fy})`;
    }
  },
  placeCur() { this.place(this.L[1]); },
  afterLoad() {
    const it = this.cur;
    if (this.ss.on && !this.ss.paused && it && !it.v) this.ssArm();
  },

  /* ----- navigation ----- */
  step(d, mode) {
    const n = this.i + d;
    if (n < 0 || n >= this.items.length) {
      if (this.ss.on && ST.ssLoop && this.items.length > 1) return this.jump(d > 0 ? 0 : this.items.length - 1, mode || 'fade');
      return;
    }
    this.swap(d, mode || 'slide');
  },
  async swap(dir, mode) {
    if (this.busy) return; this.busy = true;
    this.cropOn && this.cropCancel();
    const [lp, lc, ln] = this.L, target = dir > 0 ? ln : lp;
    const dur = mode === 'slide' ? 280 : mode === 'none' ? 0 : 650;
    if (mode === 'slide') {
      this.track.style.transition = `transform ${dur}ms cubic-bezier(.2,.8,.2,1)`; this.track.style.transform = `translateX(${-dir * this.vw}px)`;
    } else if (mode === 'fade' || mode === 'zoom') {
      target.el.style.transition = 'none'; target.el.style.left = '0%'; target.el.style.zIndex = 3; target.el.style.opacity = 0;
      if (mode === 'zoom') target.el.style.transform = 'scale(1.18)';
      void target.el.offsetWidth;
      target.el.style.transition = `opacity ${dur}ms ease, transform ${dur}ms ease`; target.el.style.opacity = 1; target.el.style.transform = 'scale(1)';
    }
    if (dur) await sleep(dur + 20);
    // commit: the target becomes the middle layer
    this.i += dir;
    if (dir > 0) this.L = [lc, ln, lp]; else this.L = [ln, lp, lc];
    this.L.forEach(l => { l.el.style.transition = 'none'; l.el.style.zIndex = ''; l.el.style.transform = ''; l.el.style.opacity = ''; });
    const [p, c, n] = this.L;
    if (dir > 0) this.fill(n, this.i + 1); else this.fill(p, this.i - 1);
    this.pos(); this.z = 1; this.x = 0; this.y = 0;
    this.L.forEach(l => this.place(l));
    if (this.ss.on && ST.ssKB && !c.it.v) { c.in.classList.remove('kbi'); void c.in.offsetWidth; c.in.classList.add('kbi'); }
    this.busy = false; this.chrome();
    if (c.ready) this.afterLoad();
  },
  jump(idx, mode = 'none') {
    idx = clamp(idx, 0, this.items.length - 1); if (idx === this.i) return;
    this.i = idx; this.resetZoom(true); this.fillAll(); this.chrome();
  },

  /* ----- zoom ----- */
  resetZoom(now) { this.z = 1; this.x = 0; this.y = 0; if (!now) this.animate(); this.placeCur(); },
  animate() { const im = this.L[1].img; im.style.transition = 'transform .22s ease'; setTimeout(() => im.style.transition = '', 240); },
  clampPan() {
    const l = this.L[1]; if (!l.it) return;
    const e = this.E(l.it), im = l.img;
    const { fit, bw, bh } = this.fitScale(im.naturalWidth || l.it.w || 1000, im.naturalHeight || l.it.h || 1000, e.rot);
    const mx = Math.max(0, (bw * fit * this.z - this.vw) / 2), my = Math.max(0, (bh * fit * this.z - this.vh) / 2);
    this.x = clamp(this.x, -mx, mx); this.y = clamp(this.y, -my, my);
  },
  zoomTo(nz, px, py, anim) {
    nz = clamp(nz, 1, 10);
    const cx = this.vw / 2, cy = this.vh / 2; if (px == null) { px = cx; py = cy; }
    const k = nz / this.z;
    this.x = px - cx - (px - cx - this.x) * k; this.y = py - cy - (py - cy - this.y) * k; this.z = nz;
    if (nz === 1) { this.x = 0; this.y = 0; }
    this.clampPan(); if (anim !== false) this.animate(); this.placeCur(); this.chrome(true);
  },

  /* ----- gestures ----- */
  bindGestures() {
    const st = this.stage, P = new Map(); let g = null, lastTap = { t: 0, x: 0, y: 0 }, tapTimer = null;
    const mid = () => { const a = [...P.values()]; return { x: (a[0].x + a[1].x) / 2, y: (a[0].y + a[1].y) / 2, d: Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y) }; };
    st.addEventListener('pointerdown', e => {
      if (this.cropOn || this.busy) return;
      try { st.setPointerCapture(e.pointerId); } catch (x) { }
      P.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (P.size === 1) g = { mode: null, sx: e.clientX, sy: e.clientY, t: Date.now(), x0: this.x, y0: this.y, moved: false, vx: 0, lx: e.clientX, lt: Date.now() };
      else if (P.size === 2) { const m = mid(); g = { mode: 'pinch', d0: m.d || 1, z0: this.z, c0x: m.x, c0y: m.y, x0: this.x, y0: this.y, moved: true }; }
    });
    st.addEventListener('pointermove', e => {
      if (!P.has(e.pointerId) || !g) return;
      P.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (g.mode === 'pinch' && P.size >= 2) {
        const m = mid(), nz = clamp(g.z0 * m.d / g.d0, 0.7, 10), cx = this.vw / 2, cy = this.vh / 2, k = nz / g.z0;
        this.z = nz; this.x = m.x - cx - (g.c0x - cx - g.x0) * k; this.y = m.y - cy - (g.c0y - cy - g.y0) * k;
        if (nz > 1) this.clampPan(); this.placeCur(); return;
      }
      const dx = e.clientX - g.sx, dy = e.clientY - g.sy, now = Date.now();
      if (!g.moved && Math.hypot(dx, dy) < 9) return;
      if (!g.moved) { g.moved = true; g.mode = this.z > 1.03 ? 'pan' : Math.abs(dx) > Math.abs(dy) ? 'page' : (dy > 0 ? 'dismiss' : 'up'); }
      const dt = now - g.lt; if (dt > 0) g.vx = (e.clientX - g.lx) / dt; g.lx = e.clientX; g.lt = now;
      if (g.mode === 'pan') { this.x = g.x0 + dx; this.y = g.y0 + dy; this.clampPan(); this.placeCur(); }
      else if (g.mode === 'page') {
        const edge = (dx > 0 && this.i === 0) || (dx < 0 && this.i === this.items.length - 1);
        this.track.style.transition = 'none'; this.track.style.transform = `translateX(${edge ? dx * 0.3 : dx}px)`;
      } else if (g.mode === 'dismiss') {
        const l = this.L[1].el; l.style.transition = 'none'; l.style.transform = `translateY(${dy}px) scale(${1 - Math.min(.25, dy / 1500)})`;
        $('#viewer').style.setProperty('--bgo', String(Math.max(0, 1 - dy / 480)));
        $('#vtop').style.opacity = $('#vbot').style.opacity = Math.max(0, 1 - dy / 140);
      } else if (g.mode === 'up') {
        this.L[1].el.style.transition = 'none'; this.L[1].el.style.transform = `translateY(${Math.max(dy, -70)}px)`;
      }
    });
    const end = e => {
      if (!P.has(e.pointerId)) return;
      P.delete(e.pointerId);
      if (!g) return;
      if (g.mode === 'pinch') {
        if (P.size === 1) { const p = [...P.values()][0]; g = { mode: null, sx: p.x, sy: p.y, t: Date.now(), x0: this.x, y0: this.y, moved: true, lx: p.x, lt: Date.now(), vx: 0 }; g.mode = 'pan'; }
        if (this.z < 1) this.zoomTo(1); else { this.clampPan(); this.animate(); this.placeCur(); }
        if (P.size === 0) g = null; return;
      }
      if (P.size > 0) return;
      const gg = g; g = null;
      if (!gg.moved) { // a tap
        const now = Date.now();
        if (e.target.closest && e.target.closest('button')) return;
        if (now - lastTap.t < 300 && Math.hypot(e.clientX - lastTap.x, e.clientY - lastTap.y) < 40) {
          clearTimeout(tapTimer); lastTap.t = 0;
          this.zoomTo(this.z > 1.05 ? 1 : ST.dtz, e.clientX, e.clientY);
        } else {
          lastTap = { t: now, x: e.clientX, y: e.clientY };
          tapTimer = setTimeout(() => this.tap(e.clientX, e.clientY), 260);
        }
        return;
      }
      if (gg.mode === 'page') {
        const dx = e.clientX - gg.sx, thr = this.vw * 0.2;
        if ((dx < -thr || gg.vx < -0.5) && this.i < this.items.length - 1) this.swap(1, 'slide');
        else if ((dx > thr || gg.vx > 0.5) && this.i > 0) this.swap(-1, 'slide');
        else { this.track.style.transition = 'transform .22s ease'; this.track.style.transform = 'translateX(0)'; }
      } else if (gg.mode === 'dismiss') {
        const dy = e.clientY - gg.sy;
        if (dy > 110) { this.close(); }
        else { const l = this.L[1].el; l.style.transition = 'transform .2s ease'; l.style.transform = ''; $('#viewer').style.setProperty('--bgo', '1'); $('#vtop').style.opacity = $('#vbot').style.opacity = ''; }
      } else if (gg.mode === 'up') {
        const dy = e.clientY - gg.sy; const l = this.L[1].el; l.style.transition = 'transform .2s ease'; l.style.transform = '';
        if (dy < -60) this.info();
      } else if (gg.mode === 'pan') { this.animate(); this.placeCur(); }
    };
    st.addEventListener('pointerup', end); st.addEventListener('pointercancel', end);
    st.addEventListener('wheel', e => { if (!this.active) return; e.preventDefault(); this.zoomTo(this.z * (e.deltaY < 0 ? 1.15 : 0.87), e.clientX, e.clientY, false); }, { passive: false });
  },
  tap() {
    if (this.tool) return this.closeTool();
    if (this.ss.on) { return this.ssToggle(); }
    this.ui = !this.ui; this.chrome();
  },

  /* ----- chrome (top bar, bottom bar, caption) ----- */
  chrome(light) {
    const it = this.cur; if (!it) return;
    const v = $('#viewer');
    v.classList.toggle('hideui', !this.ui || this.ss.on);
    if (this.ui && !this.ss.on) Dev.fullscreen(false); else Dev.fullscreen(true);
    if (light) return;
    const e = this.E(it), edited = e.rot || e.fx < 0 || e.fy < 0 || JSON.stringify(e.adj) !== '{}';
    $('#vtop').innerHTML = `<button class="vb" data-act="v-back" aria-label="Back">${ic('left', 24)}</button>
      <div class="vtt"><b>${esc(it.n)}</b><small>${this.i + 1} / ${this.items.length}${it.t ? ' · ' + dateStr(it.t) : ''}${edited ? ' · edited' : ''}</small></div>
      ${this.vault ? '' : `<button class="vb ${isFav(it.key) ? 'fav' : ''}" data-act="v-fav" aria-label="Favourite">${isFav(it.key) ? icFill('heart', 22) : ic('heart', 22)}</button>`}
      <button class="vb" data-act="v-more" aria-label="More">${ic('more', 22)}</button>`;
    const B = this.vault
      ? [['dl', 'Export', 'v-export'], ['sliders', 'Edit', 'v-edit'], ['slides', 'Slideshow', 'v-ss'], ['info', 'Info', 'v-info'], ['trash', 'Delete', 'v-del', 1]]
      : [['share', 'Share', 'v-share'], ['sliders', 'Edit', 'v-edit'], ['slides', 'Slideshow', 'v-ss'], ['info', 'Info', 'v-info'], ['trash', 'Delete', 'v-del', 1]];
    $('#vbot').innerHTML = B.map(b => `<button class="${b[3] ? 'danger' : ''}" data-act="${b[2]}">${ic(b[0], 22)}<span>${b[1]}</span></button>`).join('');
    const cap = $('#vcap');
    cap.innerHTML = this.ss.on && ST.ssCap ? `<b>${esc(it.n)}</b><small>${dateStr(it.t)}</small>` : '';
  },

  /* ----- rotate, flip ----- */
  rotate(d) { const e = this.E(this.cur); e.rot = ((e.rot + d) % 360 + 360) % 360; if (e.rot > 180) e.rot -= 360; this.z = 1; this.x = this.y = 0; this.animate(); this.placeCur(); this.chrome(); this.refreshTool(); },
  setRot(a) { const e = this.E(this.cur); e.rot = a; this.z = 1; this.x = this.y = 0; this.placeCur(); },
  flip(ax) { const e = this.E(this.cur); if (ax === 'h') e.fx *= -1; else e.fy *= -1; this.animate(); this.placeCur(); this.chrome(); },
  setAdj(k, v) { const e = this.E(this.cur); if (v === ADJ0[k]) delete e.adj[k]; else e.adj[k] = v; this.placeCur(); },
  resetEdits() { delete this.edits[this.cur.key]; this.placeCur(); this.chrome(); this.refreshTool(); },

  /* ----- tools panel ----- */
  openTool(name) {
    this.tool = name; this.ui = true; this.chrome(true);
    const t = $('#vtools'); t.hidden = false; requestAnimationFrame(() => t.classList.add('on'));
    $('#viewer').classList.add('tooling');
    this.refreshTool();
  },
  closeTool() { this.tool = null; const t = $('#vtools'); t.classList.remove('on'); setTimeout(() => { if (!this.tool) t.hidden = true; }, 200); $('#viewer').classList.remove('tooling'); },
  refreshTool() {
    if (!this.tool) return;
    const e = this.E(this.cur), a = Object.assign({}, ADJ0, e.adj);
    const tabs = [['rot', 'Rotate', 'rotcw'], ['adj', 'Adjust', 'sun'], ['fx', 'Filters', 'wand'], ['crop', 'Crop', 'crop']];
    let body = '';
    if (this.tool === 'rot') {
      body = `<div class="trow"><button class="tb" data-act="v-rot" data-d="-90">${ic('rotccw', 24)}<span>Left 90°</span></button><button class="tb" data-act="v-rot" data-d="90">${ic('rotcw', 24)}<span>Right 90°</span></button><button class="tb ${e.fx < 0 ? 'on' : ''}" data-act="v-flip" data-a="h">${ic('fliph', 24)}<span>Flip ↔</span></button><button class="tb ${e.fy < 0 ? 'on' : ''}" data-act="v-flip" data-a="v">${ic('flipv', 24)}<span>Flip ↕</span></button></div>
      <div class="lbl">STRAIGHTEN · <b id="rotv">${Math.round(e.rot * 10) / 10}°</b></div><input type="range" class="rng" id="rotr" min="-180" max="180" step="0.5" value="${e.rot}">`;
    } else if (this.tool === 'adj') {
      const S = [['b', 'Brightness', 40, 180], ['c', 'Contrast', 40, 200], ['s', 'Saturation', 0, 250], ['h', 'Hue', -180, 180], ['se', 'Sepia', 0, 100], ['g', 'Black & white', 0, 100], ['bl', 'Blur', 0, 12]];
      body = `<div class="sl">${S.map(s => `<label><span>${s[1]} <b id="av-${s[0]}">${a[s[0]]}</b></span><input type="range" class="rng" data-adj="${s[0]}" min="${s[2]}" max="${s[3]}" step="1" value="${a[s[0]]}"></label>`).join('')}</div>`;
    } else if (this.tool === 'fx') {
      body = `<div class="chips wrapc">${Object.keys(PRESETS).map(k => `<button class="chip" data-act="v-preset" data-k="${k}">${k}</button>`).join('')}</div><p class="hint">Edits are never written over your original. Use <b>Save a copy</b> to keep them.</p>`;
    } else if (this.tool === 'crop') {
      body = `<div class="chips">${[['free', 'Free'], ['1:1', '1:1'], ['4:3', '4:3'], ['3:4', '3:4'], ['16:9', '16:9'], ['9:16', '9:16']].map(c => `<button class="chip ${this.cropAsp === c[0] ? 'on' : ''}" data-act="crop-asp" data-v="${c[0]}">${c[1]}</button>`).join('')}</div>`;
    }
    $('#vtools').innerHTML = `<div class="ttabs">${tabs.map(t => `<button class="${this.tool === t[0] ? 'on' : ''}" data-act="v-tool" data-v="${t[0]}">${ic(t[2], 18)}<span>${t[1]}</span></button>`).join('')}<span class="sp"></span><button class="ib sm" data-act="v-tool-x">${ic('x', 20)}</button></div>
      <div class="tbody">${body}</div>
      <div class="tfoot"><button class="btn" data-act="v-reset">${ic('undo', 16)} Reset</button><button class="btn pri" data-act="${this.tool === 'crop' ? 'crop-save' : 'v-savecopy'}">${ic('dl', 16)} ${this.tool === 'crop' ? 'Save cropped copy' : 'Save a copy'}</button></div>`;
    if (this.tool === 'crop' && !this.cropOn) this.cropStart(); else if (this.tool !== 'crop' && this.cropOn) this.cropCancel(true);
    const rr = $('#rotr'); if (rr) rr.oninput = ev => { this.setRot(+ev.target.value); $('#rotv').textContent = Math.round(+ev.target.value * 10) / 10 + '°'; };
    $$('[data-adj]', $('#vtools')).forEach(r => r.oninput = ev => { this.setAdj(r.dataset.adj, +r.value); $('#av-' + r.dataset.adj).textContent = r.value; });
  },

  /* ----- crop ----- */
  cropStart() {
    const it = this.cur, e = this.E(it), l = this.L[1], im = l.img;
    this.resetZoom(true);
    const { fit, bw, bh } = this.fitScale(im.naturalWidth || it.w || 1000, im.naturalHeight || it.h || 1000, e.rot);
    const w = bw * fit, h = bh * fit, x = (this.vw - w) / 2, y = (this.vh - h) / 2;
    this.cb = { bx: x, by: y, bw: w, bh: h, x, y, w, h }; this.cropOn = true;
    $('#vcrop').hidden = false; this.cropAspect(this.cropAsp || 'free'); this.cropDraw();
    this.cropBind();
  },
  cropAspect(a) {
    this.cropAsp = a; const c = this.cb; if (!c) return;
    if (a !== 'free') {
      const [p, q] = a.split(':').map(Number); const r = p / q;
      let w = c.bw, h = w / r; if (h > c.bh) { h = c.bh; w = h * r; }
      c.w = w * 0.9; c.h = h * 0.9; c.x = c.bx + (c.bw - c.w) / 2; c.y = c.by + (c.bh - c.h) / 2;
    } else { c.x = c.bx; c.y = c.by; c.w = c.bw; c.h = c.bh; }
    this.cropDraw();
  },
  cropDraw() {
    const c = this.cb, b = $('#cbox'); if (!c || !b) return;
    b.style.cssText = `left:${c.x}px;top:${c.y}px;width:${c.w}px;height:${c.h}px`;
  },
  cropBind() {
    const box = $('#cbox'); if (box._b) return; box._b = true;
    let drag = null;
    box.addEventListener('pointerdown', e => {
      e.stopPropagation(); box.setPointerCapture(e.pointerId);
      const h = e.target.closest('.h'); drag = { m: h ? h.className.replace('h ', '') : 'move', sx: e.clientX, sy: e.clientY, o: { ...this.cb } };
    });
    box.addEventListener('pointermove', e => {
      if (!drag) return; const c = this.cb, o = drag.o, dx = e.clientX - drag.sx, dy = e.clientY - drag.sy, min = 40;
      const L = c.bx, T = c.by, R = c.bx + c.bw, B = c.by + c.bh;
      if (drag.m === 'move') { c.x = clamp(o.x + dx, L, R - o.w); c.y = clamp(o.y + dy, T, B - o.h); }
      else {
        let x1 = o.x, y1 = o.y, x2 = o.x + o.w, y2 = o.y + o.h;
        if (drag.m.includes('l')) x1 = clamp(o.x + dx, L, x2 - min); if (drag.m.includes('r')) x2 = clamp(x2 + dx, x1 + min, R);
        if (drag.m.includes('t')) y1 = clamp(o.y + dy, T, y2 - min); if (drag.m.includes('b')) y2 = clamp(y2 + dy, y1 + min, B);
        if (this.cropAsp && this.cropAsp !== 'free') {
          const [p, q] = this.cropAsp.split(':').map(Number), r = p / q;
          let w = x2 - x1, h = y2 - y1; if (w / h > r) w = h * r; else h = w / r;
          if (drag.m.includes('l')) x1 = x2 - w; else x2 = x1 + w; if (drag.m.includes('t')) y1 = y2 - h; else y2 = y1 + h;
          if (x1 < L || y1 < T || x2 > R || y2 > B) return;
        }
        c.x = x1; c.y = y1; c.w = x2 - x1; c.h = y2 - y1;
      }
      this.cropDraw();
    });
    const up = () => { drag = null; };
    box.addEventListener('pointerup', up); box.addEventListener('pointercancel', up);
  },
  cropCancel(keepTool) { this.cropOn = false; $('#vcrop').hidden = true; if (!keepTool) this.closeTool(); },

  /* ----- saving a copy ----- */
  async render(it, crop, clean) {
    const l = this.L[1], img = l.img;
    if (!img.naturalWidth) throw new Error('Picture not loaded');
    const e = clean ? { rot: 0, fx: 1, fy: 1, adj: {} } : this.E(it);
    const nw = img.naturalWidth, nh = img.naturalHeight;
    const rr = e.rot * Math.PI / 180, c = Math.abs(Math.cos(rr)), s = Math.abs(Math.sin(rr));
    let bw = nw * c + nh * s, bh = nw * s + nh * c;
    const k = Math.min(1, 4096 / Math.max(bw, bh));
    const cv = document.createElement('canvas'); cv.width = Math.round(bw * k); cv.height = Math.round(bh * k);
    const cx = cv.getContext('2d');
    cx.filter = filterCSS(e.adj); cx.translate(cv.width / 2, cv.height / 2); cx.rotate(rr); cx.scale(e.fx, e.fy);
    cx.drawImage(img, -nw * k / 2, -nh * k / 2, nw * k, nh * k);
    let out = cv;
    if (crop) {
      const sx = Math.round(crop.fx * cv.width), sy = Math.round(crop.fy * cv.height), sw = Math.max(1, Math.round(crop.fw * cv.width)), sh = Math.max(1, Math.round(crop.fh * cv.height));
      out = document.createElement('canvas'); out.width = sw; out.height = sh; out.getContext('2d').drawImage(cv, sx, sy, sw, sh, 0, 0, sw, sh);
    }
    return new Promise((res, rej) => out.toBlob(b => b ? res(b) : rej(new Error('Could not encode')), 'image/jpeg', 0.92));
  },
  async saveCopy(opts = {}) {
    const it = this.cur;
    try {
      toast('Saving…');
      let crop = null;
      if (opts.crop && this.cb) { const c = this.cb; crop = { fx: (c.x - c.bx) / c.bw, fy: (c.y - c.by) / c.bh, fw: c.w / c.bw, fh: c.h / c.bh }; }
      const blob = await this.render(it, crop, opts.clean);
      const base = it.n.replace(/\.[^.]+$/, '');
      const name = `${base}_${opts.clean ? 'clean' : opts.crop ? 'crop' : 'edit'}_${Date.now().toString(36)}.jpg`;
      const ok = await saveBlobToGallery(blob, name, 'image/jpeg', false);
      if (ok) { toast(`Saved to Pictures/NerdyPlayer`); rescan(true); if (opts.crop) this.closeTool(); } else toast('Could not save');
    } catch (e) { toast('Could not save: ' + e.message); }
  },

  /* ----- info ----- */
  async info() {
    const it = this.cur; if (!it) return;
    Items.info(it);
    if (it.v) return;
    const ex = await readExif(it);
    if (!ex || !Sheet.isOpen) return;
    const f = ex.f ? 'ƒ/' + (Math.round(ex.f * 10) / 10) : '';
    const exp = ex.exp ? (ex.exp < 1 ? '1/' + Math.round(1 / ex.exp) + ' s' : ex.exp + ' s') : '';
    const rows = [
      ex.make || ex.model ? ['Camera', [ex.make, ex.model].filter(Boolean).join(' ')] : null, ex.lens ? ['Lens', ex.lens] : null,
      [f, exp, ex.iso ? 'ISO ' + (Array.isArray(ex.iso) ? ex.iso[0] : ex.iso) : '', ex.focal ? Math.round(ex.focal) + ' mm' : ''].filter(Boolean).length ? ['Exposure', [f, exp, ex.iso ? 'ISO ' + (Array.isArray(ex.iso) ? ex.iso[0] : ex.iso) : '', ex.focal ? Math.round(ex.focal) + ' mm' : ''].filter(Boolean).join(' · ')] : null,
      ex.date ? ['Shot', ex.date.replace(/^(\d+):(\d+):(\d+)/, '$1-$2-$3')] : null, ex.soft ? ['Software', ex.soft] : null,
      ex.lat != null ? ['Location', `${ex.lat.toFixed(5)}, ${ex.lon.toFixed(5)}`] : null,
    ].filter(Boolean);
    if (!rows.length) return;
    const box = $('#sheet .kvs');
    if (box) box.insertAdjacentHTML('beforeend', `<div class="kvh">Camera data (EXIF)</div>` + rows.map(r => `<div class="kv"><span>${r[0]}</span><b>${esc(r[1])}</b></div>`).join('')
      + (ex.lat != null ? `<div class="note">${ic('eye', 14)} This photo carries its GPS location. Use <b>More → Save clean copy</b> before sharing it anywhere.</div>` : ''));
  },

  /* ----- slideshow ----- */
  ssStart() {
    if (!this.items.length) return;
    this.ssSettings(true);
  },
  ssGo() {
    const list = this.items.filter(x => ST.ssVideos || !x.v);
    if (!list.length) return toast('No photos to show');
    if (ST.ssShuffle) { const cur = this.cur; const rest = list.filter(x => x !== cur).sort(() => Math.random() - .5); this.items = cur && !cur.v ? [cur, ...rest] : rest; this.i = 0; }
    else { this.items = list; if (!list.includes(this.cur)) this.i = 0; else this.i = list.indexOf(this.cur); }
    this.ss.on = true; this.ss.paused = false; this.ui = false;
    this.resetZoom(true); this.fillAll(); this.chrome(); Dev.keepOn(true);
    $('#ssctl').hidden = true; this.ssArm();
    const c = this.L[1]; if (ST.ssKB && c.it && !c.it.v) { c.in.classList.remove('kbi'); void c.in.offsetWidth; c.in.classList.add('kbi'); }
  },
  ssArm() {
    clearTimeout(this.ss.timer);
    const bar = $('#ssprog'); bar.classList.remove('run'); void bar.offsetWidth;
    if (!this.ss.on || this.ss.paused) return;
    const it = this.cur; if (!it) return;
    document.documentElement.style.setProperty('--ssd', ST.ssInt + 's');
    document.documentElement.style.setProperty('--kbd', (ST.ssInt + 1) + 's');
    if (it.v) { this.ssVideoSlide(it); return; }
    bar.classList.add('run');
    this.ss.timer = setTimeout(() => this.ssNext(), ST.ssInt * 1000);
  },
  ssVideoSlide(it) { // play the clip and carry on when it ends
    const l = this.L[1]; let v = l.el.querySelector('video');
    if (!v) { v = document.createElement('video'); v.playsInline = true; v.className = 'ssvid'; l.el.appendChild(v); }
    v.src = Src.url(it); v.onended = () => { v.remove(); this.ssNext(); }; v.onerror = () => { v.remove(); this.ssNext(); };
    v.play().catch(() => { v.remove(); this.ssNext(); }); l.play.hidden = true; this.ss.vid = v;
  },
  ssNext() {
    if (!this.ss.on) return;
    document.querySelectorAll('.ssvid').forEach(v => { try { v.pause(); } catch (e) { } v.remove(); });
    if (this.i >= this.items.length - 1) { if (ST.ssLoop && this.items.length > 1) return this.swapTo0(); return this.ssStop(); }
    this.swap(1, ST.ssTrans === 'slide' ? 'slide' : ST.ssTrans === 'zoom' ? 'zoom' : ST.ssTrans === 'none' ? 'none' : 'fade');
  },
  async swapTo0() { this.i = this.items.length - 1; this.L.forEach(l => l.el.style.transition = 'none'); this.jump(0); this.ss.on && this.ssArm(); },
  ssToggle() {
    if (!this.ss.on) return;
    this.ss.paused = !this.ss.paused;
    clearTimeout(this.ss.timer);
    if (this.ss.vid) { try { this.ss.paused ? this.ss.vid.pause() : this.ss.vid.play(); } catch (e) { } }
    const c = $('#ssctl'); c.hidden = false;
    c.innerHTML = `<button data-act="ss-prev">${ic('prev', 22)}</button><button class="big" data-act="ss-toggle">${this.ss.paused ? icFill('play', 26) : ic('pause', 26)}</button><button data-act="ss-next">${ic('next', 22)}</button><button data-act="ss-set">${ic('sliders', 20)}</button><button data-act="ss-stop">${ic('x', 20)}</button>`;
    $('#ssprog').classList.toggle('paused', this.ss.paused);
    if (!this.ss.paused) { this.ssArm(); setTimeout(() => { if (!this.ss.paused) c.hidden = true; }, 1600); }
  },
  ssStop(quiet) {
    clearTimeout(this.ss.timer); this.ss.on = false; this.ss.paused = false;
    document.querySelectorAll('.ssvid').forEach(v => { try { v.pause(); } catch (e) { } v.remove(); });
    const c = $('#ssctl'); if (c) c.hidden = true; const b = $('#ssprog'); if (b) b.classList.remove('run');
    this.L.forEach(l => l.in && l.in.classList.remove('kbi'));
    if (!quiet) { this.ui = true; this.chrome(); Dev.keepOn(false); }
    else Dev.keepOn(false);
  },
  ssSettings(start) {
    const s = Sheet.open(`
      <div class="lbl">TIME PER PHOTO · <b id="ssiv">${ST.ssInt} s</b></div><input type="range" class="rng" id="ssi" min="1" max="30" step="1" value="${ST.ssInt}">
      <div class="lbl">TRANSITION</div>${seg([['fade', 'Fade'], ['slide', 'Slide'], ['zoom', 'Zoom'], ['none', 'None']], ST.ssTrans, 'ss-set-v', 'ssTrans')}
      <div class="rowsw"><span>Slow zoom (Ken Burns)</span>${sw(ST.ssKB, 'ss-sw', 'ssKB')}</div>
      <div class="rowsw"><span>Shuffle</span>${sw(ST.ssShuffle, 'ss-sw', 'ssShuffle')}</div>
      <div class="rowsw"><span>Repeat when finished</span>${sw(ST.ssLoop, 'ss-sw', 'ssLoop')}</div>
      <div class="rowsw"><span>Include videos (plays each fully)</span>${sw(ST.ssVideos, 'ss-sw', 'ssVideos')}</div>
      <div class="rowsw"><span>Show name and date</span>${sw(ST.ssCap, 'ss-sw', 'ssCap')}</div>
      ${start ? `<button class="btn pri wide" data-act="ss-go" style="margin-top:14px">${icFill('play', 14)} Start slideshow</button>` : ''}`, { title: 'Slideshow' });
    $('#ssi', s).oninput = e => { ST.ssInt = +e.target.value; $('#ssiv', s).textContent = ST.ssInt + ' s'; saveST(); };
  },
};
Viewer.cropAsp = 'free';

ACT['v-back'] = () => Viewer.back();
ACT['v-fav'] = () => { toggleFav(Viewer.cur.key); Viewer.chrome(); };
ACT['v-share'] = () => Items.share([Viewer.cur]);
ACT['v-del'] = () => { const it = Viewer.cur; if (Viewer.vault) Vault.deleteItems([it]); else Items.del([it]); };
ACT['v-info'] = () => Viewer.info();
ACT['v-edit'] = () => Viewer.openTool('rot');
ACT['v-ss'] = () => Viewer.ssStart();
ACT['v-tool'] = el => { Viewer.tool = el.dataset.v; Viewer.refreshTool(); };
ACT['v-tool-x'] = () => Viewer.cropOn ? Viewer.cropCancel() : Viewer.closeTool();
ACT['v-rot'] = el => Viewer.rotate(+el.dataset.d);
ACT['v-flip'] = el => { Viewer.flip(el.dataset.a); Viewer.refreshTool(); };
ACT['v-preset'] = el => { const e = Viewer.E(Viewer.cur); e.adj = Object.assign({}, PRESETS[el.dataset.k]); Viewer.placeCur(); Viewer.chrome(); $$('#vtools .chip').forEach(c => c.classList.toggle('on', c === el)); };
ACT['v-reset'] = () => { if (Viewer.cropOn) Viewer.cropAspect('free'); else Viewer.resetEdits(); };
ACT['v-savecopy'] = () => Viewer.saveCopy();
ACT['crop-asp'] = el => { Viewer.cropAspect(el.dataset.v); $$('#vtools .chip').forEach(c => c.classList.toggle('on', c === el)); };
ACT['crop-save'] = () => Viewer.saveCopy({ crop: true });
ACT['v-export'] = () => Vault.exportItems([Viewer.cur]);
ACT['v-more'] = () => {
  const it = Viewer.cur;
  menuSheet(it.n, [
    ['rotcw', 'Rotate right', () => Viewer.rotate(90)],
    ['fliph', 'Flip', () => Viewer.flip('h')],
    it.v ? ['play', 'Play video', () => ACT['v-share'] && Viewer.L[1].play.click()] : ['dl', 'Save a clean copy (no metadata)', () => Viewer.saveCopy({ clean: true })],
    ['slides', 'Slideshow settings', () => Viewer.ssSettings(false)],
    Viewer.vault ? null : ['layers', 'Add to collection', () => Items.collect([it])],
    Viewer.vault ? null : ['lock', 'Move to vault', () => Items.toVault([it])],
    Viewer.vault ? null : ['ext', 'Open with another app', () => Native.call('openWith', it.key, 'view')],
    Viewer.vault || it.v ? null : ['image', 'Set as…', () => Native.call('openWith', it.key, 'attach')],
  ]);
};
ACT['ss-go'] = () => { Sheet.close(); Viewer.ssGo(); };
ACT['ss-toggle'] = () => Viewer.ssToggle();
ACT['ss-prev'] = () => { Viewer.step(-1, 'slide'); };
ACT['ss-next'] = () => { Viewer.step(1, 'slide'); };
ACT['ss-set'] = () => Viewer.ssSettings(false);
ACT['ss-stop'] = () => Viewer.ssStop();
ACT['ss-set-v'] = el => { ST[el.dataset.k] = el.dataset.v; saveST(); $$(`[data-act=ss-set-v]`).forEach(b => b.classList.toggle('on', b.dataset.v === el.dataset.v)); };
ACT['ss-sw'] = el => { const k = el.dataset.k; ST[k] = !ST[k]; saveST(); el.classList.toggle('on', ST[k]); };
