'use strict';
/* ===== NerdyPlayer · gallery: grids, selection, item actions ===== */

/* selection (shared by the main screens) */
const SEL = { on: false, keys: new Set(), ctx: 'gallery', grid: null };
const selItems = () => (SEL.grid ? SEL.grid.items : []).filter(i => SEL.keys.has(i.key));

class GridView {
  /* el: container element, items: array of item objects
     cfg: { mode:'grid'|'list', cols, tile:'square'|'orig', group:'day'|'month'|'none', by:'date'|'added', sel, root, onTap, onLong, onMore } */
  constructor(el, items, cfg) {
    this.el = el; this.items = items; this.cfg = cfg; this.sel = cfg.sel || SEL; this.shown = 0; this.last = null;
    el.innerHTML = `<div class="grid ${cfg.mode === 'list' ? 'list' : (cfg.mode === 'cards' || cfg.mode === 'feed') ? 'bigs ' + cfg.mode : 'tiles'} ${cfg.tile === 'orig' ? 'orig' : ''} ${cfg.cls || ''}" style="--cols:${cfg.cols || 3}"></div><div class="gmore"></div>`;
    this.g = el.firstElementChild; this.sent = el.lastElementChild;
    this.more();
    this.io = new IntersectionObserver(es => { if (es.some(e => e.isIntersecting)) this.more(); }, { root: cfg.root || null, rootMargin: '900px' });
    this.io.observe(this.sent);
    this.bind();
  }
  destroy() { try { this.io.disconnect(); } catch (e) { } }
  label(it) {
    const g = this.cfg.group; if (!g || g === 'none') return null;
    const t = this.cfg.by === 'added' ? it.a : it.t;
    return g === 'month' ? monthLabel(t) : dayLabel(t);
  }
  more() {
    if (this.shown >= this.items.length) { this.sent.hidden = true; return; }
    const end = Math.min(this.items.length, this.shown + (this.cfg.mode === 'list' ? 80 : 240));
    let h = '';
    for (let i = this.shown; i < end; i++) {
      const it = this.items[i];
      const lb = this.label(it);
      if (lb !== null && lb !== this.last) { h += `<div class="grp">${esc(lb)}</div>`; this.last = lb; }
      h += this.cfg.mode === 'list' ? this.rowHTML(it) : this.tileHTML(it);
    }
    this.shown = end;
    this.g.insertAdjacentHTML('beforeend', h);
    this.sent.hidden = this.shown >= this.items.length;
  }
  tileHTML(it) {
    const sel = this.sel.keys.has(it.key);
    const th = Src.thumb(it, 300);
    const p = it.v ? posOf(it.key) : null;
    return `<div class="tile ${sel ? 'sel' : ''}" data-key="${it.key}" style="--ar:${((it.w && it.h) ? Math.max(.5, Math.min(2.2, it.w / it.h)) : 1).toFixed(2)}">
      ${th ? `<img loading="lazy" decoding="async" src="${th}" alt="" onerror="this.classList.add('bad')">` : ''}
      ${it.v ? `<span class="dur">${icFill('play', 9)} ${fmtDur(it.d)}</span>` : ''}
      ${isFav(it.key) ? `<i class="bd fav">${icFill('heart', 13)}</i>` : ''}
      ${p && it.d ? `<div class="prog"><i style="width:${Math.min(100, p.t * 1000 / it.d * 100).toFixed(1)}%"></i></div>` : ''}
      <i class="chk">${ic('check', 15)}</i></div>`;
  }
  rowHTML(it) {
    const sel = this.sel.keys.has(it.key);
    const th = Src.thumb(it, 240);
    const p = it.v ? posOf(it.key) : null;
    const res = it.w && it.h ? `${it.w}×${it.h}` : '';
    return `<div class="item ${sel ? 'sel' : ''}" data-key="${it.key}">
      <div class="thumb">${th ? `<img loading="lazy" decoding="async" src="${th}" alt="" onerror="this.classList.add('bad')">` : ''}<span class="ph">${ic(it.v ? 'film' : 'image', 24)}</span>
        ${it.v ? `<span class="dur">${fmtDur(it.d)}</span>` : ''}
        ${p && it.d ? `<div class="prog"><i style="width:${Math.min(100, p.t * 1000 / it.d * 100).toFixed(1)}%"></i></div>` : ''}
        <i class="chk">${ic('check', 15)}</i></div>
      <div class="meta"><b class="t">${esc(it.n)}</b>
        <span>${[res, sizeStr(it.s)].filter(Boolean).join(' · ')}</span>
        <span>${esc(it.b)} · ${dateStr(it.t)}</span></div>
      ${isFav(it.key) ? `<i class="bd favi">${icFill('heart', 14)}</i>` : ''}
      <button class="more" data-more aria-label="More">${ic('more', 20)}</button></div>`;
  }
  find(key) { return this.items.find(i => i.key === key); }
  refresh() {
    $$('[data-key]', this.g).forEach(el => el.classList.toggle('sel', this.sel.keys.has(el.dataset.key)));
    this.g.classList.toggle('selmode', !!this.sel.on);
  }
  bind() {
    const g = this.g; let timer = null, sx = 0, sy = 0, fired = false;
    const cancel = () => { clearTimeout(timer); timer = null; };
    g.addEventListener('pointerdown', e => {
      const el = e.target.closest('[data-key]'); if (!el || e.target.closest('[data-more]')) return;
      fired = false; sx = e.clientX; sy = e.clientY; cancel();
      timer = setTimeout(() => { fired = true; navigator.vibrate && navigator.vibrate(18); const it = this.find(el.dataset.key); if (it && this.cfg.onLong) this.cfg.onLong(it, this); }, 420);
    });
    g.addEventListener('pointermove', e => { if (timer && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) cancel(); });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(t => g.addEventListener(t, cancel));
    g.addEventListener('contextmenu', e => e.preventDefault());
    g.addEventListener('click', e => {
      if (fired) { fired = false; e.preventDefault(); return; }
      const m = e.target.closest('[data-more]');
      const el = e.target.closest('[data-key]'); if (!el) return;
      const it = this.find(el.dataset.key); if (!it) return;
      if (m && this.cfg.onMore) { this.cfg.onMore(it, this); return; }
      if (this.cfg.onTap) this.cfg.onTap(it, this);
    });
  }
}

/* ---------- selection mode ---------- */
function selEnter(it, grid) {
  SEL.on = true; SEL.grid = grid; SEL.keys.add(it.key); selUI();
}
function selToggle(it) {
  if (SEL.keys.has(it.key)) SEL.keys.delete(it.key); else SEL.keys.add(it.key);
  if (!SEL.keys.size && SEL.ctx !== 'pick') return selExit();
  selUI();
}
function selExit() {
  SEL.on = false; SEL.keys.clear(); selUI();
}
function selAll() {
  if (!SEL.grid) return;
  const all = SEL.grid.items.length === SEL.keys.size;
  SEL.keys.clear(); if (!all) SEL.grid.items.forEach(i => SEL.keys.add(i.key));
  selUI();
}
function selUI() {
  const bar = $('#selbar'), act = $('#selact');
  document.body.classList.toggle('selecting', SEL.on);
  if (SEL.grid) SEL.grid.refresh();
  if (!SEL.on) { bar.hidden = true; act.hidden = true; return; }
  const n = SEL.keys.size;
  bar.hidden = false; act.hidden = false;
  bar.innerHTML = `<button class="ib" data-act="sel-exit" aria-label="Cancel">${ic('x', 22)}</button><b>${n ? n + ' selected' : 'Select items'}</b><span class="sp"></span><button class="ib" data-act="sel-all" aria-label="Select all">${ic('check', 22)}<small>All</small></button>`;
  const items = selItems();
  const bytes = items.reduce((a, b) => a + b.s, 0);
  const A = SEL.ctx === 'vault' ? [
    ['ul', 'Restore', 'vault-restore'], ['dl', 'Export', 'vault-export'], ['trash', 'Delete', 'vault-del', 1],
  ] : SEL.ctx === 'trash' ? [
    ['undo', 'Restore', 'trash-restore'], ['trash', 'Delete', 'trash-del', 1],
  ] : [
    ['share', 'Share', 'sel-share'], ['heart', 'Favourite', 'sel-fav'], ['layers', 'Add to', 'sel-col'], ['lock', 'Vault', 'sel-vault'], ['trash', 'Delete', 'sel-del', 1], ['more', 'More', 'sel-more'],
  ];
  act.innerHTML = (n ? `<div class="sizeln">${sizeStr(bytes)}</div>` : '') + `<div class="abtns">${A.map(a => `<button class="${a[3] ? 'danger' : ''}" data-act="${a[2]}" ${n ? '' : 'disabled'}>${ic(a[0], 22)}<span>${a[1]}</span></button>`).join('')}</div>`;
}
ACT['sel-exit'] = () => selExit();
ACT['sel-all'] = () => selAll();
ACT['sel-share'] = () => Items.share(selItems());
ACT['sel-fav'] = () => { const on = toggleFav(selKeys()); toast(on ? 'Added to favourites' : 'Removed from favourites'); selExit(); App.render(); };
ACT['sel-col'] = () => Items.collect(selItems());
ACT['sel-vault'] = () => Items.toVault(selItems());
ACT['sel-del'] = () => Items.del(selItems());
ACT['sel-more'] = () => {
  const it = selItems();
  menuSheet(plural(it.length, 'item'), [
    ['info', 'Details', () => it.length === 1 ? Items.info(it[0]) : Items.infoMany(it)],
    ['slides', 'Slideshow from these', () => { const l = it.filter(i => !i.v); if (!l.length) return toast('Pick at least one photo'); selExit(); Viewer.open(l, 0, { slideshow: true }); }],
    ['eyeoff', 'Hide this folder (lock)', () => { const bs = [...new Set(it.map(i => i.b))]; selExit(); bs.forEach(b => Items.lockFolder(b, true)); }],
  ]);
};
const selKeys = () => [...SEL.keys];

/* ---------- actions on items ---------- */
const Items = {
  open(it, list) {
    if (it.v) { const vids = list.filter(x => x.v); Player.open(vids, Math.max(0, vids.indexOf(it))); }
    else Viewer.open(list, Math.max(0, list.indexOf(it)));
  },
  share(list) { if (!list.length) return; if (!AB) return toast('Sharing works in the phone app'); Native.call('share', JSON.stringify(list.map(i => i.key))); },
  async del(list) {
    if (!list.length) return;
    const n = list.length, what = n === 1 ? `“${esc(list[0].n)}”` : plural(n, 'item');
    const bytes = sizeStr(list.reduce((a, b) => a + b.s, 0));
    let mode;
    if (Native.info.canTrash) {
      mode = await choiceBox(`Delete ${what}?`, `${bytes} will be freed.<br><br><b>Trash</b> keeps them for 30 days in your phone's trash so you can bring them back. <b>Permanent</b> cannot be undone.`,
        [['trash', 'Move to trash', 'pri'], ['delete', 'Delete permanently', 'danger'], ['no', 'Cancel']]);
    } else {
      mode = (await confirmBox(`Delete ${what}?`, `${bytes} will be removed from your phone. This cannot be undone.`, 'Delete', true)) ? 'delete' : 'no';
    }
    if (!mode || mode === 'no') return;
    if (!AB) return toast('Deleting works in the phone app');
    Items.pendingDel = list;
    Native.call('deleteKeys', JSON.stringify(list.map(i => i.key)), mode === 'delete');
  },
  collect(list) {
    if (!list.length) return;
    const keys = list.map(i => i.key);
    const rows = UD.cols.map(c => `<button class="mi" data-c="${c.id}">${ic('layers', 20)}<span>${esc(c.name)}</span><small>${c.keys.length}</small></button>`).join('');
    const s = Sheet.open(`<div class="mlist"><button class="mi" data-c="__new">${ic('plus', 20)}<span>New collection…</span></button>${rows}</div>`, { title: 'Add to collection' });
    $$('.mi', s).forEach(b => b.onclick = async () => {
      let cid = b.dataset.c;
      Sheet.close();
      if (cid === '__new') {
        const name = await promptBox('New collection', 'Name', '', 'Create'); if (!name) return;
        cid = newCollection(name).id;
      }
      const n = addToCollection(cid, keys);
      toast(n ? `Added ${plural(n, 'item')}` : 'Already in the collection');
      if (SEL.on) selExit();
    });
  },
  async toVault(list) {
    if (!list.length) return;
    if (!AB) return toast('The vault works in the phone app');
    Vault.addItems(list);
  },
  info(it) {
    const rows = [['Name', it.n], ['Type', it.m || (it.v ? 'video' : 'image')], ['Size', sizeStr(it.s)], it.w ? ['Resolution', `${it.w} × ${it.h}${it.w && it.h ? ` (${(it.w * it.h / 1e6).toFixed(1)} MP)` : ''}`] : null,
      it.v ? ['Duration', fmtDur(it.d)] : null, ['Taken', dateStr(it.t, true)], it.a ? ['Added', dateStr(it.a, true)] : null, ['Folder', it.b], it.p ? ['Path', it.p + (it.p.endsWith('/') ? it.n : '')] : null].filter(Boolean);
    Sheet.open(`<div class="kvs">${rows.map(r => `<div class="kv"><span>${r[0]}</span><b>${esc(r[1])}</b></div>`).join('')}</div>`, { title: 'Details' });
  },
  infoMany(list) {
    const v = list.filter(i => i.v).length, im = list.length - v;
    Sheet.open(`<div class="kvs"><div class="kv"><span>Items</span><b>${list.length}</b></div><div class="kv"><span>Photos</span><b>${im}</b></div><div class="kv"><span>Videos</span><b>${v}</b></div><div class="kv"><span>Total size</span><b>${sizeStr(list.reduce((a, b) => a + b.s, 0))}</b></div></div>`, { title: 'Details' });
  },
  menu(it, grid) {
    const ctx = grid ? grid.items : [it];
    menuSheet(it.n, [
      ['play', it.v ? 'Play' : 'Open', () => Items.open(it, ctx)],
      ['heart', isFav(it.key) ? 'Remove from favourites' : 'Add to favourites', () => { toggleFav(it.key); App.render(); }],
      ['share', 'Share', () => Items.share([it])],
      ['layers', 'Add to collection', () => Items.collect([it])],
      ['lock', 'Move to vault', () => Items.toVault([it])],
      ['info', 'Details', () => Items.info(it)],
      ['ext', 'Open with another app', () => Native.call('openWith', it.key, 'view')],
      it.v ? null : ['image', 'Set as…', () => Native.call('openWith', it.key, 'attach')],
      ['check', 'Select', () => selEnter(it, grid)],
      ['trash', 'Delete', () => Items.del([it]), 1],
    ]);
  },
  async lockFolder(b, on) {
    const s = await Vault.needPin('app', on ? 'Lock this folder' : 'Unlock folder');
    if (!s) return;
    if (on) { if (!UD.lockedB.includes(b)) UD.lockedB.push(b); toast(`“${b}” is hidden. Find it under Albums.`); }
    else { UD.lockedB = UD.lockedB.filter(x => x !== b); toast('Folder unlocked for good'); }
    saveUD(); App.render();
  },
};

/* the result of a delete / trash request */
Native.on('del', o => {
  if (o.op === 'vaultorig') return Vault.originalsResult(o);
  const keys = o.keys || [];
  if (o.ok) {
    if (o.op === 'restore') { toast(`Restored ${plural(keys.length, 'item')}`); Native.call('scanTrash'); }
    else {
      toast(o.op === 'trash' ? `Moved ${plural(keys.length, 'item')} to trash` : `Deleted ${plural(keys.length, 'item')}`);
    }
    const gone = new Set(keys);
    if (o.op !== 'restore') {
      rebuildLib((LIB.raw || LIB.items).filter(i => !gone.has(i.key)));
      keys.forEach(k => { favSet.delete(k); delete UD.pos[k]; delete UD.marks[k]; });
      UD.cols.forEach(c => c.keys = c.keys.filter(k => !gone.has(k))); saveUD();
    }
    if (SEL.on) selExit();
    if (Viewer.active) Viewer.afterDelete(gone);
    rescan(true);
    if (App.view === 'trash') { Native.call('scan', true); }
    App.render();
  } else toast('Nothing was changed');
});
Native.on('perm', o => { Native.refreshInfo(); if (o.ok) rescan(true); else { LIB.denied = true; App.render(); } });

/* ---------- empty / permission states ---------- */
function emptyHTML(kind) {
  if (!AB) return `<div class="empty">${ic('offline', 44)}<h3>Open this in the NerdyPlayer app</h3><p>In a normal browser the app cannot see your gallery. You can still play a single file.</p><button class="btn pri" data-act="open-file">${ic('plus', 16)} Open a file</button></div>`;
  if (LIB.denied || !Native.info.perm) return `<div class="empty">${ic('shield', 44)}<h3>Allow access to your photos and videos</h3><p>NerdyPlayer reads your gallery right on the phone. It has no internet permission, so nothing is ever sent anywhere.</p><button class="btn pri" data-act="ask-perm">Allow access</button></div>`;
  if (!LIB.ready || LIB.scanning && !LIB.items.length) return `<div class="empty"><div class="spin"></div><p>Looking through your gallery…</p></div>`;
  return `<div class="empty">${ic(kind === 'v' ? 'film' : 'image', 44)}<h3>Nothing here yet</h3><p>${kind === 'f' ? 'Tap the heart on any photo or video to find it here.' : 'No matching files.'}</p></div>`;
}
ACT['ask-perm'] = () => Native.call('askPerm');
ACT['open-file'] = () => $('#filepick').click();

/* ---------- sort / view sheet ---------- */
function viewSheet(kind) {
  const by = kind === 'v' ? 'sortV' : 'sortP';
  const sorts = [['date', 'Date taken'], ['added', 'Added'], ['name', 'Name'], ['size', 'Size'], ['ext', 'Format'], ['folder', 'Folder'], ['random', 'Shuffle']].concat(kind === 'v' ? [['dur', 'Length'], ['res', 'Resolution']] : [['res', 'Resolution']]);
  const fm = formatCounts(kind);
  const s = Sheet.open(`
    <button class="btn wide" data-act="style-sheet" data-k="${kind}" style="margin-bottom:6px">${ic(styleOf(kind) === 'grid' ? 'grid' : styleOf(kind), 18)} View style: ${(STYLES[kind].find(x => x[0] === styleOf(kind)) || [0, 'Grid'])[1]}</button>
    <div class="lbl">SORT BY</div>${seg(sorts, ST[by], 'vs-set', by)}
    <div class="lbl">ORDER</div>${seg([['desc', 'Newest / largest first'], ['asc', 'Oldest / smallest first']], ST.dir, 'vs-set', 'dir')}
    <div class="lbl">GROUP BY</div>${seg([['day', 'Day'], ['month', 'Month'], ['none', 'None']], ST.group, 'vs-set', 'group')}
    <div class="lbl">FORMAT</div><div class="chips wrapc"><button class="chip ${!App.fmtF ? 'on' : ''}" data-act="fmt-set" data-v="">All</button>${fm.map(f => `<button class="chip ${App.fmtF === f[0] ? 'on' : ''}" data-act="fmt-set" data-v="${f[0]}">${f[0].toUpperCase()} · ${f[1]}</button>`).join('')}</div>
    <div class="lbl">GRID SIZE · <span id="colv">${ST.cols}</span> per row</div>
    <input type="range" class="rng" id="colr" min="2" max="6" step="1" value="${ST.cols}">
    <div class="lbl">THUMBNAILS</div>${seg([['square', 'Square'], ['orig', 'Original shape']], ST.tile, 'vs-set', 'tile')}`, { title: 'Sort & view' });
  $('#colr', s).oninput = e => { ST.cols = +e.target.value; $('#colv', s).textContent = ST.cols; saveST(); App.render(); };
}
const extOf = it => { const m = /\.([a-z0-9]{2,5})$/i.exec(it.n || ''); return m ? m[1].toLowerCase() : ''; };
function formatCounts(kind) {
  const m = new Map(); for (const i of visible()) if (i.v === (kind === 'v')) { const e = extOf(i) || '?'; m.set(e, (m.get(e) || 0) + 1); }
  return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 14);
}
ACT['fmt-set'] = el => { App.fmtF = el.dataset.v || ''; Sheet.close(); App.render(true); };
ACT['vs-set'] = el => {
  ST[el.dataset.k] = el.dataset.v; saveST();
  $$(`[data-act=vs-set][data-k=${el.dataset.k}]`).forEach(b => b.classList.toggle('on', b.dataset.v === el.dataset.v));
  App.render();
};
ACT['view-sheet'] = el => viewSheet(el.dataset.k);

/* ---------- the pick-from-gallery overlay (used by Vault and Collections) ---------- */
const Picker = {
  gv: null, sel: { on: true, keys: new Set(), ctx: 'pick' },
  open(title, items, onDone, okLabel = 'Add') {
    const p = $('#picker');
    this.sel.keys.clear(); this.onDone = onDone; this.items = items;
    p.innerHTML = `<header class="phd"><button class="ib" data-act="pick-close">${ic('x', 22)}</button><b id="ptitle">${esc(title)}</b><span class="sp"></span><button class="ib" data-act="pick-all">${ic('check', 20)}<small>All</small></button></header><div class="pscroll" id="pscroll"></div><footer class="pft"><button class="btn pri wide" id="pdone" data-act="pick-done" disabled>${esc(okLabel)}</button></footer>`;
    p.hidden = false; this.okLabel = okLabel;
    this.gv = new GridView($('#pscroll'), items, {
      mode: 'grid', cols: ST.cols, tile: ST.tile, group: ST.group, by: 'date', sel: this.sel, root: $('#pscroll'),
      onTap: it => { this.sel.keys.has(it.key) ? this.sel.keys.delete(it.key) : this.sel.keys.add(it.key); this.ui(); },
      onLong: it => { this.sel.keys.add(it.key); this.ui(); },
    });
    this.gv.g.classList.add('selmode');
    this.ui();
  },
  ui() {
    this.gv.refresh(); this.gv.g.classList.add('selmode');
    const n = this.sel.keys.size, b = $('#pdone');
    b.disabled = !n; b.textContent = n ? `${this.okLabel} ${plural(n, 'item')}` : 'Select items';
  },
  close() { const p = $('#picker'); p.hidden = true; p.innerHTML = ''; if (this.gv) this.gv.destroy(); this.gv = null; },
};
ACT['pick-close'] = () => Picker.close();
ACT['pick-all'] = () => { const s = Picker.sel; const all = Picker.items.length === s.keys.size; s.keys.clear(); if (!all) Picker.items.forEach(i => s.keys.add(i.key)); Picker.ui(); };
ACT['pick-done'] = () => { const keys = [...Picker.sel.keys]; const f = Picker.onDone; Picker.close(); f && f(Picker.items.filter(i => keys.includes(i.key))); };
