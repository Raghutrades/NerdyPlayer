'use strict';
/* ===== NerdyPlayer · themes and the welcome animation =====
   Colours for each theme live in css/themes.css as  :root[data-theme=…]. */

const THEMES = {
  cinema:   { name: 'Cinema',   bg: '#0b0b14', a1: '#7c5cff', a2: '#22d3ee', dark: true },
  amoled:   { name: 'Amoled',   bg: '#000000', a1: '#8b5cf6', a2: '#06b6d4', dark: true },
  aurora:   { name: 'Aurora',   bg: '#06130f', a1: '#34d399', a2: '#22d3ee', dark: true },
  ember:    { name: 'Ember',    bg: '#150b08', a1: '#fb923c', a2: '#f43f5e', dark: true },
  orchid:   { name: 'Orchid',   bg: '#150a14', a1: '#f472b6', a2: '#a78bfa', dark: true },
  ocean:    { name: 'Deep sea', bg: '#08121c', a1: '#38bdf8', a2: '#818cf8', dark: true },
  daylight: { name: 'Daylight', bg: '#f4f5fb', a1: '#6d4aff', a2: '#0ea5e9', dark: false },
  sunrise:  { name: 'Sunrise',  bg: '#fff6ee', a1: '#f0642f', a2: '#d6336c', dark: false },
};
const themeNow = () => THEMES[ST.theme] || THEMES.cinema;
function applyTheme() {
  const k = THEMES[ST.theme] ? ST.theme : 'cinema';
  document.documentElement.dataset.theme = k;
  try { document.querySelector('meta[name=theme-color]').content = THEMES[k].bg; } catch (e) { }
  if (!(typeof Player !== 'undefined' && Player.active) && !(typeof Viewer !== 'undefined' && Viewer.active)) Dev.bars(THEMES[k].bg, !THEMES[k].dark);
}

VIEWS.themes = main => {
  const sw = Object.entries(THEMES).map(([k, t]) => `<button class="tsw ${ST.theme === k ? 'on' : ''}" data-act="theme-set" data-v="${k}" style="--a:${t.a1};--b:${t.a2};--c:${t.bg};--tx:${t.dark ? '#f1eefc' : '#241f33'}">
      <span class="tprev"><i></i><u></u><s></s></span><b>${t.name}</b><em>${ic('check', 14)}</em></button>`).join('');
  main.innerHTML = `<p class="sub">Dark rooms for movies, bright ones for daytime. Amoled is pure black and saves battery on OLED screens.</p>
    <section class="card"><h3>Colour theme</h3><div class="tgrid">${sw}</div></section>
    <section class="card"><h3>Welcome animation</h3><p class="mute sm" style="margin:0 0 12px">A short intro each time you open the app. Tap it to skip.</p>
      <div class="row gap"><button class="btn ${ST.splash ? 'on' : ''}" data-act="splash-toggle">${ST.splash ? 'On' : 'Off'}</button><button class="btn" data-act="splash-replay">${ic('play', 16)} Watch it now</button></div></section>`;
  return { title: 'Themes', back: true };
};
ACT['theme-set'] = el => { ST.theme = el.dataset.v; saveST(); applyTheme(); App.render(); };
ACT['splash-toggle'] = el => { ST.splash = !ST.splash; saveST(); el.textContent = ST.splash ? 'On' : 'Off'; el.classList.toggle('on', ST.splash); };
ACT['splash-replay'] = () => Splash.run(true);

/* ---------- welcome animation ---------- */
const Splash = {
  el: null, timer: null, replaying: false,
  run(replay) {
    const el = this.el = $('#splash');
    if (!el) return;
    if (!replay && ST.splash === false) { el.remove(); return; }
    clearTimeout(this.timer);
    this.replaying = !!replay;
    el.hidden = false; el.classList.remove('out');
    if (replay) { el.style.display = 'none'; void el.offsetWidth; el.style.display = ''; }
    const wait = replay ? 3800 : Math.max(1200, 3800 - performance.now());
    this.timer = setTimeout(() => this.hide(), wait);
  },
  hide() {
    const el = this.el;
    if (!el || el.classList.contains('out')) return;
    clearTimeout(this.timer);
    el.classList.add('out');
    setTimeout(() => { if (el.classList.contains('out')) { if (this.replaying) el.hidden = true; else el.remove(); } }, 800);
  },
};
document.addEventListener('click', e => { if (e.target.closest('#splash')) Splash.hide(); });
