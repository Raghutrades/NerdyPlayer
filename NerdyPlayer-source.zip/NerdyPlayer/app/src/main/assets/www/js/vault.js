'use strict';
/* ===== NerdyPlayer · PIN lock screen, the encrypted vault, privacy settings =====
   The PIN is checked in the Android shell, never in this page. The vault files are AES-256
   encrypted on the phone and only decrypted in memory while you are looking at them. */

const Lock = {
  visible: false, purpose: 'app', cb: null, cancel: null, mode: 'enter', pin: '', first: '', old: '', title: '', waitT: null,
  show(purpose, cb, o = {}) {
    this.purpose = purpose; this.cb = cb || null; this.cancel = o.cancel || null; this.mode = 'enter'; this.pin = ''; this.title = o.title || '';
    this.canCancel = o.canCancel !== undefined ? o.canCancel : purpose !== 'app' || !Native.sec.appLock;
    this.visible = true; this.draw();
    const s = Native.refreshSec();
    if (s.bio && s.bioAvail && !s.wait) setTimeout(() => this.tryBio(), 250);
  },
  setup(cb, cancel, o = {}) {                // create a PIN
    this.purpose = o.purpose || 'vault'; this.cb = cb; this.cancel = cancel; this.mode = 'new'; this.pin = ''; this.first = ''; this.canCancel = true; this.title = '';
    this.visible = true; this.draw();
  },
  change(cb) {                              // change an existing PIN
    this.purpose = 'vault'; this.cb = cb; this.cancel = null; this.mode = 'old'; this.pin = ''; this.canCancel = true; this.visible = true; this.draw();
  },
  hide() { this.visible = false; const l = $('#lockscreen'); l.classList.remove('on'); setTimeout(() => { if (!this.visible) l.hidden = true; }, 200); clearInterval(this.waitT); },
  tryBio() { Native.call('bio', this.purpose); },
  draw() {
    const l = $('#lockscreen'); l.hidden = false; requestAnimationFrame(() => l.classList.add('on'));
    const s = Native.sec, m = this.mode;
    const T = { enter: this.title || (this.purpose === 'vault' ? 'Open your vault' : 'Unlock NerdyPlayer'), new: 'Create a PIN', confirm: 'Type it again', old: 'Current PIN' }[m];
    const sub = { enter: 'Enter your PIN', new: 'Use 4 to 12 digits. Nobody can recover it for you without your phone’s screen lock.', confirm: 'Just to be sure', old: 'First, your current PIN' }[m];
    const dots = Math.max(4, this.pin.length);
    l.innerHTML = `<div class="lk-in"><div class="lk-ico">${ic(m === 'enter' ? 'lock' : 'key', 30)}</div><h2>${esc(T)}</h2><p id="lk-s">${sub}</p>
      <div class="dots" id="lk-d">${Array.from({ length: dots }, (_, i) => `<i class="${i < this.pin.length ? 'f' : ''}"></i>`).join('')}</div>
      <div class="lk-msg" id="lk-m"></div>
      <div class="keys">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => `<button data-act="lk-k" data-v="${n}">${n}</button>`).join('')}
        ${m === 'enter' && s.bio && s.bioAvail ? `<button class="alt" data-act="lk-bio" aria-label="Fingerprint">${ic('finger', 26)}</button>` : '<span></span>'}
        <button data-act="lk-k" data-v="0">0</button><button class="alt" data-act="lk-del" aria-label="Delete">${ic('left', 24)}</button></div>
      <button class="btn pri wide lk-go" data-act="lk-go" ${this.pin.length >= 4 ? '' : 'disabled'}>${m === 'enter' ? 'Unlock' : 'Next'}</button>
      <div class="lk-links">${m === 'enter' && s.pinSet ? `<a data-act="lk-forgot">Forgot PIN?</a>` : ''}${this.canCancel ? `<a data-act="lk-cancel">Cancel</a>` : ''}</div></div>`;
    if (m === 'enter' && s.wait > 0) this.countdown(s.wait);
  },
  msg(t, bad) { const e = $('#lk-m'); if (e) { e.textContent = t; e.classList.toggle('bad', !!bad); } },
  shake() { const d = $('#lk-d'); if (d) { d.classList.remove('shake'); void d.offsetWidth; d.classList.add('shake'); } },
  key(d) { if (this.pin.length >= 12 || this.blocked) return; this.pin += d; this.upd(); },
  del() { this.pin = this.pin.slice(0, -1); this.upd(); },
  upd() {
    const d = $('#lk-d'); if (!d) return;
    d.innerHTML = Array.from({ length: Math.max(4, this.pin.length) }, (_, i) => `<i class="${i < this.pin.length ? 'f' : ''}"></i>`).join('');
    const b = $('.lk-go'); if (b) b.disabled = this.pin.length < 4;
  },
  countdown(ms) {
    clearInterval(this.waitT); this.blocked = true; const end = Date.now() + ms;
    const f = () => { const left = Math.ceil((end - Date.now()) / 1000); if (left <= 0) { clearInterval(this.waitT); this.blocked = false; this.msg(''); return; } this.msg(`Too many wrong tries. Wait ${left > 90 ? Math.ceil(left / 60) + ' min' : left + ' s'}.`, true); };
    f(); this.waitT = setInterval(f, 500);
  },
  go() {
    const p = this.pin; if (p.length < 4) return;
    if (this.mode === 'enter') {
      const r = Native.json('verify', p, this.purpose) || {};
      if (r.ok) {
        Native.refreshSec();
        if (r.vaultErr) toast('The vault could not be opened on this phone');
        const cb = this.cb; this.cb = null; this.hide(); this.pin = ''; Vault.reloadIfOpen(); cb && cb(true); if (this.purpose === 'app') window.nrResume && 0; return;
      }
      this.pin = ''; this.upd(); this.shake();
      if (r.wait) this.countdown(r.wait); else this.msg(`Wrong PIN. ${r.left != null ? r.left + ' tries left before a pause.' : ''}`, true);
    } else if (this.mode === 'old') { this.old = p; this.mode = 'new'; this.pin = ''; this.draw(); }
    else if (this.mode === 'new') { this.first = p; this.mode = 'confirm'; this.pin = ''; this.draw(); }
    else if (this.mode === 'confirm') {
      if (p !== this.first) { this.pin = ''; this.mode = 'new'; this.draw(); this.msg('The two PINs did not match. Start again.', true); this.shake(); return; }
      const r = Native.json('setPin', p, this.old || '') || {};
      if (!r.ok) { this.msg(r.err || 'Could not save', true); this.pin = ''; this.mode = this.old !== undefined && this.old !== '' ? 'old' : 'new'; this.draw(); this.msg(r.err || 'Could not save', true); return; }
      this.old = ''; Native.json('verify', p, 'vault'); Native.refreshSec();
      const cb = this.cb; this.cb = null; this.hide(); this.pin = ''; toast('PIN saved'); Vault.offerBio(); Vault.reloadIfOpen(); cb && cb(true);
    }
  },
};
ACT['lk-k'] = el => Lock.key(el.dataset.v);
ACT['lk-del'] = () => Lock.del();
ACT['lk-go'] = () => Lock.go();
ACT['lk-bio'] = () => Lock.tryBio();
ACT['lk-cancel'] = () => { const c = Lock.cancel; Lock.cancel = null; Lock.cb = null; Lock.hide(); c && c(); };
ACT['lk-forgot'] = async () => {
  const s = Native.refreshSec();
  if (!s.deviceSecure) {
    const ok = await confirmBox('No way to reset', 'Your phone has no screen lock, so the app cannot check that it is really you. The only option is to <b>erase the vault and the PIN</b> and start fresh. Everything inside the vault is lost.', 'Erase everything', true);
    if (ok) { Native.call('vaultWipe', ''); Native.refreshSec(); Lock.hide(); App.render(); toast('Vault erased'); }
    return;
  }
  const ok = await confirmBox('Reset your PIN?', 'Confirm with your phone’s own screen lock (pattern, PIN or fingerprint). Your vault stays safe and you choose a new PIN.', 'Continue');
  if (ok) Native.call('devConfirm');
};
Native.on('dev', o => {
  if (!o.ok) return toast('Not confirmed');
  Lock.visible = true; Lock.mode = 'new'; Lock.pin = ''; Lock.old = ''; Lock.first = ''; Lock.purpose = 'vault'; Lock.canCancel = true; Lock.draw();
});
Native.on('bio', o => {
  if (!Lock.visible) return;
  if (o.ok) { Native.refreshSec(); const cb = Lock.cb; Lock.cb = null; Lock.hide(); Lock.pin = ''; Vault.reloadIfOpen(); cb && cb(true); }
});
document.addEventListener('keydown', e => { if (!Lock.visible) return; if (/^[0-9]$/.test(e.key)) Lock.key(e.key); else if (e.key === 'Backspace') Lock.del(); else if (e.key === 'Enter') Lock.go(); });

/* ---------- the vault ---------- */
const Vault = {
  items: [], loaded: false,
  needPin(purpose, title) {
    return new Promise(res => {
      if (!AB) return res(true);
      const s = Native.refreshSec();
      if (!s.pinSet) return Lock.setup(() => res(true), () => res(false), { purpose });
      if ((purpose === 'vault' && s.vaultOk) || (purpose === 'app' && (s.appOk || (s.vaultOk && !s.vaultAlways)))) return res(true);
      Lock.show(purpose, () => res(true), { title, cancel: () => res(false), canCancel: true });
    });
  },
  reloadIfOpen() { if (App.view === 'vault') App.render(); },
  load() {
    const s = Native.sec; this.items = [];
    if (!s.vaultOk) return;
    let a = []; try { a = JSON.parse(Native.call('vaultList') || '[]'); } catch (e) { }
    this.items = a.map(e => ({ key: 'z' + e.id, id: e.id, vault: true, v: !!e.v, k: e.v ? 'v' : 'i', n: e.n, m: e.m, s: e.s, a: e.a, t: e.t || e.a, d: e.d, w: e.w, h: e.h, b: 'Vault', th: !!e.th, p: '' }))
      .sort((x, y) => y.a - x.a);
    this.loaded = true;
  },
  onLocked() { this.items = []; this.loaded = false; },
  async offerBio() {
    const s = Native.refreshSec();
    if (s.bioAvail && !s.bio) {
      const ok = await confirmBox('Use fingerprint or face?', 'Unlock faster. Your PIN still works any time.', 'Turn on');
      if (ok) { Native.call('setOpt', 'bio', '1'); toast('Biometric unlock on'); }
    }
  },
  async addItems(list) {
    if (!list.length) return;
    const ok = await this.needPin('vault', 'Open your vault');
    if (!ok) return;
    const go = await confirmBox(`Move ${plural(list.length, 'item')} to the vault?`,
      `They are copied into the vault and <b>encrypted</b>. Then Android asks you once to remove the originals, so they no longer show in any gallery.<br><br>${sizeStr(list.reduce((a, b) => a + b.s, 0))} total.`, 'Move to vault');
    if (!go) return;
    if (SEL.on) selExit();
    const meta = list.map(i => ({ key: i.key, n: i.n, m: i.m, v: i.v ? 1 : 0, s: i.s, d: i.d, w: i.w, h: i.h, t: i.t, b: i.b }));
    this.busy(`Encrypting 0 / ${list.length}…`);
    this.addList = list;
    Native.call('vaultAdd', JSON.stringify(meta));
  },
  busy(t) {
    let b = $('#busy'); if (!b) return;
    if (!t) { b.hidden = true; return; }
    b.hidden = false; b.innerHTML = `<div class="spin"></div><span id="busyt">${esc(t)}</span>`;
  },
  originalsResult(o) {
    this.busy('');
    const p = this.pend || { done: (o.keys || []).length };
    if (o.ok) {
      const gone = new Set(o.keys || []);
      LIB.items = LIB.items.filter(i => !gone.has(i.key)); rebuildLib(LIB.items);
      toast(`${plural(gone.size, 'item')} moved to the vault`);
    } else toast('Copies are safe in the vault, but the originals are still in your gallery. Delete them yourself when ready.', 5200);
    this.pend = null; rescan(true); this.load(); App.render();
  },
  deleteItems(list) {
    confirmBox(`Delete ${plural(list.length, 'item')} forever?`, 'They are erased from the vault and cannot be recovered.', 'Delete forever', true).then(ok => {
      if (!ok) return;
      Native.call('vaultDelete', JSON.stringify(list.map(i => i.id)));
      if (SEL.on) selExit();
      this.load();
      if (Viewer.active && Viewer.vault) Viewer.afterDelete(new Set(list.map(i => i.key)));
      App.render(); toast('Deleted');
    });
  },
  async exportItems(list, remove) {
    const msg = remove ? 'back into your gallery (Pictures / Movies → NerdyPlayer) and remove them from the vault' : 'into your gallery (Pictures / Movies → NerdyPlayer) and keep them in the vault too';
    const ok = await confirmBox(remove ? 'Restore to gallery?' : 'Export a copy?', `${plural(list.length, 'item')} will be saved ${msg}. Once outside the vault they are no longer protected.`, remove ? 'Restore' : 'Export');
    if (!ok) return;
    this.busy('Decrypting…');
    Native.call('vaultRestore', JSON.stringify(list.map(i => i.id)), !!remove);
  },
};
Native.on('vprog', o => { const t = $('#busyt'); if (t) t.textContent = `Encrypting ${o.i} / ${o.n}…`; });
Native.on('vadd', o => {
  if (o.err) { Vault.busy(''); return toast(o.err); }
  if (o.keys && o.keys.length) {
    Vault.pend = { done: o.done };
    Vault.busy('Waiting for Android to remove the originals…');
    Native.call('vaultRemoveOriginals', JSON.stringify(o.keys));
  } else { Vault.busy(''); toast('Nothing could be added'); }
  if (o.failed) toast(`${o.failed} could not be copied and stayed where they were`, 4200);
  Vault.load();
});
Native.on('vrest', o => {
  Vault.busy(''); toast(o.failed ? `${o.ok} saved, ${o.failed} failed` : `${plural(o.ok, 'item')} saved to your gallery`);
  if (SEL.on) selExit(); Vault.load(); rescan(true); App.render();
  if (Viewer.active && Viewer.vault && o.removed) Viewer.afterDelete(new Set(Vault.items.map(i => i.key).filter(() => false)));
});

VIEWS.vault = main => {
  const s = Native.refreshSec();
  if (!AB) { main.innerHTML = `<div class="empty">${ic('lock', 44)}<h3>The vault lives in the phone app</h3><p>It needs Android's secure key storage.</p></div>`; return { title: 'Vault' }; }
  if (!s.pinSet) {
    main.innerHTML = `<section class="vhero">${ic('shield', 46)}<h2>Your private vault</h2>
      <p>Hide photos and videos where no gallery, file manager or other app can see them. Everything inside is <b>encrypted with AES-256</b> and opens only with your PIN${s.bioAvail ? ' or fingerprint' : ''}.</p>
      <ul class="vlist"><li>${ic('check', 16)} Works fully offline, no account, no cloud</li><li>${ic('check', 16)} Hidden from Gallery, Files and backups</li><li>${ic('check', 16)} Videos still play and seek normally</li><li>${ic('check', 16)} Blocks screenshots while it is open</li></ul>
      <button class="btn pri wide" data-act="vault-setup">${ic('key', 16)} Create PIN and open vault</button></section>`;
    return { title: 'Vault' };
  }
  if (!s.vaultOk) {
    main.innerHTML = `<section class="vhero">${ic('lock', 46)}<h2>Vault is locked</h2><p>Your hidden photos and videos are encrypted until you unlock.</p><button class="btn pri wide" data-act="vault-unlock">${ic('unlock', 16)} Unlock</button></section>`;
    setTimeout(() => { if (App.view === 'vault' && !Lock.visible && !Native.sec.vaultOk && !Vault.asked) { Vault.asked = true; Vault.needPin('vault', 'Open your vault').then(ok => { Vault.asked = false; if (ok) App.render(); }); } }, 80);
    return { title: 'Vault' };
  }
  Vault.load();
  const list = Vault.items;
  const total = list.reduce((a, b) => a + b.s, 0);
  const sub = App.sub.vault || 'all';
  const L = list.filter(i => sub === 'all' || (sub === 'v' ? i.v : !i.v));
  let h = `<div class="tbar"><div class="chips">${[['all', 'All'], ['i', 'Photos'], ['v', 'Videos']].map(c => `<button class="chip ${sub === c[0] ? 'on' : ''}" data-act="vsub" data-v="${c[0]}">${c[1]}</button>`).join('')}</div></div>`;
  if (!L.length) {
    main.innerHTML = h + `<div class="empty">${ic('lock', 44)}<h3>${list.length ? 'Nothing in this filter' : 'Your vault is empty'}</h3><p>Add photos and videos and they disappear from your gallery, safe and encrypted.</p><button class="btn pri" data-act="vault-add">${ic('plus', 16)} Add from gallery</button></div>`;
  } else {
    main.innerHTML = h + `<div class="count">${plural(L.length, 'item')} · ${sizeStr(total)} encrypted</div><div id="gv"></div>`;
    App.gv = mkGrid($('#gv'), L, { mode: 'grid', group: 'none', ctx: 'vault' });
    const g = App.gv; g.cfg.onMore = null;
    g.cfg.onTap = (it, gv) => { if (SEL.on) return selToggle(it); if (it.v) { const vids = gv.items.filter(x => x.v); Player.open(vids, vids.indexOf(it), { vault: true }); } else Viewer.open(gv.items, gv.items.indexOf(it), { vault: true }); };
  }
  return { title: 'Vault', actions: [['plus', 'vault-add'], ['lock', 'lock-now']] };
};
ACT['vsub'] = el => { App.sub.vault = el.dataset.v; App.render(); };
ACT['vault-setup'] = () => Lock.setup(() => App.render(), null, { purpose: 'vault' });
ACT['vault-unlock'] = () => Vault.needPin('vault', 'Open your vault').then(ok => ok && App.render());
ACT['vault-add'] = () => {
  const l = sortItems(visible(), 'date', 'desc'); if (!l.length) return toast('Your gallery is empty');
  Picker.open('Add to vault', l, items => Vault.addItems(items), 'Hide');
};
ACT['vault-restore'] = () => { const l = selItems(); selExit(); Vault.exportItems(l, true); };
ACT['vault-export'] = () => { const l = selItems(); selExit(); Vault.exportItems(l, false); };
ACT['vault-del'] = () => Vault.deleteItems(selItems());

/* ---------- Privacy & security ---------- */
VIEWS.privacy = main => {
  const s = Native.refreshSec();
  const row = (t, sub, ctrl) => `<div class="rowsw"><div class="grow"><span>${t}</span>${sub ? `<small>${sub}</small>` : ''}</div>${ctrl}</div>`;
  const NS = (k, v) => `data-act="priv-set" data-k="${k}" data-v="${v}"`;
  const segN = (opts, cur, k) => `<div class="seg">${opts.map(([v, t]) => `<button class="${String(cur) === String(v) ? 'on' : ''}" ${NS(k, v)}>${t}</button>`).join('')}</div>`;
  main.innerHTML = `<p class="sub">Your photos stay on this phone. NerdyPlayer has <b>no internet permission</b> at all, and Android backups of its data are switched off.</p>
  <section class="card"><h3>PIN</h3><p class="mute sm" style="margin:0 0 12px">${s.pinSet ? 'A PIN is set. It protects the vault, locked folders and (optionally) the whole app.' : 'No PIN yet. Create one to use the vault and lock features.'}</p>
    <div class="row gap wrap"><button class="btn pri" data-act="pin-${s.pinSet ? 'change' : 'new'}">${ic('key', 16)} ${s.pinSet ? 'Change PIN' : 'Create PIN'}</button>${s.pinSet ? `<button class="btn" data-act="lock-now">${ic('lock', 16)} Lock now</button>` : ''}</div></section>
  <section class="card"><h3>Locking</h3>
    ${row('Lock the whole app', 'Ask for the PIN every time you open NerdyPlayer', sw(s.appLock, 'priv-sw', 'applock'))}
    ${s.bioAvail ? row('Fingerprint or face', 'Unlock quickly instead of typing the PIN', sw(s.bio, 'priv-sw', 'bio')) : ''}
    ${row('Vault always asks', 'Even if the app is already unlocked', sw(s.vaultAlways, 'priv-sw', 'vaultAlways'))}
    ${row('Shake to lock', 'Shake the phone hard three times to lock at once', sw(s.shake, 'priv-sw', 'shake'))}
    <div class="lbl">LOCK AFTER LEAVING THE APP</div>${segN([[0, 'At once'], [15, '15 s'], [60, '1 min'], [300, '5 min'], [-1, 'Never']], s.autolock, 'autolock')}</section>
  <section class="card"><h3>Hide from screenshots</h3><p class="mute sm" style="margin:0 0 10px">Also hides this app's picture in the recent-apps list.</p>
    ${segN([[0, 'Off'], [1, 'Vault only'], [2, 'Everywhere']], s.secure, 'secure')}</section>
  <section class="card"><h3>Locked folders</h3>${UD.lockedB.length ? UD.lockedB.map(b => `<div class="rowsw"><span>${ic('folder', 16)} ${esc(b)}</span><button class="btn sm" data-act="unlock-folder" data-b="${esc(b)}">Unlock for good</button></div>`).join('') : `<p class="mute sm" style="margin:0">None. Open a folder in Albums and tap the lock to hide it until you enter your PIN. (This hides it inside NerdyPlayer. For real encryption, use the vault.)</p>`}</section>
  <section class="card"><h3>How your data is protected</h3><div class="col gap6">${[
      'The vault is AES-256 encrypted. Its key is stored in the phone’s hardware-backed key store and never leaves it.',
      'Your PIN is checked by the Android part of the app, with growing waits after wrong tries.',
      'Decrypted pictures and videos exist only in memory while you view them.',
      'Forgot the PIN? Confirm with your phone’s screen lock and set a new one. If your phone has no screen lock, there is no way back, so keep one.',
      'Uninstalling the app erases the vault. Export what you want to keep first.',
    ].map(x => `<div class="sm row top gap6"><span class="accol">${ic('check', 14)}</span><span>${esc(x)}</span></div>`).join('')}</div></section>
  ${s.pinSet || s.vaultExists ? `<section class="card"><h3>Danger zone</h3><button class="btn danger" data-act="vault-wipe">${ic('trash', 15)} Erase vault and PIN</button></section>` : ''}`;
  return { title: 'Privacy & security', back: true };
};
ACT['pin-new'] = () => Lock.setup(() => App.render(), null, { purpose: 'vault' });
ACT['pin-change'] = () => Lock.change(() => App.render());
ACT['priv-sw'] = async el => {
  const k = el.dataset.k, s = Native.refreshSec();
  if ((k === 'applock' || k === 'bio') && !s.pinSet) { const ok = await Vault.needPin('vault', ''); if (!ok) return; }
  Native.call('setOpt', k, s[k === 'applock' ? 'appLock' : k] ? '0' : '1'); App.render();
};
ACT['priv-set'] = el => { Native.call('setOpt', el.dataset.k, el.dataset.v); App.render(); };
ACT['unlock-folder'] = async el => { await Items.lockFolder(el.dataset.b, false); };
ACT['vault-wipe'] = async () => {
  const ok = await confirmBox('Erase the vault?', 'Every hidden photo and video and your PIN will be <b>destroyed</b>. This cannot be undone.', 'Erase', true);
  if (!ok) return;
  const s = Native.refreshSec(); let pin = '';
  if (s.pinSet) { const okp = await Vault.needPin('vault', 'Confirm with your PIN'); if (!okp) return; pin = await promptBox('Type your PIN to erase', 'PIN', '', 'Erase'); if (!pin) return; }
  if (Native.call('vaultWipe', pin) === true) { Native.refreshSec(); Vault.onLocked(); toast('Vault erased'); App.render(); } else toast('Wrong PIN');
};
