'use strict';
/* ===== NerdyPlayer · lock screen (Sec) and private vault (Vault_) ===== */
const Sec = (() => {
  let mode = null, buf = '', first = '', after = null, cancel = null, waitT = null;
  const el = () => $('#lock');
  const dots = () => `<div class="dots">${'<i></i>'.repeat(buf.length)}</div>`;
  function paint(title, msg, opts = {}) {
    const bio = opts.bio && S.st.bio && CFG.bio;
    el().innerHTML = `<div class="lg">${ic(opts.icon || 'lock', 32)}</div><h2>${esc(title)}</h2><div class="msg" id="lmsg">${esc(msg || '')}</div><div id="ld">${dots()}</div>
    <div class="pp">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => `<button data-d="${n}">${n}</button>`).join('')}
      <button data-d="bio" style="${bio ? '' : 'visibility:hidden'}">${ic('fp', 26)}</button><button data-d="0">0</button><button data-d="bk">${ic('backspace', 24)}</button></div>
    <div class="row gap" style="margin-top:18px"><button class="btn pri" data-d="ok">Unlock</button>${opts.cancel ? '<button class="btn" data-d="cancel">Cancel</button>' : ''}</div>`;
    el().classList.add('on');
  }
  function show(m, o = {}) { mode = m; buf = ''; first = ''; after = o.after || null; cancel = o.cancel || null; paint(o.title, o.msg, o); }
  function hide() { el().classList.remove('on'); mode = null; buf = ''; clearInterval(waitT); }
  function msg(t) { const m = $('#lmsg'); if (m) m.textContent = t; }
  function shake() { const d = $('#ld'); if (d) { d.classList.remove('shake'); void d.offsetWidth; d.classList.add('shake'); } hap(40); }
  function refresh() { const d = $('#ld'); if (d) d.innerHTML = dots(); }
  function wait(sec) {
    clearInterval(waitT); let s = sec;
    const tick = () => { if (s <= 0) { clearInterval(waitT); msg('Try again'); return; } msg('Too many tries. Wait ' + s + 's'); s--; };
    tick(); waitT = setInterval(tick, 1000);
  }
  async function submit() {
    if (buf.length < 4) { msg('Use at least 4 digits'); return shake(); }
    if (mode === 'verify') {
      const r = nat('verify', buf) || 'bad:0';
      if (r === 'ok') { S.st.unlocked = true; const f = after; hide(); f && f(); return; }
      buf = ''; refresh(); shake();
      if (r.startsWith('wait:')) wait(+r.slice(5)); else msg('Wrong PIN. ' + (r.split(':')[1] || 0) + ' tries before a pause');
    } else if (mode === 'new') {
      first = buf; buf = ''; mode = 'confirm'; refresh(); $('#lock h2').textContent = 'Confirm your PIN'; msg('Enter it once more');
    } else if (mode === 'confirm') {
      if (buf !== first) { buf = ''; first = ''; mode = 'new'; refresh(); shake(); $('#lock h2').textContent = 'Create a PIN'; return msg('Did not match. Start again'); }
      const r = nat('setPin', '', buf);
      if (r === 'ok') { S.st.pin = true; S.st.unlocked = true; const f = after; hide(); toast('PIN set'); f && f(); }
      else { buf = ''; refresh(); shake(); msg('Could not save the PIN'); }
    } else if (mode === 'old' || mode === 'change') {
      /* change flow: ask old, then new, then confirm */
      if (mode === 'old') { const r = nat('verify', buf) || 'bad:0'; if (r !== 'ok') { buf = ''; refresh(); shake(); return msg(r.startsWith('wait') ? 'Wait ' + r.slice(5) + 's' : 'Wrong PIN'); } S._oldPin = buf; buf = ''; mode = 'change'; refresh(); $('#lock h2').textContent = 'New PIN'; return msg('Enter a new PIN (4 to 12 digits)'); }
      first = buf; buf = ''; mode = 'changec'; refresh(); $('#lock h2').textContent = 'Confirm new PIN'; msg('Once more');
    } else if (mode === 'changec') {
      if (buf !== first) { buf = ''; mode = 'change'; refresh(); shake(); $('#lock h2').textContent = 'New PIN'; return msg('Did not match'); }
      const r = nat('setPin', S._oldPin || '', buf); S._oldPin = '';
      if (r === 'ok') { hide(); toast('PIN changed'); } else { buf = ''; refresh(); shake(); msg('Could not change the PIN'); }
    } else if (mode === 'remove') {
      const r = nat('removePin', buf);
      if (r === 'ok') { S.st.pin = false; S.st.applock = false; S.st.unlocked = false; hide(); toast('PIN removed'); renderMain(); }
      else { buf = ''; refresh(); shake(); msg('Wrong PIN'); }
    }
  }
  function key(d) {
    if (d === 'bk') { buf = buf.slice(0, -1); return refresh(); }
    if (d === 'ok') return submit();
    if (d === 'cancel') { const c = cancel; hide(); c && c(); return; }
    if (d === 'bio') return nat('bio');
    if (buf.length < 12) { buf += d; refresh(); hap(8); }
  }
  document.addEventListener('click', e => { const b = e.target.closest('#lock [data-d]'); if (b) key(b.dataset.d); });
  const api = {
    /* run fn only when the vault is usable (PIN exists and unlocked) */
    needVault(fn) {
      if (!S.st.pin) return api.setup(fn);
      if (S.st.unlocked) return fn();
      api.ask(fn, () => { });
    },
    setup(fn) { show('new', { title: 'Create a PIN', msg: 'Protects your private vault (4 to 12 digits)', after: fn, cancel: () => { if (S.view === 'vault') go('lib'); }, cancel_: 1, icon: 'key' }); },
    ask(fn, onCancel) { show('verify', { title: 'Enter PIN', msg: '', after: fn, bio: true, cancel: onCancel, icon: 'lock' }); if (onCancel) if (S.st.bio && CFG.bio) setTimeout(() => nat('bio'), 350); },
    change() { show('old', { title: 'Current PIN', msg: '', cancel: () => { }, icon: 'key' }); },
    remove() { show('remove', { title: 'Enter PIN to remove it', msg: 'The vault stays encrypted but will no longer need a PIN', cancel: () => { }, icon: 'key' }); },
    lockNow() { nat('lock'); S.st.unlocked = false; S.vault = []; S.vaultOpen = false; if (Viewer.isOn() && Viewer.ctx() === 'vault') Viewer.close(); api.afterLock(); },
    afterLock() {
      if (S.st.applock) { S.media = []; S.loaded = false; api.ask(async () => { await boot2(); }, null); }
      else if (S.view === 'vault') render();
    },
    onNativeLock() { api.lockNow(); },
    onBio(ok) { if (ok && mode === 'verify') { S.st.unlocked = true; const f = after; hide(); f && f(); } },
    lockBack() { if (cancel) { const c = cancel; hide(); c(); return true; } return false; },
    isOn: () => el().classList.contains('on')
  };
  return api;
})();

const Vault_ = (() => {
  const empty = () => `<div class="empty"><div class="big">${ic('lock', 34)}</div><h3 style="color:var(--tx);margin:0 0 6px">Your private vault is empty</h3><p>Files you hide are encrypted with AES-256 and removed from the gallery and every other app. Only this app can open them.</p><button class="btn pri" data-vb="add">${ic('plus', 16)} Add photos & videos</button></div>`;
  async function render(m) {
    if (!S.st.pin) {
      m.innerHTML = `<div class="empty"><div class="big">${ic('shield', 34)}</div><h3 style="color:var(--tx);margin:0 0 6px">Private vault</h3><p>Hide photos and videos behind a PIN. They are encrypted and invisible to the gallery and other apps.</p><button class="btn pri" data-vb="setup">Create a PIN</button></div>`;
      S.vaultOpen = false; renderBar(); return;
    }
    if (!S.st.unlocked) {
      S.vaultOpen = false; renderBar();
      m.innerHTML = `<div class="empty"><div class="big">${ic('lock', 34)}</div><h3 style="color:var(--tx);margin:0 0 6px">Vault locked</h3><p>Enter your PIN${S.st.bio && CFG.bio ? ' or use your fingerprint' : ''} to open it.</p><button class="btn pri" data-vb="open">Unlock</button></div>`;
      return;
    }
    S.vaultOpen = true; renderBar();
    const ok = await loadVault();
    if (!ok) { S.st.unlocked = false; return render(m); }
    const v = S.vault.slice();
    const head = `<div class="pad row" style="gap:8px"><span class="mute sm grow">${v.length} item${v.length === 1 ? '' : 's'} · ${sizeStr(v.reduce((s, x) => s + x.s, 0))} · AES-256</span><button class="btn sm" data-vb="add">${ic('plus', 14)} Add</button></div>`;
    m.innerHTML = head + '<div id="gh"></div>';
    mountGrid($('#gh'), v, { ctx: 'vault', vault: true, group: false, empty: empty() });
  }
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-vb]'); if (!b) return;
    const a = b.dataset.vb;
    if (a === 'setup') Sec.setup(() => render($('#main')));
    if (a === 'open') Sec.ask(() => render($('#main')), () => { });
    if (a === 'add') { S.pick = true; S.tab = 'all'; go('lib'); startSel(); renderMain(); }
  });
  return { render };
})();
