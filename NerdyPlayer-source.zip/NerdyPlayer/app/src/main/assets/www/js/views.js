'use strict';
/* ===== NerdyPlayer · view styles: Mosaic, Feed, Stack, Reels + live video previews =====
   A video card plays a muted preview of the real video (served from the phone with range support).
   If the page cannot play it, the card falls back to a flip-book of 6 stills taken from the video. */
const VIEWS = [['grid', 'Grid', 'grid', 'Square tiles'], ['mosaic', 'Mosaic', 'mosaic', 'True shapes'], ['feed', 'Feed', 'feed', 'Big cards'], ['stack', 'Stack', 'stack', 'Swipe deck']];

const Preview = (() => {
  const live = new Map();           // pv element -> state
  const observers = [];
  let muted = true;
  const MAX = 2;

  function fallback(el, st) {
    if (st.fb) return; st.fb = true;
    if (st.v) { st.v.pause(); st.v.remove(); st.v = null; }
    const id = el.dataset.vid; let n = 0;
    const img = document.createElement('img'); img.className = 'pvf'; img.alt = '';
    el.appendChild(img);
    const step = () => { img.src = '/frame/' + id + '/' + n; n = (n + 1) % 6; };
    img.onload = () => el.classList.add('live');
    step(); st.fbT = setInterval(step, 800); st.img = img;
  }
  function play(el) {
    if (!CFG.live || live.has(el) || !el.dataset.vid || !S.st.perm) return;
    if (live.size >= MAX) stop(live.keys().next().value);
    const st = { v: null, to: 0, fb: false }; live.set(el, st);
    const v = document.createElement('video');
    v.muted = muted; v.loop = true; v.playsInline = true; v.setAttribute('playsinline', ''); v.preload = 'auto'; v.src = '/vid/' + el.dataset.vid;
    v.addEventListener('playing', () => { clearTimeout(st.to); if (!st.fb) el.classList.add('live'); });
    v.addEventListener('error', () => fallback(el, st));
    v.addEventListener('timeupdate', () => { const b = el.querySelector('.pgl'); if (b && v.duration) b.style.width = (v.currentTime / v.duration * 100) + '%'; });
    el.insertBefore(v, el.querySelector('.dur') || null);
    st.v = v;
    const pr = v.play(); if (pr && pr.catch) pr.catch(() => { });
    st.to = setTimeout(() => { if (!el.classList.contains('live')) fallback(el, st); }, 3500);
  }
  function stop(el) {
    const st = live.get(el); if (!st) return;
    clearTimeout(st.to); clearInterval(st.fbT);
    if (st.v) { try { st.v.pause(); st.v.removeAttribute('src'); st.v.load(); } catch (e) { } st.v.remove(); }
    if (st.img) st.img.remove();
    el.classList.remove('live'); live.delete(el);
  }
  /* watch every video card inside scope; play when 60 % visible */
  function watch(scope, root) {
    const io = new IntersectionObserver(es => es.forEach(e => e.isIntersecting ? play(e.target) : stop(e.target)), { root: root || null, threshold: [0.6] });
    $$('.pv[data-vid]', scope).forEach(el => io.observe(el));
    observers.push(io);
    return io;
  }
  function stopAll() { observers.forEach(o => o.disconnect()); observers.length = 0; [...live.keys()].forEach(stop); }
  function setMuted(m) { muted = m; live.forEach(st => { if (st.v) st.v.muted = m; }); }
  return { play, stop, watch, stopAll, setMuted, isMuted: () => muted };
})();

const bigThumb = (it, px) => it.vault ? '/vt/' + it.uid : '/thumb/' + it.t + '/' + it.i + '/' + px;
const arOf = it => it.w && it.h ? Math.max(0.62, Math.min(1.8, it.w / it.h)) : 1.25;
const subLine = it => [it.b, dayLabel(it.d), isVid(it) ? durStr(it.u) : (it.w ? it.w + '×' + it.h : ''), it.s ? sizeStr(it.s) : ''].filter(Boolean).join(' · ');

function pvHTML(it, px, extra = '') {
  const vid = isVid(it);
  return `<div class="pv" ${vid ? `data-vid="${it.i}"` : ''} data-k="${esc(K(it))}" ${extra}>
    <img class="poster" loading="lazy" src="${bigThumb(it, px)}" alt="">
    ${vid ? `<span class="lv">LIVE</span><span class="dur">${ic('play', 11)}${durStr(it.u)}</span><button class="mute" data-fm="1">${ic(Preview.isMuted() ? 'mute' : 'volume', 17)}</button><span class="pgl"></span>` : ''}
  </div>`;
}

/* ---------------- Feed ---------------- */
const Feed = {
  mount(host, items) {
    Preview.stopAll();
    host.innerHTML = '<div class="feed" id="fd"></div><div id="fsent" style="height:2px"></div>';
    const fd = $('#fd', host); let pos = 0;
    const more = () => {
      const end = Math.min(items.length, pos + 8); let html = '';
      for (; pos < end; pos++) {
        const it = items[pos], k = K(it), fav = S.fav.has(k);
        html += `<article class="fc" data-k="${esc(k)}"><div class="fh"><div class="grow"><b>${esc(it.n)}</b><span>${esc(subLine(it))}</span></div></div>
          ${pvHTML(it, 900, `style="aspect-ratio:${arOf(it)}"`)}
          <div class="fa"><button class="ib ${fav ? 'on' : ''}" data-fa="fav">${ic(fav ? 'heartfill' : 'heart', 22)}</button><button class="ib" data-fa="share">${ic('share', 21)}</button><button class="ib" data-fa="open">${ic('expand', 21)}</button><span class="grow"></span>${isVid(it) ? `<span class="xs mute" style="padding-right:10px">Preview plays on its own</span>` : ''}</div></article>`;
      }
      fd.insertAdjacentHTML('beforeend', html);
      Preview.watch(fd, $('#main'));
    };
    more();
    const io = new IntersectionObserver(es => { if (es[0].isIntersecting && pos < items.length) more(); }, { root: $('#main'), rootMargin: '1400px' });
    io.observe($('#fsent', host));
    host.onclick = e => {
      const card = e.target.closest('.fc'); if (!card) return;
      const it = S.map.get(card.dataset.k); if (!it) return;
      const m = e.target.closest('[data-fm]');
      if (m) { Preview.setMuted(!Preview.isMuted()); $$('.pv .mute', host).forEach(b => b.innerHTML = ic(Preview.isMuted() ? 'mute' : 'volume', 17)); return; }
      const a = e.target.closest('[data-fa]');
      if (a) {
        if (a.dataset.fa === 'fav') { toggleFav(card.dataset.k); const on = S.fav.has(card.dataset.k); a.classList.toggle('on', on); a.innerHTML = ic(on ? 'heartfill' : 'heart', 22); hap(15); }
        if (a.dataset.fa === 'share') nat('share', it.t, +it.i);
        if (a.dataset.fa === 'open') openItem(it);
        return;
      }
      if (e.target.closest('.pv')) openItem(it);
    };
  }
};

/* ---------------- Stack (swipe deck) ---------------- */
const Stack = {
  mount(host, items) {
    Preview.stopAll();
    let i = 0;
    host.innerHTML = `<div class="stkw"><div class="stk" id="stk"></div><div class="stkb"><button id="sk-prev">${ic('undo', 22)}</button><button class="big" id="sk-fav">${ic('heart', 28)}</button><button id="sk-open">${ic('expand', 22)}</button></div><div class="stkc" id="sk-c"></div></div>`;
    const box = $('#stk', host);
    const cardHTML = (it, pos) => `<div class="sc" data-pos="${pos}"><span class="stamp l">SKIP</span><span class="stamp r">LOVE</span>${pvHTML(it, 1080)}<div class="cap"><b>${esc(it.n)}</b><span>${esc(subLine(it))}</span></div></div>`;
    const place = () => {
      Preview.stopAll();
      const cs = [0, 1, 2].map(n => items[i + n]).filter(Boolean);
      box.innerHTML = cs.map((it, n) => cardHTML(it, n)).reverse().join('');
      $$('.sc', box).forEach(c => layout(c, +c.dataset.pos));
      $('#sk-c', host).textContent = items.length ? (i + 1) + ' of ' + items.length + ' · swipe left or right, up to love it' : '';
      const top = items[i]; const fb = $('#sk-fav', host);
      if (fb) { const on = top && S.fav.has(K(top)); fb.innerHTML = ic(on ? 'heartfill' : 'heart', 28); }
      const tp = $('.sc[data-pos="0"] .pv', box); if (tp && tp.dataset.vid) Preview.play(tp);
      if (!top) box.innerHTML = `<div class="empty">That was everything.<br><br><button class="btn pri" id="sk-again">Start again</button></div>`;
    };
    const layout = (c, n) => { c.style.transform = `translateY(${n * 16}px) scale(${1 - n * 0.055})`; c.style.opacity = n > 2 ? 0 : 1; c.style.zIndex = 10 - n; c.style.pointerEvents = n === 0 ? 'auto' : 'none'; };
    const next = d => { i = Math.max(0, Math.min(items.length, i + d)); place(); };
    let g = null;
    box.addEventListener('pointerdown', e => {
      const c = e.target.closest('.sc[data-pos="0"]'); if (!c || e.target.closest('[data-fm]')) return;
      box.setPointerCapture(e.pointerId); g = { c, x: e.clientX, y: e.clientY, dx: 0, dy: 0, t: Date.now() }; c.classList.add('drag');
    });
    box.addEventListener('pointermove', e => {
      if (!g) return; g.dx = e.clientX - g.x; g.dy = e.clientY - g.y;
      g.c.style.transform = `translate(${g.dx}px,${g.dy}px) rotate(${g.dx / 18}deg)`;
      $('.stamp.l', g.c).style.opacity = Math.max(0, Math.min(1, -g.dx / 110));
      $('.stamp.r', g.c).style.opacity = Math.max(0, Math.min(1, Math.max(g.dx, -g.dy) / 110));
    });
    const end = () => {
      if (!g) return; const { c, dx, dy, t } = g; g = null; c.classList.remove('drag');
      const moved = Math.hypot(dx, dy);
      if (moved < 8 && Date.now() - t < 300) { const it = items[i]; if (it) openItem(it); layout(c, 0); return; }
      if (-dy > 120 && Math.abs(dy) > Math.abs(dx)) { const it = items[i]; if (it && !S.fav.has(K(it))) { toggleFav(K(it)); toast('Loved'); } c.style.transform = 'translateY(-120%) scale(.9)'; c.style.opacity = 0; hap(20); setTimeout(() => next(1), 220); return; }
      if (Math.abs(dx) > 110) { c.style.transform = `translate(${dx > 0 ? 130 : -130}%,${dy}px) rotate(${dx > 0 ? 25 : -25}deg)`; c.style.opacity = 0; setTimeout(() => next(1), 220); return; }
      layout(c, 0); $('.stamp.l', c).style.opacity = 0; $('.stamp.r', c).style.opacity = 0;
    };
    box.addEventListener('pointerup', end); box.addEventListener('pointercancel', end);
    host.addEventListener('click', e => {
      if (e.target.closest('#sk-prev')) return next(-1);
      if (e.target.closest('#sk-again')) { i = 0; return place(); }
      const m = e.target.closest('[data-fm]'); if (m) { Preview.setMuted(!Preview.isMuted()); m.innerHTML = ic(Preview.isMuted() ? 'mute' : 'volume', 17); return; }
      if (e.target.closest('#sk-open')) { const it = items[i]; if (it) openItem(it); return; }
      if (e.target.closest('#sk-fav')) { const it = items[i]; if (!it) return; toggleFav(K(it)); hap(18); e.target.closest('#sk-fav').innerHTML = ic(S.fav.has(K(it)) ? 'heartfill' : 'heart', 28); }
    });
    place();
  }
};

/* ---------------- Reels (fullscreen vertical) ---------------- */
const Reels = (() => {
  let on = false, items = [];
  const root = () => $('#reels');
  function open(list, start = 0) {
    if (!list.length) return toast('Nothing to show');
    Preview.stopAll();
    items = list; on = true; S.map = new Map(list.map(x => [K(x), x]));
    const r = root(); r.classList.add('on');
    r.innerHTML = `<div class="rt"><button data-r="close">${ic('close', 26)}</button><span class="grow"></span><button data-r="mute">${ic(Preview.isMuted() ? 'mute' : 'volume', 24)}</button></div><div class="rsc" id="rsc">${list.map((it, n) => `<section class="rs" data-n="${n}"></section>`).join('')}</div>`;
    const sc = $('#rsc', r);
    const fill = el => {
      if (el.dataset.f) return; el.dataset.f = 1;
      const it = items[+el.dataset.n], k = K(it), fav = S.fav.has(k);
      el.innerHTML = `<div class="bd" style="background-image:url('${bigThumb(it, 300)}')"></div>${pvHTML(it, 1280)}<div class="cp"><b>${esc(it.n)}</b><span>${esc(subLine(it))}</span></div><div class="rl"><button data-r="fav" class="${fav ? 'on' : ''}">${ic(fav ? 'heartfill' : 'heart', 26)}</button><button data-r="share">${ic('share', 24)}</button><button data-r="open">${ic('expand', 24)}</button></div>`;
      const pv = $('.pv[data-vid]', el); if (pv) io2.observe(pv);
    };
    const io1 = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { fill(e.target); const nx = e.target.nextElementSibling; nx && fill(nx); } }), { root: sc, rootMargin: '100% 0px' });
    const io2 = new IntersectionObserver(es => es.forEach(e => e.isIntersecting ? Preview.play(e.target) : Preview.stop(e.target)), { root: sc, threshold: [0.6] });
    $$('.rs', sc).forEach(el => io1.observe(el));
    sc._ios = [io1, io2];
    setTimeout(() => { const t = $$('.rs', sc)[start]; if (t) t.scrollIntoView(); }, 30);
  }
  function close() {
    if (!on) return; on = false;
    const r = root(), sc = $('#rsc', r); if (sc && sc._ios) sc._ios.forEach(o => o.disconnect());
    Preview.stopAll(); r.classList.remove('on'); r.innerHTML = '';
    if (S.view === 'lib') renderMain();
  }
  document.addEventListener('click', e => {
    const r = e.target.closest('#reels'); if (!r) return;
    const b = e.target.closest('[data-r]');
    if (!b) {
      const m = e.target.closest('[data-fm]');
      if (m) { Preview.setMuted(!Preview.isMuted()); $$('#reels .mute, #reels [data-r="mute"]').forEach(x => x.innerHTML = ic(Preview.isMuted() ? 'mute' : 'volume', x.dataset.r ? 24 : 17)); return; }
      const pv = e.target.closest('.pv[data-vid]'); if (pv) { const v = pv.querySelector('video'); if (v) { if (v.paused) v.play(); else v.pause(); } }
      return;
    }
    const a = b.dataset.r;
    if (a === 'close') return close();
    if (a === 'mute') { Preview.setMuted(!Preview.isMuted()); b.innerHTML = ic(Preview.isMuted() ? 'mute' : 'volume', 24); $$('#reels .pv .mute').forEach(x => x.innerHTML = ic(Preview.isMuted() ? 'mute' : 'volume', 17)); return; }
    const sec = b.closest('.rs'); const it = items[+sec.dataset.n];
    if (a === 'fav') { toggleFav(K(it)); const on = S.fav.has(K(it)); b.classList.toggle('on', on); b.innerHTML = ic(on ? 'heartfill' : 'heart', 26); hap(15); }
    if (a === 'share') nat('share', it.t, +it.i);
    if (a === 'open') { Preview.setMuted(true); openItem(it, items); }
  });
  return { open, close, isOn: () => on };
})();
