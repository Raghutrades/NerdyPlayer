'use strict';
/* ===== NerdyPlayer · screens: Home, Videos, Photos, Albums, folders, collections, search ===== */

const VIEWS = {};
const ROWS = {}; // id -> list, so cards in a row can open with their neighbours as context

const cardHTML = (it, ctx) => `<button class="hc" data-act="row-open" data-key="${it.key}" data-ctx="${ctx}">
  <div class="hth">${Src.thumb(it, 300) ? `<img loading="lazy" src="${Src.thumb(it, 300)}" alt="" onerror="this.classList.add('bad')">` : ''}<span class="ph">${ic(it.v ? 'film' : 'image', 22)}</span>
  ${it.v ? `<span class="dur">${fmtDur(it.d)}</span>` : ''}
  ${(() => { const p = it.v ? posOf(it.key) : null; return p && it.d ? `<div class="prog"><i style="width:${Math.min(100, p.t * 1000 / it.d * 100).toFixed(1)}%"></i></div>` : ''; })()}</div>
  <span class="hn">${esc(it.n)}</span></button>`;
ACT['row-open'] = el => {
  const list = ROWS[el.dataset.ctx] || []; const it = list.find(i => i.key === el.dataset.key);
  if (it) Items.open(it, list);
};
function hrow(id, title, list, more) {
  if (!list.length) return '';
  ROWS[id] = list;
  return `<div class="sechd"><h2>${title}</h2>${more || ''}</div><div class="hs">${list.slice(0, 24).map(i => cardHTML(i, id)).join('')}</div>`;
}

/* ---------- Home ---------- */
VIEWS.home = main => {
  const vis = visible(), vids = vis.filter(i => i.v), imgs = vis.filter(i => !i.v);
  const total = vis.reduce((a, b) => a + b.s, 0);
  const hr = new Date().getHours();
  const hello = hr < 5 ? 'Late night' : hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';
  let h = `<section class="hero"><div class="pill">${ic('shield', 14)} 100% offline · nothing leaves this phone</div>
    <h1>${hello}, <em>Raghu.</em></h1>
    <p class="hstats">${LIB.ready && vis.length ? `<b>${vids.length.toLocaleString()}</b> videos · <b>${imgs.length.toLocaleString()}</b> photos · <b>${sizeStr(total)}</b>` : 'Your private media room'}</p>
    <div class="hbtns"><button class="btn pri" data-act="play-random">${icFill('play', 14)} Surprise me</button><button class="btn glass" data-act="slideshow-all">${ic('slides', 16)} Slideshow</button><button class="btn glass" data-act="open-file">${ic('plus', 16)} Open file</button></div></section>`;
  if (!vis.length) { main.innerHTML = h + emptyHTML('v'); return { title: null }; }

  const cont = Object.entries(UD.pos).sort((a, b) => b[1].at - a[1].at).map(([k]) => LIB.map.get(k)).filter(i => i && vis.includes(i));
  h += hrow('cont', 'Continue watching', cont, `<a data-act="go" data-v="videos" data-s="prog">All</a>`);
  const recent = sortItems(vis, 'added', 'desc').slice(0, 30);
  h += hrow('new', 'Recently added', recent);
  const favs = vis.filter(i => isFav(i.key));
  h += hrow('favs', 'Favourites', favs, `<a data-act="go" data-v="smart" data-id="fav">All</a>`);
  const now = new Date();
  const otd = imgs.concat(vids).filter(i => { const d = new Date(i.t); return d.getMonth() === now.getMonth() && d.getDate() === now.getDate() && d.getFullYear() < now.getFullYear(); }).sort((a, b) => b.t - a.t);
  h += hrow('otd', 'On this day', otd);

  const tools = [
    ['disk', 'Storage', 'Where your space goes', 'storage'], ['copy', 'Duplicates', 'Find the same file twice', 'dups'],
    ['lock', 'Vault', 'Hidden and encrypted', 'vault'], ['layers', 'Collections', 'Your own albums', 'albums'],
  ];
  if (Native.info.canTrash) tools.push(['trash', 'Trash', 'Bring things back', 'trash']);
  h += `<div class="sechd"><h2>Tools</h2></div><div class="tools">${tools.map(t => `<button class="tool" data-act="go" data-v="${t[3]}">${ic(t[0], 22)}<b>${t[1]}</b><span>${t[2]}</span></button>`).join('')}</div>`;

  const bs = [...LIB.buckets.values()].filter(b => !isLockedBucket(b.name) || SESS.unlockedFolders).sort((a, b) => b.items.length - a.items.length).slice(0, 12);
  if (bs.length) h += `<div class="sechd"><h2>Folders</h2><a data-act="go" data-v="albums">All</a></div><div class="hs">${bs.map(b => folderCard(b, true)).join('')}</div>`;
  main.innerHTML = h;
  return { title: null };
};
ACT['play-random'] = () => {
  const v = visible().filter(i => i.v); if (!v.length) return toast('No videos found');
  const l = v.slice().sort(() => Math.random() - .5); Player.open(l, 0);
};
ACT['slideshow-all'] = () => {
  const l = visible().filter(i => !i.v); if (!l.length) return toast('No photos found');
  Viewer.open(sortItems(l, 'date', 'desc'), 0, { slideshow: true });
};
ACT['go'] = el => { if (el.dataset.s) App.sub[el.dataset.v === 'videos' ? 'v' : 'i'] = el.dataset.s; App.go(el.dataset.v, el.dataset.id ? { id: el.dataset.id } : {}); };

function folderCard(b, small) {
  const locked = isLockedBucket(b.name) && !SESS.unlockedFolders;
  const cover = b.items[0];
  return `<button class="fc ${small ? 'sm' : ''}" data-act="folder-open" data-b="${esc(b.name)}">
    <div class="fth">${locked ? `<span class="lk">${ic('lock', 26)}</span>` : (cover && Src.thumb(cover, 300) ? `<img loading="lazy" src="${Src.thumb(cover, 300)}" alt="" onerror="this.classList.add('bad')">` : '')}<span class="ph">${ic('folder', 26)}</span></div>
    <b>${esc(b.name)}</b><span>${locked ? 'Locked' : [b.i ? plural(b.i, 'photo') : '', b.v ? plural(b.v, 'video') : ''].filter(Boolean).join(' · ')}</span></button>`;
}
ACT['folder-open'] = async el => {
  const b = el.dataset.b;
  if (isLockedBucket(b) && !SESS.unlockedFolders) {
    const ok = await Vault.needPin('app', 'Unlock locked folders');
    if (!ok) return;
    SESS.unlockedFolders = true; toast('Locked folders are open until you leave the app');
    App.render();
  }
  App.go('album', { b });
};

/* ---------- Videos / Photos ---------- */
function filterFor(kind, sub, vis) {
  let l = vis.filter(i => kind === 'v' ? i.v : !i.v);
  let keepOrder = false;
  switch (sub) {
    case 'fav': l = l.filter(i => isFav(i.key)); break;
    case 'recent': l = UD.hist.map(k => LIB.map.get(k)).filter(i => i && i.v === (kind === 'v') && l.includes(i)); keepOrder = true; break;
    case 'prog': l = l.filter(i => posOf(i.key)).sort((a, b) => posOf(b.key).at - posOf(a.key).at); keepOrder = true; break;
    case 'long': l = l.filter(i => i.d > 20 * 60000); break;
    case 'cam': l = l.filter(i => /camera|dcim/i.test(i.b + ' ' + i.p)); break;
    case 'shot': l = l.filter(i => /screenshot|screen shot|screen_record|screenrecord/i.test(i.b + ' ' + i.p)); break;
    case 'big': l = l.filter(i => i.s > 5 * 1048576); break;
    default: break;
  }
  if (!keepOrder) l = sortItems(l, ST[kind === 'v' ? 'sortV' : 'sortP'], ST.dir);
  return l;
}
const dateSorted = () => ['date', 'added'].includes(ST.sortV);

function libView(main, kind) {
  const sub = App.sub[kind] || 'all';
  const chips = kind === 'v'
    ? [['all', 'All'], ['folders', 'Folders'], ['fav', 'Favourites'], ['recent', 'Recent'], ['prog', 'In progress'], ['long', 'Long']]
    : [['all', 'All'], ['folders', 'Folders'], ['fav', 'Favourites'], ['cam', 'Camera'], ['shot', 'Screenshots'], ['big', 'Large']];
  const vis = visible();
  const bar = `<div class="tbar"><div class="chips">${chips.map(c => `<button class="chip ${sub === c[0] ? 'on' : ''}" data-act="sub" data-k="${kind}" data-v="${c[0]}">${c[1]}</button>`).join('')}</div>
    <button class="ib sm" data-act="view-sheet" data-k="${kind}" aria-label="Sort and view">${ic('sliders', 20)}</button></div>`;
  if (sub === 'folders') {
    const bs = [...LIB.buckets.values()].filter(b => (kind === 'v' ? b.v : b.i)).map(b => ({ ...b, items: b.items.filter(i => i.v === (kind === 'v')) })).sort((a, b) => b.items.length - a.items.length);
    main.innerHTML = bar + (bs.length ? `<div class="fgrid">${bs.map(b => folderCard(b)).join('')}</div>` : emptyHTML(kind));
    return { title: kind === 'v' ? 'Videos' : 'Photos' };
  }
  const list = filterFor(kind, sub, vis);
  if (!list.length) { main.innerHTML = bar + emptyHTML(sub === 'fav' ? 'f' : kind); return { title: kind === 'v' ? 'Videos' : 'Photos' }; }
  const total = list.reduce((a, b) => a + b.s, 0);
  main.innerHTML = bar + `<div class="count">${plural(list.length, kind === 'v' ? 'video' : 'photo')} · ${sizeStr(total)}</div><div id="gv"></div>`;
  App.gv = mkGrid($('#gv'), list, { mode: kind === 'v' && ST.viewV === 'list' ? 'list' : 'grid', group: ['recent', 'prog'].includes(sub) ? 'none' : ST.group, by: (kind === 'v' ? ST.sortV : ST.sortP) === 'added' ? 'added' : 'date' });
  return { title: kind === 'v' ? 'Videos' : 'Photos' };
}
/* a grid in the main screen, wired to selection and opening */
function mkGrid(el, list, o = {}) {
  const sortedByDate = ['date', 'added'].includes(ST.sortV) || o.by;
  const gv = new GridView(el, list, {
    mode: o.mode || 'grid', cols: ST.cols, tile: ST.tile, group: sortedByDate ? (o.group || ST.group) : 'none', by: o.by || 'date', root: $('#main'),
    onTap: (it, g) => { if (SEL.on) { selToggle(it); } else Items.open(it, g.items); },
    onLong: (it, g) => { if (!SEL.on) { SEL.ctx = o.ctx || 'gallery'; selEnter(it, g); } else selToggle(it); },
    onMore: (it, g) => Items.menu(it, g),
  });
  SEL.grid = gv; SEL.ctx = o.ctx || 'gallery';
  return gv;
}
VIEWS.videos = main => libView(main, 'v');
VIEWS.photos = main => libView(main, 'i');
ACT['sub'] = el => { App.sub[el.dataset.k] = el.dataset.v; App.render(); $('#main').scrollTop = 0; };

/* ---------- Albums ---------- */
VIEWS.albums = main => {
  const vis = visible();
  const smart = [
    ['heart', 'Favourites', vis.filter(i => isFav(i.key)).length, 'fav'], ['clock', 'Recently added', Math.min(60, vis.length), 'new'],
    ['film', 'Long videos', vis.filter(i => i.v && i.d > 20 * 60000).length, 'long'], ['disk', 'Largest files', Math.min(50, vis.length), 'big'],
    ['camera', 'Screenshots', vis.filter(i => /screenshot|screen_record|screenrecord/i.test(i.b + i.p)).length, 'shot'],
    ['image', 'Panoramas', vis.filter(i => !i.v && i.w / Math.max(1, i.h) > 2.2).length, 'pano'],
  ];
  let h = `<div class="sechd first"><h2>Smart albums</h2></div><div class="tools sm">${smart.map(s => `<button class="tool" data-act="go" data-v="smart" data-id="${s[3]}">${ic(s[0], 20)}<b>${s[1]}</b><span>${s[2]}</span></button>`).join('')}</div>`;
  h += `<div class="sechd"><h2>Collections</h2><a data-act="col-new">+ New</a></div>`;
  h += UD.cols.length ? `<div class="clist">${UD.cols.map(c => { const cov = c.keys.map(k => LIB.map.get(k)).find(Boolean); return `<button class="crow" data-act="go" data-v="collection" data-id="${c.id}"><div class="cth">${cov && Src.thumb(cov, 200) ? `<img loading="lazy" src="${Src.thumb(cov, 200)}" alt="" onerror="this.classList.add('bad')">` : ''}<span class="ph">${ic('layers', 22)}</span></div><div><b>${esc(c.name)}</b><span>${plural(c.keys.length, 'item')}</span></div>${ic('right', 18)}</button>`; }).join('')}</div>` : `<p class="hint">Make your own albums out of any photos and videos, without moving the files.</p>`;
  const bs = [...LIB.buckets.values()].sort((a, b) => b.items.length - a.items.length);
  h += `<div class="sechd"><h2>Folders</h2><span class="mute xs">${bs.length}</span></div>` + (bs.length ? `<div class="fgrid">${bs.map(b => folderCard(b)).join('')}</div>` : emptyHTML('v'));
  main.innerHTML = h;
  return { title: 'Albums' };
};
ACT['col-new'] = async () => { const n = await promptBox('New collection', 'Name', '', 'Create'); if (n) { newCollection(n); App.render(); } };

VIEWS.album = (main, p) => {
  const all = LIB.buckets.get(p.b);
  const kindF = App.sub.album || 'all';
  let list = (all ? all.items : []).filter(i => visible().includes(i));
  if (kindF === 'v') list = list.filter(i => i.v); if (kindF === 'i') list = list.filter(i => !i.v);
  list = sortItems(list, ST.sortP, ST.dir);
  const locked = isLockedBucket(p.b);
  const bar = `<div class="tbar"><div class="chips">${[['all', 'All'], ['i', 'Photos'], ['v', 'Videos']].map(c => `<button class="chip ${kindF === c[0] ? 'on' : ''}" data-act="albsub" data-v="${c[0]}">${c[1]}</button>`).join('')}</div>
    <button class="ib sm" data-act="folder-lock" data-b="${esc(p.b)}" aria-label="Lock folder">${ic(locked ? 'unlock' : 'lock', 20)}</button><button class="ib sm" data-act="view-sheet" data-k="i">${ic('sliders', 20)}</button></div>`;
  if (!list.length) { main.innerHTML = bar + emptyHTML('i'); return { title: p.b, back: true }; }
  main.innerHTML = bar + `<div class="count">${plural(list.length, 'item')} · ${sizeStr(list.reduce((a, b) => a + b.s, 0))}</div><div id="gv"></div>`;
  App.gv = mkGrid($('#gv'), list, { mode: 'grid' });
  return { title: p.b, back: true, actions: [['slides', 'album-slides']] };
};
ACT['albsub'] = el => { App.sub.album = el.dataset.v; App.render(); };
ACT['folder-lock'] = el => Items.lockFolder(el.dataset.b, !isLockedBucket(el.dataset.b));
ACT['album-slides'] = () => { const l = (App.gv ? App.gv.items : []).filter(i => !i.v); if (!l.length) return toast('No photos here'); Viewer.open(l, 0, { slideshow: true }); };

VIEWS.collection = (main, p) => {
  const c = UD.cols.find(x => x.id === p.id);
  if (!c) { App.back(); return {}; }
  const list = c.keys.map(k => LIB.map.get(k)).filter(i => i && visible().includes(i));
  if (!list.length) main.innerHTML = `<div class="empty">${ic('layers', 44)}<h3>${esc(c.name)} is empty</h3><p>Select photos or videos anywhere and use <b>Add to</b>.</p></div>`;
  else { main.innerHTML = `<div class="count">${plural(list.length, 'item')} · ${sizeStr(list.reduce((a, b) => a + b.s, 0))}</div><div id="gv"></div>`; App.gv = mkGrid($('#gv'), list, { mode: 'grid', group: 'none' }); }
  return { title: c.name, back: true, actions: [['more', 'col-menu']] };
};
ACT['col-menu'] = () => {
  const c = UD.cols.find(x => x.id === App.params.id); if (!c) return;
  menuSheet(c.name, [
    ['slides', 'Slideshow', () => { const l = c.keys.map(k => LIB.map.get(k)).filter(i => i && !i.v); if (!l.length) return toast('No photos in this collection'); Viewer.open(l, 0, { slideshow: true }); }],
    ['edit', 'Rename', async () => { const n = await promptBox('Rename collection', 'Name', c.name); if (n) { c.name = n; saveUD(); App.render(); } }],
    SEL.grid && SEL.grid.items.length ? ['check', 'Select items to remove', () => toast('Long-press an item, then use More → Remove')] : null,
    ['trash', 'Delete collection (files stay)', async () => { if (await confirmBox('Delete collection?', `“${esc(c.name)}” is removed. Your photos and videos are not touched.`, 'Delete', true)) { UD.cols = UD.cols.filter(x => x !== c); saveUD(); App.back(); } }, 1],
  ]);
};

VIEWS.smart = (main, p) => {
  const vis = visible();
  const defs = {
    fav: ['Favourites', () => sortItems(vis.filter(i => isFav(i.key)), 'date', 'desc')],
    new: ['Recently added', () => sortItems(vis, 'added', 'desc').slice(0, 60)],
    long: ['Long videos', () => sortItems(vis.filter(i => i.v && i.d > 20 * 60000), 'dur', 'desc')],
    big: ['Largest files', () => sortItems(vis, 'size', 'desc').slice(0, 50)],
    shot: ['Screenshots', () => sortItems(vis.filter(i => /screenshot|screen_record|screenrecord/i.test(i.b + i.p)), 'date', 'desc')],
    pano: ['Panoramas', () => sortItems(vis.filter(i => !i.v && i.w / Math.max(1, i.h) > 2.2), 'date', 'desc')],
  };
  const d = defs[p.id] || defs.fav; const list = d[1]();
  if (!list.length) main.innerHTML = emptyHTML('f');
  else { main.innerHTML = `<div class="count">${plural(list.length, 'item')} · ${sizeStr(list.reduce((a, b) => a + b.s, 0))}</div><div id="gv"></div>`; App.gv = mkGrid($('#gv'), list, { mode: 'grid', group: 'none', by: 'date' }); }
  return { title: d[0], back: true };
};

/* ---------- Search ---------- */
VIEWS.search = (main, p) => {
  const q = App.q || '';
  main.innerHTML = `<div class="sbox">${ic('search', 20)}<input id="q" type="search" placeholder="Search name, folder, year, month…" value="${esc(q)}" autocomplete="off"><button class="ib sm ${q ? '' : 'hid'}" data-act="q-clear">${ic('x', 18)}</button></div>
   <div class="chips pad">${[['all', 'All'], ['v', 'Videos'], ['i', 'Photos'], ['fav', 'Favourites']].map(c => `<button class="chip ${App.qk === c[0] ? 'on' : ''}" data-act="q-kind" data-v="${c[0]}">${c[1]}</button>`).join('')}</div><div id="sres"></div>`;
  const run = () => {
    const raw = $('#q').value.trim().toLowerCase(); App.q = raw;
    const box = $('#sres');
    $('[data-act=q-clear]').classList.toggle('hid', !raw);
    if (!raw && App.qk === 'all') { if (App.gv) { App.gv.destroy(); App.gv = null; } box.innerHTML = `<p class="hint">Try “screenshots”, “2024”, “march”, “whatsapp” or “video”.</p>`; return; }
    const toks = raw.split(/\s+/).filter(Boolean);
    let l = visible().filter(i => {
      if (App.qk === 'v' && !i.v) return false; if (App.qk === 'i' && i.v) return false; if (App.qk === 'fav' && !isFav(i.key)) return false;
      const d = new Date(i.t); const hay = `${i.n} ${i.b} ${i.m} ${MONL[d.getMonth()]} ${d.getFullYear()} ${i.v ? 'video' : 'photo image'}`.toLowerCase();
      return toks.every(t => hay.includes(t));
    });
    l = sortItems(l, 'date', 'desc').slice(0, 600);
    if (App.gv) App.gv.destroy();
    if (!l.length) { box.innerHTML = `<div class="empty small">${ic('search', 36)}<p>No matches</p></div>`; App.gv = null; return; }
    box.innerHTML = `<div class="count">${l.length}${l.length === 600 ? '+' : ''} found</div><div id="gv"></div>`;
    App.gv = mkGrid($('#gv'), l, { mode: 'grid', group: 'none' });
  };
  $('#q').oninput = debounce(run, 150);
  run();
  if (!q) setTimeout(() => { try { $('#q').focus(); } catch (e) { } }, 120);
  return { title: 'Search', back: true };
};
ACT['q-clear'] = () => { App.q = ''; App.render(); };
ACT['q-kind'] = el => { App.qk = el.dataset.v; App.render(); };
