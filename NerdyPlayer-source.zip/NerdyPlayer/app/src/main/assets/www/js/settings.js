'use strict';
/* ===== NerdyPlayer · settings ===== */

VIEWS.settings = main => {
  const r = (t, sub, ctrl) => `<div class="rowsw"><div class="grow"><span>${t}</span>${sub ? `<small>${sub}</small>` : ''}</div>${ctrl}</div>`;
  const S = (k, opts) => seg(opts, ST[k], 'set-v', k);
  const W = k => sw(ST[k], 'set-sw', k);
  main.innerHTML = `
  <section class="card"><h3>${ic('tag', 18)} Your name</h3><p class="mute sm" style="margin:0 0 10px">Shown in the greeting on Home. Leave empty for no name.</p><input class="inp" id="nm" maxlength="24" placeholder="Your name" value="${esc(ST.userName || '')}"></section>

  <section class="card"><h3>${ic('palette', 18)} Look</h3>
    <div class="row gap wrap"><button class="btn" data-act="go" data-v="themes">${ic('palette', 16)} Themes</button><button class="btn" data-act="splash-replay">${ic('play', 16)} Welcome animation</button></div>
    ${r('Full-screen app', 'Hides the status and navigation bars. Swipe from the edge to peek.', W('appFull'))}
    ${r('Show welcome animation', 'Cinematic intro on every start', W('splash'))}
    ${r('Intro music', 'Made on the phone, no files', sw(ST.splashSound !== false, 'set-sw2', 'splashSound'))}</section>

  <section class="card"><h3>${ic('film', 18)} Video player</h3>
    <div class="lbl">SKIP STEP</div>${S('seek', [[5, '5 s'], [10, '10 s'], [15, '15 s'], [30, '30 s'], [60, '1 min']])}
    ${r('Touch gestures', 'Swipe for seek, brightness and volume', W('gest'))}
    ${r('Double-tap to skip or pause', 'Left / right edges skip, middle pauses', W('dtap'))}
    ${r('Hold for 2× speed', 'Press and hold anywhere while playing', W('hold2x'))}
    ${r('Continue where I left off', null, W('resume'))}
    ${r('Remember speed per video', null, W('remSpeed'))}
    ${r('Rotate screen to match the video', 'Landscape for wide videos', W('autoland'))}
    ${r('Keep the screen on', 'While a video is playing', W('keepon'))}
    <div class="lbl">STARTING SPEED</div>${S('speed', [[0.75, '0.75×'], [1, '1×'], [1.25, '1.25×'], [1.5, '1.5×'], [2, '2×']])}
    <div class="lbl">PICTURE SIZE</div>${S('fit', [['fit', 'Fit'], ['fill', 'Fill'], ['stretch', 'Stretch'], ['100', '100%']])}
    <div class="lbl">HIDE CONTROLS AFTER</div>${S('ctlHide', [[0, 'Never'], [3, '3 s'], [4, '4 s'], [6, '6 s']])}
    <div class="lbl">AFTER A VIDEO ENDS</div>${S('loop', [['off', 'Stop'], ['one', 'Repeat it'], ['all', 'Repeat list']])}
    ${r('Play the next video', null, W('autonext'))}
    <div class="lbl">PLAYBACK ENGINE</div>${S('engine', [['auto', 'Automatic'], ['vlc', 'Advanced'], ['standard', 'Standard']])}<p class="hint">Automatic picks the best one for each file. Advanced plays every format, including half-downloaded files.</p>
    ${r('Auto-play previews on cards and reels', null, sw(ST.autoPreview !== false, 'prev-sw', 'autoPreview'))}
    <div class="lbl">WHEN YOU LEAVE THE APP</div>${S('bg', [['pause', 'Pause'], ['audio', 'Keep playing sound']])}
    ${r('Picture-in-picture on Home', 'Float the video when you press Home', sw(ST.pip !== false, 'set-sw', 'pip'))}</section>

  <section class="card"><h3>${ic('cc', 18)} Subtitles</h3>
    <div class="lbl">SIZE · ${ST.subSize}%</div><input type="range" class="rng" min="50" max="220" step="5" value="${ST.subSize}" data-rng="subSize">
    <div class="lbl">HEIGHT FROM BOTTOM · ${ST.subPos}%</div><input type="range" class="rng" min="2" max="40" step="1" value="${ST.subPos}" data-rng="subPos">
    <p class="hint">Load a .srt, .vtt or .ass file from the player's Subtitles panel. Colours and timing are adjusted there too.</p></section>

  <section class="card"><h3>${ic('image', 18)} Photos &amp; slideshow</h3>
    <div class="lbl">DOUBLE-TAP ZOOM</div>${S('dtz', [[2, '2×'], [2.5, '2.5×'], [3, '3×'], [4, '4×']])}
    <div class="lbl">SLIDESHOW TIME PER PHOTO · ${ST.ssInt} s</div><input type="range" class="rng" min="1" max="30" step="1" value="${ST.ssInt}" data-rng="ssInt">
    <div class="lbl">TRANSITION</div>${S('ssTrans', [['fade', 'Fade'], ['slide', 'Slide'], ['zoom', 'Zoom'], ['none', 'None']])}
    ${r('Slow zoom (Ken Burns)', null, W('ssKB'))}${r('Shuffle', null, W('ssShuffle'))}${r('Repeat', null, W('ssLoop'))}${r('Include videos', 'Plays each one fully', W('ssVideos'))}${r('Show name and date', null, W('ssCap'))}</section>

  <section class="card"><h3>${ic('grid', 18)} Gallery</h3>
    <div class="lbl">GRID SIZE · ${ST.cols} per row</div><input type="range" class="rng" min="2" max="6" step="1" value="${ST.cols}" data-rng="cols">
    <div class="lbl">THUMBNAILS</div>${S('tile', [['square', 'Square'], ['orig', 'Original shape']])}
    <div class="lbl">GROUP BY</div>${S('group', [['day', 'Day'], ['month', 'Month'], ['none', 'None']])}
    <div class="lbl">VIDEO LAYOUT</div>${S('viewV', [['list', 'List'], ['grid', 'Grid']])}</section>

  <section class="card"><h3>${ic('shield', 18)} Privacy</h3><p class="mute sm" style="margin:0 0 12px">PIN, fingerprint, auto-lock, vault and screenshot blocking.</p><button class="btn pri" data-act="go" data-v="privacy">${ic('shield', 16)} Privacy &amp; security</button></section>

  <section class="card"><h3>${ic('trash', 18)} Your data</h3><p class="mute sm" style="margin:0 0 12px">Favourites, collections, bookmarks and resume points live inside the app. Clearing them never touches your photos or videos.</p>
    <button class="btn danger" data-act="clear-ud">${ic('trash', 15)} Clear favourites, collections and history</button></section>
  <div class="card tc"><button class="btn" data-act="go" data-v="about">${ic('info', 16)} About NerdyPlayer</button></div>`;
  const nm = $('#nm', main); if (nm) nm.oninput = () => { ST.userName = nm.value.trim(); saveST(); };
  $$('[data-rng]', main).forEach(r => r.oninput = () => {
    ST[r.dataset.rng] = +r.value; saveST();
    const lbl = r.previousElementSibling; if (lbl) lbl.textContent = lbl.textContent.replace(/[\d.]+( s| per row|%)?$/, m => r.value + (m.match(/ s| per row|%/) || [''])[0]);
  });
  return { title: 'Settings', back: true };
};
ACT['set-v'] = el => { const k = el.dataset.k; let v = el.dataset.v; if (/^-?[\d.]+$/.test(v)) v = +v; ST[k] = v; saveST(); $$(`[data-act=set-v][data-k=${k}]`).forEach(b => b.classList.toggle('on', b.dataset.v === el.dataset.v)); };
ACT['set-sw'] = el => { const k = el.dataset.k; ST[k] = k === 'pip' ? !(ST.pip !== false) : !ST[k]; saveST(); el.classList.toggle('on', ST[k]); el.setAttribute('aria-checked', !!ST[k]); if (k === 'appFull') Native.call('appFull', !!ST.appFull); };
ACT['clear-ud'] = async () => {
  if (!await confirmBox('Clear your app data?', 'Favourites, collections, bookmarks, locked-folder list and resume points are removed. Photos and videos stay exactly where they are.', 'Clear', true)) return;
  favSet.clear(); UD.pos = {}; UD.hist = []; UD.marks = {}; UD.cols = []; UD.lockedB = []; UD.speed = {}; UD.filt = {}; saveUD(); toast('Cleared'); App.render();
};
