'use strict';
/* ===== NerdyPlayer · settings ===== */
const ACCENTS = ['#8b5cf6', '#22d3ee', '#22c55e', '#f59e0b', '#f43f5e', '#3b82f6'];
function viewSettings(m) {
  const seg = (key, arr, v) => `<div class="seg">${arr.map(a => `<button data-set="${key}" data-val="${a[0]}" class="${String(a[0]) === String(v) ? 'on' : ''}">${a[1]}</button>`).join('')}</div>`;
  const tg = (key, v) => `<button class="tg ${v ? 'on' : ''}" data-tg="${key}"></button>`;
  const row = (t, s, right) => `<div class="li"><div class="grow"><b>${t}</b>${s ? `<div class="xs mute">${s}</div>` : ''}</div>${right || ''}</div>`;
  const blk = (t, inner) => `<div class="card"><div class="xs mute" style="text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">${t}</div>${inner}</div>`;
  const al = S.st.autolock == null ? 30 : S.st.autolock;
  m.innerHTML = `<div class="pad">
  ${blk('Appearance', `
    <div class="li"><div class="grow"><b>Theme</b></div></div>${seg('theme', [['midnight', 'Midnight'], ['light', 'Light'], ['amoled', 'AMOLED']], CFG.theme)}
    <div class="li"><div class="grow"><b>Accent colour</b></div></div><div class="sw">${ACCENTS.map(c => `<i data-acc="${c}" class="${CFG.accent === c ? 'on' : ''}" style="background:${c}"></i>`).join('')}</div>
    <div class="li"><div class="grow"><b>Grid columns</b></div></div>${seg('cols', [2, 3, 4, 5, 6].map(n => [n, n]), CFG.cols)}
    ${row('Show file names', 'Under every thumbnail', tg('names', CFG.names))}
    ${row('Date headers', 'Group by day in the library', tg('dates', CFG.dates))}`)}
  <div id="sec">${blk('Privacy & security', `
    ${row('PIN', S.st.pin ? 'A PIN protects the vault' : 'No PIN yet. The vault needs one.', S.st.pin ? '<button class="btn sm" data-sa2="chpin">Change</button> <button class="btn sm danger" data-sa2="rmpin">Remove</button>' : '<button class="btn sm pri" data-sa2="mkpin">Set PIN</button>')}
    ${row('Lock the whole app', 'Ask for the PIN before anything is shown', tg('applock', !!S.st.applock))}
    ${S.st.bio ? row('Fingerprint / face unlock', 'Faster than typing the PIN', tg('bio', CFG.bio)) : ''}
    <div class="li"><div class="grow"><b>Auto-lock</b><div class="xs mute">When you leave the app</div></div></div>${seg('autolock', [[0, 'At once'], [15, '15 s'], [30, '30 s'], [60, '1 min'], [300, '5 min']], al)}
    ${row('Block screenshots', 'Also hides the app in the recent-apps list', tg('secure', !!S.st.secure))}
    ${row('Erase the vault', 'Deletes every hidden file and the key. Cannot be undone.', '<button class="btn sm danger" data-sa2="wipe">Erase</button>')}
    <p class="xs mute" style="margin:10px 0 0">Hidden files are encrypted with AES-256. The key is kept inside the phone’s secure key store. The app has no internet permission, so nothing can be uploaded.</p>`)}</div>
  ${blk('Photo viewer', `${row('Two-finger twist to rotate', 'Free-angle rotation with two fingers', tg('twist', CFG.twist))}`)}
  ${blk('Video player', `
    ${row('Resume where you stopped', '', tg('resume', CFG.resume))}
    ${row('Swipe gestures', 'Brightness, volume and seeking by swiping', tg('gest', CFG.gest))}
    ${row('Pinch, zoom and twist video', 'Two fingers to zoom, pan and rotate the picture', tg('xform', CFG.xform))}
    ${row('Auto picture-in-picture', 'Shrink to a floating window when you press Home', tg('autopip', CFG.autopip))}
    <div class="li"><div class="grow"><b>Double-tap skip</b></div></div>${seg('seek', [5, 10, 15, 30].map(n => [n, n + 's']), CFG.seek)}
    <div class="li"><div class="grow"><b>Hold to fast-play</b></div></div>${seg('hold', [2, 3, 4].map(n => [n, n + '×']), CFG.hold)}
    <div class="li"><div class="grow"><b>Default speed</b></div></div>${seg('speed', [0.75, 1, 1.25, 1.5].map(n => [n, n + '×']), CFG.speed)}
    <div class="li"><div class="grow"><b>Default picture size</b></div></div>${seg('aspect', [[0, 'Fit'], [1, 'Fill'], [3, 'Stretch'], [4, '16:9']], CFG.aspect)}`)}
  ${blk('Data on this phone', `
    ${row('Refresh library', 'Look for new photos and videos', '<button class="btn sm" data-sa2="refresh">Refresh</button>')}
    ${row('Clear favourites', S.fav.size + ' marked', '<button class="btn sm danger" data-sa2="clrfav">Clear</button>')}
    ${row('Forget video positions', 'Resume points for every video', '<button class="btn sm danger" data-sa2="clrres">Forget</button>')}`)}
  </div>`;
  if (S.params && S.params.jump === 'sec') { S.params.jump = null; setTimeout(() => { const e = $('#sec'); e && e.scrollIntoView(); }, 30); }
}
const Settings = {
  async click(e) {
    const s = e.target.closest('[data-set]');
    if (s) {
      const k = s.dataset.set; let v = s.dataset.val; if (!isNaN(+v)) v = +v;
      if (k === 'autolock') { S.st.autolock = v; nat('setInt', 'autolock', v); } else { CFG[k] = v; saveCfg(); }
      return viewSettings($('#main'));
    }
    const t = e.target.closest('[data-tg]');
    if (t) {
      const k = t.dataset.tg;
      if (k === 'applock') {
        if (!S.st.pin) { toast('Set a PIN first'); return; }
        S.st.applock = !S.st.applock; nat('setFlag', 'applock', !!S.st.applock);
      } else if (k === 'secure') { S.st.secure = !S.st.secure; nat('setFlag', 'secure', !!S.st.secure); }
      else { CFG[k] = !CFG[k]; saveCfg(); }
      return viewSettings($('#main'));
    }
    const a = e.target.closest('[data-acc]');
    if (a) { CFG.accent = a.dataset.acc; saveCfg(); return viewSettings($('#main')); }
    const x = e.target.closest('[data-sa2]');
    if (!x) return;
    const k = x.dataset.sa2;
    if (k === 'mkpin') return Sec.setup(() => viewSettings($('#main')));
    if (k === 'chpin') return Sec.change();
    if (k === 'rmpin') return Sec.remove();
    if (k === 'refresh') { await loadMedia(); toast('Library refreshed'); return; }
    if (k === 'clrfav') { S.fav.clear(); saveFav(); toast('Favourites cleared'); return viewSettings($('#main')); }
    if (k === 'clrres') { nat('clearResume'); return toast('Video positions cleared'); }
    if (k === 'wipe') {
      if (!S.st.pin) { toast('The vault has no PIN and no files yet'); return; }
      const ok = await confirmBox('Erase the whole vault?', 'Every hidden photo and video is destroyed along with the key. This cannot be undone.', 'Continue', true);
      if (!ok) return;
      const pin = await askText('Enter your PIN to erase', 'PIN', 'password');
      if (pin == null) return;
      const r = nat('wipe', pin);
      toast(r === 'ok' ? 'Erasing…' : (r && r.startsWith('wait') ? 'Too many tries, wait a bit' : 'Wrong PIN'));
    }
  }
};
