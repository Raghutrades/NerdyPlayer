'use strict';
/* ===== NerdyPlayer · settings ===== */
const ACCENTS = ['#8b5cf6', '#22d3ee', '#22c55e', '#f59e0b', '#f43f5e', '#3b82f6', '#ec4899', '#14b8a6'];
const THEMES = [['midnight', 'Midnight', 'linear-gradient(135deg,#0b0d14,#1e2336)'], ['amoled', 'AMOLED', '#000'], ['light', 'Light', 'linear-gradient(135deg,#f4f5fa,#dfe2ee)'], ['paper', 'Paper', 'linear-gradient(135deg,#f6f0e4,#e0d4bb)'], ['aurora', 'Aurora', 'linear-gradient(135deg,#06181d,#2dd4bf 60%,#a78bfa)'], ['neon', 'Neon', 'linear-gradient(135deg,#07050f,#ff2bd6 55%,#00f0ff)'], ['sunset', 'Sunset', 'linear-gradient(135deg,#190e1e,#fb7185 60%,#fbbf24)'], ['forest', 'Forest', 'linear-gradient(135deg,#09140f,#4ade80 70%,#a3e635)'], ['ocean', 'Ocean', 'linear-gradient(135deg,#050f1e,#38bdf8 60%,#818cf8)']];
function viewSettings(m) {
  const seg = (key, arr, v) => `<div class="seg">${arr.map(a => `<button data-set="${key}" data-val="${a[0]}" class="${String(a[0]) === String(v) ? 'on' : ''}">${a[1]}</button>`).join('')}</div>`;
  const tg = (key, v) => `<button class="tg ${v ? 'on' : ''}" data-tg="${key}"></button>`;
  const row = (t, s, right) => `<div class="li"><div class="grow"><b>${t}</b>${s ? `<div class="xs mute">${s}</div>` : ''}</div>${right || ''}</div>`;
  const blk = (t, inner) => `<div class="card"><div class="xs mute" style="text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">${t}</div>${inner}</div>`;
  const al = S.st.autolock == null ? 0 : S.st.autolock;
  m.innerHTML = `<div class="pad">
  <div id="look">${blk('Looks', `
    <div class="prev"><div class="row gap"><span class="ico" style="width:42px;height:42px;border-radius:14px;background:var(--card2);display:grid;place-items:center;color:var(--ac)">${ic('sparkle', 22)}</span><div class="grow"><b>Live preview</b><div class="xs mute">Everything below changes this at once</div></div><button class="btn pri sm">Button</button></div><div class="seg" style="margin:12px 0 0"><button class="on">Chip</button><button>Chip</button><button>Chip</button></div></div>
    <div class="li"><div class="grow"><b>Theme</b></div></div>
    <div class="thm">${THEMES.map(t => `<button data-set="theme" data-val="${t[0]}" class="${CFG.theme === t[0] ? 'on' : ''}"><i style="background:${t[2]}"></i><span>${t[1]}</span></button>`).join('')}</div>
    <div class="li"><div class="grow"><b>Accent colour</b><div class="xs mute">Tap again for the theme’s own colours</div></div></div><div class="sw" style="flex-wrap:wrap">${ACCENTS.map(c => `<i data-acc="${c}" class="${CFG.accent === c ? 'on' : ''}" style="background:${c}"></i>`).join('')}<i data-acc="" class="${!CFG.accent ? 'on' : ''}" style="background:conic-gradient(#8b5cf6,#22d3ee,#22c55e,#f59e0b,#f43f5e,#8b5cf6)"></i></div>
    <div class="li"><div class="grow"><b>Cards &amp; menus</b></div></div>${seg('card', [['soft', 'Soft'], ['glass', 'Glass'], ['outline', 'Outline'], ['bubble', 'Bubble'], ['sharp', 'Sharp']], CFG.card)}
    <div class="li"><div class="grow"><b>Buttons</b></div></div>${seg('btn', [['gradient', 'Gradient'], ['solid', 'Solid'], ['glow', 'Glow'], ['outline', 'Outline'], ['pill', 'Pill']], CFG.btn)}
    <div class="li"><div class="grow"><b>Navigation bar</b></div></div>${seg('nav', [['bar', 'Classic bar'], ['dock', 'Floating dock']], CFG.nav)}
    <div class="li"><div class="grow"><b>Grid columns</b></div></div>${seg('cols', [2, 3, 4, 5, 6].map(n => [n, n]), CFG.cols)}
    ${row('Show file names', 'Under every thumbnail', tg('names', CFG.names))}
    ${row('Date headers', 'Group by day, with a fast date scrubber', tg('dates', CFG.dates))}`)}
  ${blk('Videos on cards', `
    ${row('Live previews', 'Videos play a muted preview on Feed, Stack and Reels cards', tg('live', CFG.live))}
    <div class="li"><div class="grow"><b>Videos tab style</b><div class="xs mute">Also changeable from the View button in the Library</div></div></div>${seg('vwv', [['grid', 'Grid'], ['mosaic', 'Mosaic'], ['feed', 'Feed'], ['stack', 'Stack']], CFG.vw.videos)}
    <div class="li"><div class="grow"><b>Photos tab style</b></div></div>${seg('vwp', [['grid', 'Grid'], ['mosaic', 'Mosaic'], ['feed', 'Feed'], ['stack', 'Stack']], CFG.vw.photos)}`)}</div>
  <div id="sec">${blk('Privacy & security', `
    ${row('PIN', S.st.pin ? 'A PIN protects the vault' : 'No PIN yet. The vault needs one.', S.st.pin ? '<button class="btn sm" data-sa2="chpin">Change</button> <button class="btn sm danger" data-sa2="rmpin">Remove</button>' : '<button class="btn sm pri" data-sa2="mkpin">Set PIN</button>')}
    ${row('Lock the whole app', 'Ask for the PIN before anything is shown', tg('applock', !!S.st.applock))}
    ${S.st.bio ? row('Fingerprint / face unlock', 'Faster than typing the PIN', tg('bio', CFG.bio)) : ''}
    <div class="li"><div class="grow"><b>Auto-lock</b><div class="xs mute">How long after you leave the app before it locks</div></div></div>${seg('autolock', [[0, 'At once'], [15, '15 s'], [30, '30 s'], [60, '1 min'], [300, '5 min']], al)}
    ${row('Block screenshots', 'Also hides the app in the recent-apps list', tg('secure', !!S.st.secure))}
    ${row('Close the vault when I leave it', 'Asks for your PIN every time you open the Vault tab', tg('vlock', CFG.vlock))}
    ${row('Instant hide', S.st.allfiles ? 'On. Hidden files vanish from the gallery and other apps at once, with no Android prompt.' : 'Off. Android will ask you to confirm each time. Turn on “All files access” to remove originals instantly.', S.st.allfiles ? '<span class="chip on">On</span>' : '<button class="btn sm pri" data-sa2="allfiles">Turn on</button>')}
    ${row('Erase the vault', 'Deletes every hidden file and the key. Cannot be undone.', '<button class="btn sm danger" data-sa2="wipe">Erase</button>')}
    <p class="xs mute" style="margin:10px 0 0">Hidden files are encrypted with AES-256. The key is kept inside the phone’s secure key store. The app has no internet permission, so nothing can be uploaded.</p>`)}</div>
  ${blk('Photo viewer', `${row('Two-finger twist to rotate', 'Free-angle rotation with two fingers', tg('twist', CFG.twist))}`)}
  ${blk('Video player', `
    ${row('Resume where you stopped', '', tg('resume', CFG.resume))}
    ${row('Swipe gestures', 'Brightness, volume and seeking by swiping', tg('gest', CFG.gest))}
    ${row('Pinch, zoom and twist video', 'Two fingers to zoom, pan and rotate the picture', tg('xform', CFG.xform))}
    ${row('Immersive mode', 'Controls vanish fast, only a thin progress line stays', tg('immersive', CFG.immersive))}
    ${row('Ambient glow', 'The empty space around the video glows with its colours', tg('ambient', CFG.ambient))}
    ${row('Turn sideways for wide videos', 'Landscape videos switch the screen to landscape by themselves', tg('autoland', CFG.autoland))}
    ${row('Auto picture-in-picture', 'Shrink to a floating window when you press Home', tg('autopip', CFG.autopip))}
    <div class="li"><div class="grow"><b>Double-tap skip</b></div></div>${seg('seek', [5, 10, 15, 30].map(n => [n, n + 's']), CFG.seek)}
    <div class="li"><div class="grow"><b>Hold to fast-play</b></div></div>${seg('hold', [2, 3, 4].map(n => [n, n + '×']), CFG.hold)}
    <div class="li"><div class="grow"><b>Default speed</b></div></div>${seg('speed', [0.75, 1, 1.25, 1.5].map(n => [n, n + '×']), CFG.speed)}
    <div class="li"><div class="grow"><b>Default picture size</b></div></div>${seg('aspect', [[0, 'Fit'], [1, 'Fill'], [3, 'Stretch'], [4, '16:9']], CFG.aspect)}`)}
  ${blk('Data on this phone', `
    ${row('Refresh library', 'Look for new photos and videos', '<button class="btn sm" data-sa2="refresh">Refresh</button>')}
    ${row('Clear favourites', S.fav.size + ' marked', '<button class="btn sm danger" data-sa2="clrfav">Clear</button>')}
    ${row('Forget video positions', 'Resume points for every video', '<button class="btn sm danger" data-sa2="clrres">Forget</button>')}`)}
  </div>`;
  if (S.params && S.params.jump) { const id = S.params.jump; S.params.jump = null; setTimeout(() => { const e = $('#' + id); e && e.scrollIntoView(); }, 30); }
}
const Settings = {
  async click(e) {
    const s = e.target.closest('[data-set]');
    if (s) {
      const k = s.dataset.set; let v = s.dataset.val; if (!isNaN(+v)) v = +v;
      if (k === 'autolock') { S.st.autolock = v; nat('setInt', 'autolock', v); }
      else if (k === 'vwv') { CFG.vw.videos = v; saveCfg(); }
      else if (k === 'vwp') { CFG.vw.photos = v; saveCfg(); }
      else { CFG[k] = v; saveCfg(); }
      return viewSettings($('#main'));
    }
    const t = e.target.closest('[data-tg]');
    if (t) {
      const k = t.dataset.tg;
      if (k === 'applock') {
        if (!S.st.pin) { toast('Set a PIN first'); return; }
        S.st.applock = !S.st.applock; nat('setFlag', 'applock', !!S.st.applock);
      } else if (k === 'secure') { S.st.secure = !S.st.secure; nat('setFlag', 'secure', !!S.st.secure); }
      else { CFG[k] = !CFG[k]; saveCfg(); }
      return viewSettings($('#main'));
    }
    const a = e.target.closest('[data-acc]');
    if (a) { CFG.accent = a.dataset.acc || null; saveCfg(); return viewSettings($('#main')); }
    const x = e.target.closest('[data-sa2]');
    if (!x) return;
    const k = x.dataset.sa2;
    if (k === 'allfiles') {
      const ok = await confirmBox('Allow “All files access”?', 'Android will open a settings screen. Switch NerdyPlayer on there, then come back. This lets hidden originals be removed instantly, with no prompt. The app still has no internet permission.', 'Open settings');
      if (ok) nat('openAllFiles'); return;
    }
    if (k === 'mkpin') return Sec.setup(() => viewSettings($('#main')));
    if (k === 'chpin') return Sec.change();
    if (k === 'rmpin') return Sec.remove();
    if (k === 'refresh') { await loadMedia(); toast('Library refreshed'); return; }
    if (k === 'clrfav') { S.fav.clear(); saveFav(); toast('Favourites cleared'); return viewSettings($('#main')); }
    if (k === 'clrres') { nat('clearResume'); return toast('Video positions cleared'); }
    if (k === 'wipe') {
      if (!S.st.pin) { toast('The vault has no PIN and no files yet'); return; }
      const ok = await confirmBox('Erase the whole vault?', 'Every hidden photo and video is destroyed along with the key. This cannot be undone.', 'Continue', true);
      if (!ok) return;
      const pin = await askText('Enter your PIN to erase', 'PIN', 'password');
      if (pin == null) return;
      const r = nat('wipe', pin);
      toast(r === 'ok' ? 'Erasing…' : (r && r.startsWith('wait') ? 'Too many tries, wait a bit' : 'Wrong PIN'));
    }
  }
};
